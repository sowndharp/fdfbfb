import React, { useState, useMemo } from 'react';
import { LayoutGrid, ZoomIn, X, ChevronLeft, ChevronRight, Image as ImageIcon } from 'lucide-react';
import { GALLERY_ITEMS } from '../data/mockData';
import { GalleryItem } from '../types';

interface GalleryProps {
  isDarkMode: boolean;
}

export default function Gallery({ isDarkMode }: GalleryProps) {
  const [activeCategory, setActiveCategory] = useState<'All' | GalleryItem['category']>('All');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  // Filter logic
  const filteredItems = useMemo(() => {
    return GALLERY_ITEMS.filter((item) => {
      return activeCategory === 'All' ? true : item.category === activeCategory;
    });
  }, [activeCategory]);

  const categories = [
    { id: 'All', label: 'All Photos' },
    { id: 'campus', label: 'Campus Perimeter' },
    { id: 'labs', label: 'Advanced Labs' },
    { id: 'library', label: 'Central Library' },
    { id: 'sports', label: 'Sports Arena' },
    { id: 'cultural', label: 'Cultural meets' },
    { id: 'graduation', label: 'Graduation Day' }
  ] as const;

  const handlePrevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex === null) return;
    setLightboxIndex((prevIdx) => {
      if (prevIdx === null) return 0;
      return (prevIdx - 1 + filteredItems.length) % filteredItems.length;
    });
  };

  const handleNextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex === null) return;
    setLightboxIndex((prevIdx) => {
      if (prevIdx === null) return 0;
      return (prevIdx + 1) % filteredItems.length;
    });
  };

  return (
    <div id="gallery-page-container" className="animate-fade-in mt-[60px] md:mt-[76px]">
      
      {/* Page header */}
      <section className="bg-brand-blue text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-brand-blue via-brand-blue/90 to-brand-blue-accent" />
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-gold/15 rounded-full blur-3xl" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-3">
          <span className="text-xxs font-bold uppercase tracking-widest text-brand-gold px-3.5 py-1.5 rounded-full bg-white/10 border border-white/5 font-display select-none">
            Campus Snapshots
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold font-display leading-none tracking-tight">
            AVS Institutional Gallery
          </h2>
          <p className="text-xs sm:text-sm text-brand-gold-light/80 max-w-2xl mx-auto font-sans">
            A visual documentation of specialized computing rooms, seminar chambers, graduations and campus life.
          </p>
        </div>
      </section>

      {/* Categories sorting row */}
      <section className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`p-2 rounded-2xl border flex flex-wrap gap-2 justify-center items-center ${
          isDarkMode 
            ? 'bg-brand-blue-light border-white/5' 
            : 'bg-white border-gray-150 shadow'
        }`}>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold tracking-tight shrink-0 transition-all cursor-pointer ${
                activeCategory === cat.id
                  ? 'bg-brand-gold text-black shadow-md'
                  : isDarkMode
                    ? 'bg-white/5 text-gray-300 hover:bg-white/10'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </section>

      {/* Grid gallery content */}
      <section className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item, idx) => (
            <div
              key={item.id}
              onClick={() => setLightboxIndex(idx)}
              className={`group rounded-3xl overflow-hidden border shadow-sm hover:shadow-xl transition-all duration-300 cursor-pointer ${
                isDarkMode 
                  ? 'bg-brand-blue border-white/5' 
                  : 'bg-white border-gray-150'
              }`}
            >
              {/* Image box */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                
                {/* Visual hover shield */}
                <div className="absolute inset-0 bg-brand-blue/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-6 text-white font-sans">
                  <div className="flex justify-end">
                    <div className="w-8 h-8 rounded-full bg-brand-gold text-black flex items-center justify-center">
                      <ZoomIn className="w-4 h-4" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold text-brand-gold uppercase tracking-wider font-display">
                      {item.category}
                    </span>
                    <h4 className="text-xs sm:text-sm font-extrabold font-display leading-tight">
                      {item.title}
                    </h4>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Lightbox full overlay screen portal */}
      {lightboxIndex !== null && (
        <div 
          onClick={() => setLightboxIndex(null)}
          className="fixed inset-0 bg-slate-950/95 z-50 flex flex-col items-center justify-center p-4 animate-fade-in text-white font-sans"
        >
          {/* Close trigger tool */}
          <button
            onClick={() => setLightboxIndex(null)}
            className="absolute top-6 right-6 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white cursor-pointer"
            aria-label="Close full preview"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Nav arrows */}
          <button
            onClick={handlePrevImage}
            className="absolute left-6 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white cursor-pointer"
            aria-label="Previous preview photo"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          
          <button
            onClick={handleNextImage}
            className="absolute right-6 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white cursor-pointer"
            aria-label="Next preview photo"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Main Visual Display Frame */}
          <div 
            onClick={(e) => e.stopPropagation()} 
            className="max-w-4xl w-full text-center space-y-4"
          >
            <div className="max-h-[70vh] rounded-2xl overflow-hidden border border-white/5 border border-brand-gold/20 shadow-2xl relative inline-block">
              <img
                src={filteredItems[lightboxIndex].image}
                alt={filteredItems[lightboxIndex].title}
                className="max-h-[70vh] max-w-full object-contain mx-auto"
                referrerPolicy="no-referrer"
              />
            </div>
            
            <div className="space-y-1">
              <span className="text-xs text-brand-gold font-bold uppercase tracking-wider font-display">
                Photo {lightboxIndex + 1} of {filteredItems.length} • {filteredItems[lightboxIndex].category}
              </span>
              <h3 className="text-sm sm:text-base font-bold font-display max-w-xl mx-auto leading-tight">
                {filteredItems[lightboxIndex].title}
              </h3>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
