import React, { useState } from 'react';
import { 
  Building2, 
  GraduationCap, 
  BookOpen, 
  FlaskConical, 
  Trophy, 
  UserCheck, 
  Users, 
  Flame,
  LayoutGrid
} from 'lucide-react';
import { DEPARTMENTS } from '../data/mockData';

interface DepartmentsProps {
  isDarkMode: boolean;
}

export default function Departments({ isDarkMode }: DepartmentsProps) {
  const [activeDeptIdx, setActiveDeptIdx] = useState(0);

  const activeDept = DEPARTMENTS[activeDeptIdx];

  return (
    <div id="departments-page" className="animate-fade-in mt-[60px] md:mt-[76px]">
      
      {/* Title Jumbotron header */}
      <section className="bg-brand-blue text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-brand-blue via-brand-blue/90 to-brand-blue-accent" />
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-gold/15 rounded-full blur-3xl" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-3">
          <span className="text-xxs font-bold uppercase tracking-widest text-brand-gold px-3.5 py-1.5 rounded-full bg-white/10 border border-white/5 font-display select-none">
            Academics Sectors
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold font-display leading-none tracking-tight">
            Academic Departments
          </h2>
          <p className="text-xs sm:text-sm text-brand-gold-light/80 max-w-2xl mx-auto font-sans">
            Meticulously structured centers of learning led by distinguished Ph.D. scholars in Salem.
          </p>
        </div>
      </section>

      {/* Tabs list switchers */}
      <section className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`p-2 rounded-2xl border flex flex-col sm:flex-row gap-2 justify-center items-stretch sm:items-center ${
          isDarkMode 
            ? 'bg-brand-blue-light border-white/5' 
            : 'bg-white border-gray-150 shadow'
        }`}>
          {DEPARTMENTS.map((dept, idx) => {
            const isActive = activeDeptIdx === idx;
            return (
              <button
                key={dept.id}
                onClick={() => setActiveDeptIdx(idx)}
                className={`flex-1 text-center py-3.5 px-4 rounded-xl text-xs sm:text-sm font-bold tracking-tight transition-all cursor-pointer ${
                  isActive
                    ? 'bg-brand-gold text-black shadow'
                    : isDarkMode
                      ? 'bg-white/5 text-gray-300 hover:bg-white/10'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {dept.name.split(' of ')[1] || dept.name}
              </button>
            );
          })}
        </div>
      </section>

      {/* Main Department content viewport */}
      <section className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16 font-sans">
        
        {/* Intro Grid & HOD message */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Dept Details and HOD Desk Left */}
          <div className="lg:col-span-8 space-y-8">
            <div className="space-y-3">
              <h3 className={`text-2xl sm:text-3xl font-extrabold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                {activeDept.name}
              </h3>
              <p className="text-xs sm:text-sm text-gray-500 leading-relaxed font-sans">
                {activeDept.description}
              </p>
            </div>

            {/* HOD Statement Message Bubble */}
            <div className={`p-6 sm:p-8 rounded-3xl border border-dashed relative ${
              isDarkMode ? 'bg-brand-blue-light/50 border-white/10' : 'bg-slate-55 bg-white border-gray-200'
            }`}>
              <div className="absolute top-4 left-4 font-serif text-5xl opacity-15 text-brand-gold select-none">
                “
              </div>
              
              <div className="space-y-4 pl-4 relative z-10">
                <span className="text-xxs font-bold text-brand-gold uppercase tracking-widest block font-display flex items-center gap-1">
                  <UserCheck className="w-3.5 h-3.5" /> Welcoming Message • HOD's Desk
                </span>
                <p className="text-xs sm:text-sm italic text-gray-500 font-sans leading-relaxed">
                  "{activeDept.hod.message}"
                </p>
                
                {/* Sign Board */}
                <div className="pt-2 border-t border-gray-100 dark:border-white/5 text-xs">
                  <span className={`font-bold block ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>{activeDept.hod.name}</span>
                  <p className="text-xxs text-gray-400 font-medium">{activeDept.hod.designation} ({activeDept.hod.qualification}) – Estd Experience {activeDept.hod.experience}</p>
                </div>
              </div>
            </div>
          </div>

          {/* HOD Photo card Right */}
          <div className="lg:col-span-4 shrink-0">
            <div className={`p-5 rounded-3xl border text-center space-y-4 ${
              isDarkMode ? 'bg-brand-blue border-white/5' : 'bg-white border-gray-150 shadow-md'
            }`}>
              <div className="w-36 h-36 rounded-full overflow-hidden border-4 border-brand-gold/30 mx-auto shadow-md">
                <img
                  src={activeDept.hod.image}
                  alt={activeDept.hod.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="leading-tight text-xs font-sans">
                <span className={`block font-bold text-sm ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>{activeDept.hod.name}</span>
                <span className="text-xxs text-brand-gold font-bold uppercase tracking-wider block mt-1">{activeDept.hod.designation}</span>
                <span className="text-[10px] text-gray-400 block mt-1">Research background: {activeDept.hod.qualification}</span>
              </div>
            </div>
          </div>

        </div>

        {/* Faculty Block Profiles Directory */}
        <div className="space-y-6">
          <div className="flex items-center gap-2 border-b border-gray-100 dark:border-white/5 pb-4">
            <div className="p-2 bg-brand-gold/10 text-brand-gold rounded-xl">
              <Users className="w-5 h-5" />
            </div>
            <h4 className={`text-xl font-bold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
              Distinguished Faculty Directory
            </h4>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeDept.faculty.map((fac, idx) => (
              <div 
                key={idx}
                className={`p-4 rounded-2xl border flex items-center gap-4 transition-all hover:scale-101 ${
                  isDarkMode 
                    ? 'bg-brand-blue border-white/5' 
                    : 'bg-white border-gray-100 shadow-sm'
                }`}
              >
                <div className="w-16 h-16 rounded-xl overflow-hidden shadow shrink-0">
                  <img
                    src={fac.image}
                    alt={fac.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="leading-tight font-sans text-xs">
                  <span className={`block font-bold mb-0.5 ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>{fac.name}</span>
                  <span className="text-[10px] text-brand-gold font-bold uppercase tracking-wide block mb-1">{fac.designation}</span>
                  <span className="text-[10px] text-gray-400">{fac.qualification}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Labs and Prototyping Studios */}
        <div className="space-y-6">
          <div className="flex items-center gap-2 border-b border-gray-100 dark:border-white/5 pb-4">
            <div className="p-2 bg-brand-gold/10 text-brand-gold rounded-xl">
              <FlaskConical className="w-5 h-5" />
            </div>
            <h4 className={`text-xl font-bold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
              Experimental Laboratories & Prototyping Studios
            </h4>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {activeDept.laboratories.map((lab, idx) => (
              <div 
                key={idx}
                className={`group rounded-2xl overflow-hidden border ${
                  isDarkMode 
                    ? 'bg-brand-blue border-white/5' 
                    : 'bg-white border-gray-150 shadow-sm hover:shadow-md'
                } transition-all duration-300`}
              >
                <div className="h-56 overflow-hidden relative">
                  <img
                    src={lab.image}
                    alt={lab.name}
                    className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                </div>
                <div className="p-5 space-y-1.5">
                  <h5 className={`font-display text-sm font-bold tracking-tight ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                    {lab.name}
                  </h5>
                  <p className="text-xxs sm:text-xs text-gray-500 leading-relaxed font-sans">
                    {lab.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Achievements and Student Activities double panels */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 font-sans">
          
          {/* Achievements left */}
          <div className="space-y-6">
            <div className="flex items-center gap-2 border-b border-gray-100 dark:border-white/5 pb-4">
              <div className="p-2 bg-brand-gold/10 text-brand-gold rounded-xl">
                <Trophy className="w-5 h-5" />
              </div>
              <h4 className={`text-lg font-bold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                Recent Research & Department Achievements
              </h4>
            </div>

            <div className="space-y-3.5 text-xs text-gray-600 dark:text-gray-300">
              {activeDept.achievements.map((ach, idx) => (
                <div 
                  key={idx} 
                  className={`flex gap-3 items-start p-3 rounded-xl border ${
                    isDarkMode ? 'bg-white/5 border-white/5' : 'bg-white shadow-sm border-gray-100'
                  }`}
                >
                  <div className="w-6 h-6 rounded-lg bg-yellow-500/15 text-yellow-500 flex items-center justify-center font-bold shrink-0 mt-0.5">
                    ★
                  </div>
                  <p className="leading-relaxed text-xxs sm:text-xs">
                    {ach}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Activities Right */}
          <div className="space-y-6">
            <div className="flex items-center gap-2 border-b border-gray-100 dark:border-white/5 pb-4">
              <div className="p-2 bg-brand-gold/10 text-brand-gold rounded-xl">
                <Flame className="w-5 h-5" />
              </div>
              <h4 className={`text-lg font-bold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                Student Enrichment Clubs & Activities
              </h4>
            </div>

            <div className="space-y-3.5 text-xs text-gray-600 dark:text-gray-300">
              {activeDept.activities.map((act, idx) => (
                <div 
                  key={idx} 
                  className={`flex gap-3 items-start p-3 rounded-xl border ${
                    isDarkMode ? 'bg-white/5 border-white/5' : 'bg-white shadow-sm border-gray-100'
                  }`}
                >
                  <div className="w-6 h-6 rounded-lg bg-orange-500/15 text-orange-500 flex items-center justify-center font-bold shrink-0 mt-0.5">
                    ●
                  </div>
                  <p className="leading-relaxed text-xxs sm:text-xs">
                    {act}
                  </p>
                </div>
              ))}
            </div>
          </div>

        </div>

      </section>

    </div>
  );
}
