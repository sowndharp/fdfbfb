import React, { useState, useMemo } from 'react';
import { Search, BookOpen, GraduationCap, Clock, CheckCircle2, TrendingUp, AlertCircle, ArrowRight, X } from 'lucide-react';
import { COURSES } from '../data/mockData';
import { Course } from '../types';

interface CoursesProps {
  isDarkMode: boolean;
  onPageChange: (page: string) => void;
}

export default function Courses({ isDarkMode, onPageChange }: CoursesProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDegree, setSelectedDegree] = useState<'All' | 'UG' | 'PG'>('All');
  const [selectedCourseDetail, setSelectedCourseDetail] = useState<Course | null>(null);

  // Filter logic
  const filteredCourses = useMemo(() => {
    return COURSES.filter((course) => {
      const matchesSearch = course.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            course.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            course.code.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesDegree = selectedDegree === 'All' ? true : course.degree === selectedDegree;
      return matchesSearch && matchesDegree;
    });
  }, [searchQuery, selectedDegree]);

  const handleEnquireClick = () => {
    setSelectedCourseDetail(null);
    onPageChange('admissions');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div id="courses-catalog-page" className="animate-fade-in mt-[60px] md:mt-[76px]">
      
      {/* Title Header with custom visual details */}
      <section className="bg-brand-blue text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-brand-blue via-brand-blue/90 to-brand-blue-accent" />
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-gold/15 rounded-full blur-3xl" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-3">
          <span className="text-xxs font-bold uppercase tracking-widest text-brand-gold px-3.5 py-1.5 rounded-full bg-white/10 border border-white/5 font-display select-none">
            Academics Curriculums
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold font-display leading-none tracking-tight">
            Specialized College Programs
          </h2>
          <p className="text-xs sm:text-sm text-brand-gold-light/80 max-w-2xl mx-auto font-sans">
            Affiliated to Periyar University, Salem • Rigorous theoretical frameworks meets heavy practical lab experiments.
          </p>
        </div>
      </section>

      {/* Filter and Search Bar row */}
      <section className="py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`p-4 rounded-2xl border flex flex-col md:flex-row gap-4 justify-between items-center ${
          isDarkMode 
            ? 'bg-brand-blue-light border-white/5' 
            : 'bg-white border-gray-150 shadow-md'
        }`}>
          {/* Search tool */}
          <div className="relative w-full md:max-w-md font-sans">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
            <input
              type="text"
              placeholder="Search computer science, commerce, MBA, coding, etc..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs sm:text-sm pl-11 pr-4 py-3 rounded-xl border border-gray-200 dark:border-white/10 bg-transparent focus:outline-none focus:ring-2 focus:ring-brand-gold text-gray-700 dark:text-white"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700 p-0.5"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Filtering buttons */}
          <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0 font-display">
            {(['All', 'UG', 'PG'] as const).map((deg) => (
              <button
                key={deg}
                onClick={() => setSelectedDegree(deg)}
                className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold tracking-tight shrink-0 transition-all cursor-pointer ${
                  selectedDegree === deg
                    ? 'bg-brand-gold text-black shadow-md'
                    : isDarkMode
                      ? 'bg-white/5 text-gray-300 hover:bg-white/10'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                {deg === 'All' ? 'All Degrees' : deg === 'UG' ? 'Undergraduate (UG)' : 'Postgraduate (PG)'}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Courses Grid */}
      <section className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {filteredCourses.length === 0 ? (
          <div className="text-center py-16 space-y-4 font-sans max-w-sm mx-auto">
            <AlertCircle className="w-12 h-12 text-brand-gold mx-auto" />
            <h4 className="text-sm font-bold uppercase tracking-wider text-gray-500">No Program Matches!</h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              We couldn't locate any degrees matching "{searchQuery}". Try searching for alternative keywords related to sciences or accounting.
            </p>
            <button 
              onClick={() => { setSearchQuery(''); setSelectedDegree('All'); }}
              className="text-xs font-bold text-brand-gold underline"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredCourses.map((course) => (
              <div
                key={course.id}
                className={`group rounded-3xl overflow-hidden border shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col h-full ${
                  isDarkMode 
                    ? 'bg-brand-blue border-white/5' 
                    : 'bg-white border-gray-150'
                }`}
              >
                {/* Course Thumbnail */}
                <div className="relative h-44 overflow-hidden shrink-0">
                  <img
                    src={course.image}
                    alt={course.name}
                    className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  {/* Badge */}
                  <div className="absolute top-4 left-4 bg-brand-blue/80 backdrop-blur-md px-3.5 py-1 rounded-full text-[10px] text-brand-gold font-bold uppercase tracking-wider font-display border border-brand-gold/20">
                    {course.degree} • {course.duration}
                  </div>
                </div>

                {/* Course Content block */}
                <div className="p-6 flex flex-col flex-1">
                  <span className="text-[10px] font-mono font-bold text-gray-400 block mb-1">{course.code}</span>
                  <h4 className={`text-base sm:text-lg font-bold font-display tracking-tight leading-snug group-hover:text-brand-gold transition-colors duration-200 mb-2 ${
                    isDarkMode ? 'text-white' : 'text-brand-blue'
                  }`}>
                    {course.name}
                  </h4>
                  
                  <p className="text-xs text-gray-500 leading-relaxed font-sans mb-5 line-clamp-3">
                    {course.description}
                  </p>

                  <div className="space-y-3 mb-6 flex-1 font-sans text-xs border-t border-gray-100 dark:border-white/5 pt-4">
                    {/* Eligibility parameters */}
                    <div className="flex gap-2">
                      <GraduationCap className="w-4 h-4 text-brand-gold shrink-0" />
                      <div>
                        <span className="font-semibold block text-[10px] text-gray-400 uppercase tracking-wider">Eligibility Criteria</span>
                        <p className="text-xxs sm:text-xs text-gray-500 font-medium leading-relaxed mt-0.5">
                          {course.eligibility}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Actions footer */}
                  <div className="flex gap-2 pt-4 border-t border-gray-100 dark:border-white/5 text-xxs font-semibold font-display">
                    <button
                      onClick={() => setSelectedCourseDetail(course)}
                      className={`flex-1 text-center py-2.5 rounded-xl border font-bold transition-all cursor-pointer ${
                        isDarkMode
                          ? 'bg-white/5 border-white/5 hover:bg-white/10 text-white'
                          : 'bg-slate-50 border-gray-150 hover:bg-gray-100 text-gray-700'
                      }`}
                    >
                      View Opportunities
                    </button>
                    <button
                      onClick={() => {
                        onPageChange('admissions');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="bg-brand-gold hover:bg-brand-gold-dark text-black px-4 py-2.5 rounded-xl font-bold cursor-pointer"
                    >
                      Apply Seat
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Expand opportunities modal lightbox */}
      {selectedCourseDetail && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in font-sans">
          <div className="bg-white dark:bg-brand-blue border border-brand-gold/30 rounded-3xl p-6 sm:p-8 max-w-xl w-full max-h-[85vh] overflow-y-auto space-y-6 relative shadow-2xl">
            <button
              onClick={() => setSelectedCourseDetail(null)}
              className="absolute top-4 right-4 p-1 rounded-full bg-gray-100 dark:bg-white/10 hover:bg-gray-200 text-gray-500 dark:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1 border-b border-gray-100 dark:border-white/5 pb-4">
              <span className="text-[10px] font-mono text-brand-gold font-bold uppercase tracking-widest">{selectedCourseDetail.code}</span>
              <h3 className="text-lg sm:text-xl font-extrabold font-display text-brand-blue dark:text-white leading-tight">
                Career Horizons: {selectedCourseDetail.name}
              </h3>
            </div>

            <p className="text-xs text-gray-500 leading-relaxed font-sans">
              {selectedCourseDetail.description}
            </p>

            <div className="space-y-3 font-sans text-xs">
              <span className="font-extrabold uppercase tracking-widest text-brand-gold font-display flex items-center gap-1.5 mb-2">
                <TrendingUp className="w-4 h-4 text-brand-gold" /> Key Placement Roles:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {selectedCourseDetail.opportunities.map((opp, i) => (
                  <div key={i} className="flex items-center gap-2 p-2 bg-gray-50 dark:bg-white/5 border border-gray-100 dark:border-white/5 rounded-xl">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span className="text-xxs sm:text-xs font-semibold text-gray-700 dark:text-gray-300">{opp}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-gray-100 dark:border-white/5 flex gap-3 text-xxs font-bold font-display">
              <button
                onClick={handleEnquireClick}
                className="flex-1 bg-brand-gold hover:bg-brand-gold-dark text-black text-center py-3.5 rounded-xl uppercase tracking-wider shadow transform hover:-translate-y-0.5 transition-all cursor-pointer"
              >
                Inquire For This Program
              </button>
              <button
                onClick={() => setSelectedCourseDetail(null)}
                className="px-6 border border-gray-200 dark:border-white/10 text-gray-400 dark:text-white rounded-xl py-3.5"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
