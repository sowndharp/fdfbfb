import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  User, 
  BookOpen, 
  Users, 
  MapPin, 
  CheckCircle, 
  ArrowLeft, 
  ArrowRight, 
  Download, 
  Printer, 
  PhoneCall, 
  FileCheck,
  ShieldCheck,
  ClipboardList
} from 'lucide-react';
import { COURSES, COLLEGE_INFO } from '../data/mockData';

interface RegisterProps {
  isDarkMode: boolean;
}

export default function Register({ isDarkMode }: RegisterProps) {
  // Current active step: 1 (Personal), 2 (Academic), 3 (Guardian), 4 (Summary & Receipt)
  const [activeStep, setActiveStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [registrationSuccess, setRegistrationSuccess] = useState(false);
  const [generatedRegId, setGeneratedRegId] = useState('');
  const [regDate, setRegDate] = useState('');

  // Form states
  const [formData, setFormData] = useState({
    // Step 1: Personal Details
    studentName: '',
    dob: '',
    gender: '',
    mobile: '',
    altMobile: '',
    email: '',
    bloodGroup: '',

    // Step 2: Academic
    lastSchool: '',
    boardOfStudy: 'State Board',
    percentage: '',
    selectedCourseId: '',

    // Step 3: Guardian & Address
    guardianName: '',
    guardianRelation: 'Father',
    guardianContact: '',
    addressLine1: '',
    addressLine2: '',
    city: 'Salem',
    stateId: 'Tamil Nadu',
    pincode: '',
    agreeToTerms: false
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
    // Clear error
    if (formErrors[name]) {
      setFormErrors(prev => {
        const copy = { ...prev };
        delete copy[name];
        return copy;
      });
    }
  };

  // Step validations
  const validateStep = (step: number) => {
    const errors: Record<string, string> = {};
    
    if (step === 1) {
      if (!formData.studentName.trim()) errors.studentName = "Full Name is required.";
      if (!formData.dob) errors.dob = "Date of Birth is required.";
      if (!formData.gender) errors.gender = "Please select gender.";
      if (!formData.mobile.trim() || formData.mobile.length !== 10) {
        errors.mobile = "Enter a valid 10-digit mobile number.";
      }
      if (formData.email.trim() && !/\S+@\S+\.\S+/.test(formData.email)) {
        errors.email = "Please enter a valid email address.";
      }
    } else if (step === 2) {
      if (!formData.lastSchool.trim()) errors.lastSchool = "School name is required.";
      if (!formData.percentage.trim() || isNaN(Number(formData.percentage)) || Number(formData.percentage) < 35 || Number(formData.percentage) > 100) {
        errors.percentage = "Enter a valid aggregate percentage (35 - 100).";
      }
      if (!formData.selectedCourseId) errors.selectedCourseId = "Please select an academic course.";
    } else if (step === 3) {
      if (!formData.guardianName.trim()) errors.guardianName = "Guardian name is required.";
      if (!formData.guardianContact.trim() || formData.guardianContact.length !== 10) {
        errors.guardianContact = "Enter a valid 10-digit guardian contact number.";
      }
      if (!formData.addressLine1.trim()) errors.addressLine1 = "Address Details are required.";
      if (!formData.pincode.trim() || formData.pincode.length !== 6) {
        errors.pincode = "Enter a valid 6-digit PIN code.";
      }
      if (!formData.agreeToTerms) {
        errors.agreeToTerms = "You must agree to college guidelines to register.";
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handle steps
  const nextStep = () => {
    if (validateStep(activeStep)) {
      setActiveStep(prev => prev + 1);
      window.scrollTo({ top: 300, behavior: 'smooth' });
    }
  };

  const prevStep = () => {
    setActiveStep(prev => prev - 1);
    window.scrollTo({ top: 300, behavior: 'smooth' });
  };

  // Find course details
  const selectedCourse = COURSES.find(c => c.id === formData.selectedCourseId);

  // Submit complete registration
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateStep(3)) return;

    setIsSubmitting(true);

    // Generate parameters immediately in order to use them for WhatsApp redirect
    const dateStr = new Date().toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    const randId = `AVS-2026-${Math.floor(100000 + Math.random() * 900000)}`;

    setGeneratedRegId(randId);
    setRegDate(dateStr);

    const targetWhatsAppNum = "916384688085"; // AVS Admission line
    const textMessage = 
      `*AVS ARTS & SCIENCE COLLEGE, SALEM*\n` +
      `*ONLINE REGISTRATION DETAILS*\n` +
      `-----------------------------------------\n` +
      `• *Registration ID:* ${randId}\n` +
      `• *Date:* ${dateStr}\n` +
      `-----------------------------------------\n` +
      `*STUDENT CO-ORDINATES*\n` +
      `• *Name:* ${formData.studentName}\n` +
      `• *DOB:* ${formData.dob}\n` +
      `• *Gender:* ${formData.gender}\n` +
      `• *Mobile:* ${formData.mobile}\n` +
      `• *Alt Mobile:* ${formData.altMobile || 'N/A'}\n` +
      `• *Email:* ${formData.email || 'N/A'}\n` +
      `• *Blood Group:* ${formData.bloodGroup || 'N/A'}\n` +
      `-----------------------------------------\n` +
      `*ACADEMIC ARCHIVE*\n` +
      `• *Selected Course:* ${selectedCourse?.name || 'N/A'}\n` +
      `• *School Attended:* ${formData.lastSchool}\n` +
      `• *Board:* ${formData.boardOfStudy}\n` +
      `• *Aggregate Mark:* ${formData.percentage}%\n` +
      `-----------------------------------------\n` +
      `*GUARDIAN & ADDRESS*\n` +
      `• *Guardian:* ${formData.guardianName} (${formData.guardianRelation})\n` +
      `• *Contact:* ${formData.guardianContact}\n` +
      `• *Address:* ${formData.addressLine1}, ${formData.addressLine2 ? formData.addressLine2 + ', ' : ''}${formData.city}, ${formData.stateId} - ${formData.pincode}\n` +
      `-----------------------------------------\n` +
      `👉 _Ready for registration verification. Please guide on direct admission procedure._`;
    
    const formattedUrl = `https://wa.me/${targetWhatsAppNum}?text=${encodeURIComponent(textMessage)}`;
    
    // Open immediately to bypass popup blockers
    window.open(formattedUrl, '_blank');

    setTimeout(() => {
      setIsSubmitting(false);
      setRegistrationSuccess(true);
      setActiveStep(4);
      window.scrollTo({ top: 200, behavior: 'smooth' });
    }, 600);
  };

  // Format and share details with college administrative desk via WhatsApp APIS
  const handleShareToWhatsApp = () => {
    const targetWhatsAppNum = "916384688085"; // AVS Admission line
    const textMessage = 
      `*AVS ARTS & SCIENCE COLLEGE, SALEM*\n` +
      `*ONLINE REGISTRATION DETAILS*\n` +
      `-----------------------------------------\n` +
      `• *Registration ID:* ${generatedRegId}\n` +
      `• *Date:* ${regDate}\n` +
      `-----------------------------------------\n` +
      `*STUDENT CO-ORDINATES*\n` +
      `• *Name:* ${formData.studentName}\n` +
      `• *DOB:* ${formData.dob}\n` +
      `• *Gender:* ${formData.gender}\n` +
      `• *Mobile:* ${formData.mobile}\n` +
      `• *Alt Mobile:* ${formData.altMobile || 'N/A'}\n` +
      `• *Email:* ${formData.email || 'N/A'}\n` +
      `• *Blood Group:* ${formData.bloodGroup || 'N/A'}\n` +
      `-----------------------------------------\n` +
      `*ACADEMIC ARCHIVE*\n` +
      `• *Selected Course:* ${selectedCourse?.name || 'N/A'}\n` +
      `• *School Attended:* ${formData.lastSchool}\n` +
      `• *Board:* ${formData.boardOfStudy}\n` +
      `• *Aggregate Mark:* ${formData.percentage}%\n` +
      `-----------------------------------------\n` +
      `*GUARDIAN & ADDRESS*\n` +
      `• *Guardian:* ${formData.guardianName} (${formData.guardianRelation})\n` +
      `• *Contact:* ${formData.guardianContact}\n` +
      `• *Address:* ${formData.addressLine1}, ${formData.addressLine2 ? formData.addressLine2 + ', ' : ''}${formData.city}, ${formData.stateId} - ${formData.pincode}\n` +
      `-----------------------------------------\n` +
      `👉 _Ready for registration verification. Please guide on direct admission procedure._`;
    
    const formattedUrl = `https://wa.me/${targetWhatsAppNum}?text=${encodeURIComponent(textMessage)}`;
    window.open(formattedUrl, '_blank');
  };

  // Simple print handler
  const handlePrint = () => {
    window.print();
  };

  return (
    <div id="registration-page-view" className="animate-fade-in mt-[60px] md:mt-[76px] min-h-screen pb-20">
      
      {/* Banner / Title Header */}
      <section className="bg-brand-blue text-white py-16 relative overflow-hidden print:hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-brand-blue via-brand-blue/90 to-brand-blue-accent" />
        <div className="absolute -top-10 -left-10 w-48 h-48 bg-brand-gold/10 rounded-full blur-2xl" />
        <div className="absolute bottom-0 right-0 w-80 h-80 bg-brand-gold/15 rounded-full blur-3xl animate-pulse" />
        
        <div className="max-w-4xl mx-auto px-4 relative z-10 text-center space-y-3">
          <span className="text-xxs font-bold uppercase tracking-widest text-brand-gold px-3 py-1 rounded-full bg-white/10 border border-white/5 font-display select-none">
            Online Registration Portal 2026 - 2027
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold font-display leading-tight tracking-tight">
            AVS Smart Admission Desk
          </h2>
          <p className="text-xs sm:text-sm text-brand-gold-light/90 max-w-xl mx-auto font-sans">
            Avoid paper queues. Fill in student academics, confirm selected program structures, and lock your primary eligibility immediately!
          </p>
        </div>
      </section>

      {/* Main Grid Section */}
      <section className="max-w-4xl mx-auto px-4 mt-12 print:mt-0">
        
        {/* Progress Timeline Header Card (Hidden when printing receipt) */}
        {!registrationSuccess && (
          <div className="mb-10 bg-white dark:bg-brand-blue p-6 rounded-3xl border border-gray-150 dark:border-white/5 shadow-sm print:hidden">
            <div className="flex justify-between items-center relative">
              
              {/* Connector lines behind */}
              <div className="absolute left-[8%] right-[8%] top-1/2 h-1 bg-gray-100 dark:bg-white/5 -translate-y-2 z-0" />
              <div 
                className="absolute left-[8%] top-1/2 h-1 bg-brand-gold -translate-y-2 z-0 transition-all duration-300" 
                style={{ width: `${((activeStep - 1) / 2) * 84}%` }}
              />

              {/* Step dots */}
              {[
                { step: 1, label: "Personal Details", icon: User },
                { step: 2, label: "Academics", icon: BookOpen },
                { step: 3, label: "Guardian Details", icon: Users }
              ].map((item) => {
                const IconComponent = item.icon;
                const isCompleted = activeStep > item.step;
                const isActive = activeStep === item.step;
                
                return (
                  <div key={item.step} className="flex flex-col items-center z-10 relative">
                    <div 
                      className={`w-10 h-10 rounded-full flex items-center justify-center border font-display transition-all duration-300 ${
                        isCompleted 
                          ? 'bg-brand-gold border-brand-gold text-black' 
                          : isActive
                            ? 'bg-brand-blue-accent border-brand-gold text-brand-gold font-bold scale-110 shadow-lg'
                            : 'bg-white dark:bg-brand-blue-light border-gray-200 dark:border-white/10 text-gray-400'
                      }`}
                    >
                      {isCompleted ? <CheckCircle className="w-5 h-5 text-black" /> : <IconComponent className="w-4 h-4" />}
                    </div>
                    <span className={`mt-2 font-display text-[10px] font-bold uppercase tracking-wider ${
                      isActive ? 'text-brand-gold' : 'text-gray-400'
                    }`}>
                      {item.label}
                    </span>
                  </div>
                );
              })}

            </div>
          </div>
        )}

        {/* Dynamic Form Board */}
        <div className={`rounded-3xl border ${
          isDarkMode 
            ? 'bg-brand-blue border-white/5 text-white' 
            : 'bg-white border-gray-150 text-gray-800'
        } shadow-xl overflow-hidden`}>
          
          {/* Main Form Elements */}
          <form onSubmit={handleSubmit} className="p-6 sm:p-10">
            
            {/* STEP 1: Personal Coordinates */}
            {activeStep === 1 && (
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="border-b border-gray-100 dark:border-white/5 pb-4">
                  <h3 className="text-lg font-bold font-display uppercase tracking-tight flex items-center gap-2 text-brand-gold">
                    <User className="w-5 h-5 text-brand-gold" /> Step 1: Personal Information
                  </h3>
                  <p className="text-xxs text-gray-400">Provide official details as recorded in school certificates.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 font-sans text-xs">
                  
                  {/* Student Full Name */}
                  <div className="space-y-1.5Col">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Student Full Name *</label>
                    <input
                      type="text"
                      name="studentName"
                      required
                      placeholder="Ex: VIMAL PRAKASH S"
                      value={formData.studentName}
                      onChange={handleInputChange}
                      className={`w-full p-3 rounded-xl border bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold ${
                        formErrors.studentName 
                          ? 'border-red-500 ring-2 ring-red-500/20' 
                          : 'border-gray-250 dark:border-white/10'
                      }`}
                    />
                    {formErrors.studentName && (
                      <p className="text-red-500 text-[10px] font-semibold mt-1">{formErrors.studentName}</p>
                    )}
                  </div>

                  {/* Date of Birth */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Date of Birth *</label>
                    <input
                      type="date"
                      name="dob"
                      required
                      value={formData.dob}
                      onChange={handleInputChange}
                      className={`w-full p-3 rounded-xl border bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold text-gray-450 ${
                        formErrors.dob 
                          ? 'border-red-500 ring-2 ring-red-500/20' 
                          : 'border-gray-250 dark:border-white/10'
                      }`}
                    />
                    {formErrors.dob && (
                      <p className="text-red-500 text-[10px] font-semibold mt-1">{formErrors.dob}</p>
                    )}
                  </div>

                  {/* Gender Choice */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Gender *</label>
                    <select
                      name="gender"
                      required
                      value={formData.gender}
                      onChange={handleInputChange}
                      className={`w-full p-3 rounded-xl border bg-white dark:bg-brand-blue text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold ${
                        formErrors.gender 
                          ? 'border-red-500' 
                          : 'border-gray-250 dark:border-white/10'
                      }`}
                    >
                      <option value="">-- Choose Gender --</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Other">Other</option>
                    </select>
                    {formErrors.gender && (
                      <p className="text-red-500 text-[10px] font-semibold mt-1">{formErrors.gender}</p>
                    )}
                  </div>

                  {/* Blood Group */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Blood Group</label>
                    <select
                      name="bloodGroup"
                      value={formData.bloodGroup}
                      onChange={handleInputChange}
                      className="w-full p-3 rounded-xl border border-gray-250 dark:border-white/10 bg-white dark:bg-brand-blue text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold"
                    >
                      <option value="">-- Optional --</option>
                      <option value="A+">A+</option>
                      <option value="A-">A-</option>
                      <option value="B+">B+</option>
                      <option value="B-">B-</option>
                      <option value="O+">O+</option>
                      <option value="O-">O-</option>
                      <option value="AB+">AB+</option>
                      <option value="AB-">AB-</option>
                    </select>
                  </div>

                  {/* Contact Number (Mobile) */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Mobile Number *</label>
                    <input
                      type="tel"
                      name="mobile"
                      required
                      maxLength={10}
                      placeholder="10 Digit Student/Primary Phone"
                      value={formData.mobile}
                      onChange={handleInputChange}
                      className={`w-full p-3 rounded-xl border bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold ${
                        formErrors.mobile
                          ? 'border-red-500 ring-2 ring-red-500/20'
                          : 'border-gray-250 dark:border-white/10'
                      }`}
                    />
                    {formErrors.mobile && (
                      <p className="text-red-500 text-[10px] font-semibold mt-1">{formErrors.mobile}</p>
                    )}
                  </div>

                  {/* Alternate/Parents Contact Number */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Alternate Number (WhatsApp)</label>
                    <input
                      type="tel"
                      name="altMobile"
                      maxLength={10}
                      placeholder="For immediate updates"
                      value={formData.altMobile}
                      onChange={handleInputChange}
                      className="w-full p-3 rounded-xl border border-gray-250 dark:border-white/10 bg-transparent text-sm focus:outline-none"
                    />
                  </div>

                  {/* Student Email Address */}
                  <div className="space-y-1.5 md:col-span-2">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Student Email Address</label>
                    <input
                      type="email"
                      name="email"
                      placeholder="e.g., studentname@gmail.com"
                      value={formData.email}
                      onChange={handleInputChange}
                      className={`w-full p-3 rounded-xl border bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold ${
                        formErrors.email
                          ? 'border-red-500'
                          : 'border-gray-250 dark:border-white/10'
                      }`}
                    />
                    {formErrors.email && (
                      <p className="text-red-500 text-[10px] font-semibold mt-1">{formErrors.email}</p>
                    )}
                  </div>

                </div>

                {/* Footer buttons row */}
                <div className="pt-6 border-t border-gray-100 dark:border-white/5 flex justify-end">
                  <button
                    type="button"
                    onClick={nextStep}
                    className="inline-flex items-center gap-1.5 bg-brand-gold hover:bg-brand-gold-dark text-black px-6 py-3 rounded-xl font-extrabold text-xs uppercase tracking-wider font-display shadow-md transition-all cursor-pointer"
                  >
                    Next Panel
                    <ArrowRight className="w-4 h-4 text-black" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* STEP 2: Academic details */}
            {activeStep === 2 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="border-b border-gray-100 dark:border-white/5 pb-4">
                  <h3 className="text-lg font-bold font-display uppercase tracking-tight flex items-center gap-2 text-brand-gold">
                    <BookOpen className="w-5 h-5 text-brand-gold" /> Step 2: Academic Profile
                  </h3>
                  <p className="text-xxs text-gray-400">Detail your secondary qualification matrices to determine merit parameters.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 font-sans text-xs">
                  
                  {/* Name of Last Attended School */}
                  <div className="space-y-1.5 md:col-span-2">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Secondary High School Name & Location *</label>
                    <input
                      type="text"
                      name="lastSchool"
                      required
                      placeholder="e.g., Government Hr. Sec School, Ramalingapuram"
                      value={formData.lastSchool}
                      onChange={handleInputChange}
                      className={`w-full p-3 rounded-xl border bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold ${
                        formErrors.lastSchool 
                          ? 'border-red-500' 
                          : 'border-gray-250 dark:border-white/10'
                      }`}
                    />
                    {formErrors.lastSchool && (
                      <p className="text-red-500 text-[10px] font-semibold mt-1">{formErrors.lastSchool}</p>
                    )}
                  </div>

                  {/* Board Of Study */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Board of Examination *</label>
                    <select
                      name="boardOfStudy"
                      required
                      value={formData.boardOfStudy}
                      onChange={handleInputChange}
                      className="w-full p-3 rounded-xl border border-gray-250 dark:border-white/10 bg-white dark:bg-brand-blue text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold"
                    >
                      <option value="State Board">Tamil Nadu State Board</option>
                      <option value="CBSE">CBSE (Central Board)</option>
                      <option value="ICSE">ICSE / ISC</option>
                      <option value="Other">Other Board</option>
                    </select>
                  </div>

                  {/* Percentage score */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">XII standard Aggregate Score (%) *</label>
                    <input
                      type="text"
                      name="percentage"
                      maxLength={5}
                      required
                      placeholder="e.g., 88.5 or 92"
                      value={formData.percentage}
                      onChange={handleInputChange}
                      className={`w-full p-3 rounded-xl border bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold ${
                        formErrors.percentage
                          ? 'border-red-500'
                          : 'border-gray-250 dark:border-white/10'
                      }`}
                    />
                    {formErrors.percentage && (
                      <p className="text-red-500 text-[10px] font-semibold mt-1">{formErrors.percentage}</p>
                    )}
                  </div>

                  {/* TARGET COURSE SELECTION */}
                  <div className="space-y-1.5 md:col-span-2">
                    <label className="font-bold text-amber-500 uppercase tracking-wider block font-display">Select Academic Course applied for *</label>
                    <select
                      name="selectedCourseId"
                      required
                      value={formData.selectedCourseId}
                      onChange={handleInputChange}
                      className={`w-full p-3.5 rounded-xl border dark:bg-brand-blue text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold font-semibold ${
                        formErrors.selectedCourseId
                          ? 'border-red-500'
                          : 'border-gray-300 dark:border-white/15'
                      }`}
                    >
                      <option value="">-- Choose Program --</option>
                      <optgroup label="Undergraduate (UG) Programs">
                        {COURSES.filter(c => c.degree === 'UG').map(course => (
                          <option key={course.id} value={course.id}>
                            {course.name} ({course.duration})
                          </option>
                        ))}
                      </optgroup>
                      <optgroup label="Postgraduate (PG) Programs">
                        {COURSES.filter(c => c.degree === 'PG').map(course => (
                          <option key={course.id} value={course.id}>
                            {course.name} ({course.duration})
                          </option>
                        ))}
                      </optgroup>
                    </select>
                    {formErrors.selectedCourseId && (
                      <p className="text-red-500 text-[10px] font-semibold mt-1">{formErrors.selectedCourseId}</p>
                    )}

                    {selectedCourse && (
                      <div className="mt-4 p-4 rounded-2xl bg-brand-gold/10 border border-brand-gold/25 font-sans space-y-2">
                        <div className="flex justify-between items-center text-xxs font-bold text-brand-gold uppercase tracking-widest">
                          <span>Eligibility Confirmed</span>
                          <span>{selectedCourse.feePerSemester} / SEMESTER</span>
                        </div>
                        <p className="text-[11px] leading-relaxed text-gray-500 dark:text-gray-300">
                          {selectedCourse.description}
                        </p>
                      </div>
                    )}
                  </div>

                </div>

                {/* Navigation Controls */}
                <div className="pt-6 border-t border-gray-100 dark:border-white/5 flex justify-between">
                  <button
                    type="button"
                    onClick={prevStep}
                    className="inline-flex items-center gap-1.5 px-5 py-3 rounded-xl border border-gray-300 dark:border-white/10 text-gray-400 hover:text-white transition-all cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={nextStep}
                    className="inline-flex items-center gap-1.5 bg-brand-gold hover:bg-brand-gold-dark text-black px-6 py-3 rounded-xl font-extrabold text-xs uppercase tracking-wider font-display shadow-md transition-all cursor-pointer"
                  >
                    Next Panel
                    <ArrowRight className="w-4 h-4 text-black" />
                  </button>
                </div>
              </motion.div>
            )}

            {/* STEP 3: Guardian details & address confirmation */}
            {activeStep === 3 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="border-b border-gray-100 dark:border-white/5 pb-4">
                  <h3 className="text-lg font-bold font-display uppercase tracking-tight flex items-center gap-2 text-brand-gold">
                    <Users className="w-5 h-5 text-brand-gold" /> Step 3: Guardian & Contact Details
                  </h3>
                  <p className="text-xxs text-gray-400">Communication coordinates for registration billing and counselling call invites.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 font-sans text-xs">
                  
                  {/* Guardian Name */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Guardian Name *</label>
                    <input
                      type="text"
                      name="guardianName"
                      required
                      placeholder="Father or Mother name"
                      value={formData.guardianName}
                      onChange={handleInputChange}
                      className={`w-full p-3 rounded-xl border bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold ${
                        formErrors.guardianName 
                          ? 'border-red-500' 
                          : 'border-gray-250 dark:border-white/10'
                      }`}
                    />
                    {formErrors.guardianName && (
                      <p className="text-red-500 text-[10px] font-semibold mt-1">{formErrors.guardianName}</p>
                    )}
                  </div>

                  {/* Relationship */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Relationship *</label>
                    <select
                      name="guardianRelation"
                      value={formData.guardianRelation}
                      onChange={handleInputChange}
                      className="w-full p-3 rounded-xl border border-gray-250 dark:border-white/10 bg-white dark:bg-brand-blue text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold"
                    >
                      <option value="Father">Father</option>
                      <option value="Mother">Mother</option>
                      <option value="Brother">Brother</option>
                      <option value="Sister">Sister</option>
                      <option value="Other">Other Guardian</option>
                    </select>
                  </div>

                  {/* Guardian Contact phone */}
                  <div className="space-y-1.5 md:col-span-2">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Guardian Phone / Contact Number *</label>
                    <input
                      type="tel"
                      name="guardianContact"
                      required
                      maxLength={10}
                      placeholder="10 Digit Guardian Number"
                      value={formData.guardianContact}
                      onChange={handleInputChange}
                      className={`w-full p-3 rounded-xl border bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold ${
                        formErrors.guardianContact
                          ? 'border-red-500 ring-2 ring-red-500/20'
                          : 'border-gray-250 dark:border-white/10'
                      }`}
                    />
                    {formErrors.guardianContact && (
                      <p className="text-red-500 text-[10px] font-semibold mt-1">{formErrors.guardianContact}</p>
                    )}
                  </div>

                  {/* Address line 1 */}
                  <div className="space-y-1.5 md:col-span-2">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Permanent Address Detail (Door No, Street Name) *</label>
                    <input
                      type="text"
                      name="addressLine1"
                      required
                      placeholder="Door No, Street coordinates, Village/Town"
                      value={formData.addressLine1}
                      onChange={handleInputChange}
                      className={`w-full p-3 rounded-xl border bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold ${
                        formErrors.addressLine1
                          ? 'border-red-500'
                          : 'border-gray-250 dark:border-white/10'
                      }`}
                    />
                    {formErrors.addressLine1 && (
                      <p className="text-red-500 text-[10px] font-semibold mt-1">{formErrors.addressLine1}</p>
                    )}
                  </div>

                  {/* Address line 2 */}
                  <div className="space-y-1.5 md:col-span-2">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Area Address (Line 2)</label>
                    <input
                      type="text"
                      name="addressLine2"
                      placeholder="Taluk, Landmark optional"
                      value={formData.addressLine2}
                      onChange={handleInputChange}
                      className="w-full p-3 rounded-xl border border-gray-250 dark:border-white/10 bg-transparent text-sm"
                    />
                  </div>

                  {/* City */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">City / Town *</label>
                    <input
                      type="text"
                      name="city"
                      required
                      value={formData.city}
                      onChange={handleInputChange}
                      className="w-full p-3 rounded-xl border border-gray-250 dark:border-white/10 bg-transparent text-sm"
                    />
                  </div>

                  {/* PIN code */}
                  <div className="space-y-1.5">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Permanent Pincode (6 Digits) *</label>
                    <input
                      type="text"
                      name="pincode"
                      maxLength={6}
                      required
                      placeholder="e.g. 636106"
                      value={formData.pincode}
                      onChange={handleInputChange}
                      className={`w-full p-3 rounded-xl border bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold ${
                        formErrors.pincode
                          ? 'border-red-500'
                          : 'border-gray-250 dark:border-white/10'
                      }`}
                    />
                    {formErrors.pincode && (
                      <p className="text-red-500 text-[10px] font-semibold mt-1">{formErrors.pincode}</p>
                    )}
                  </div>

                  {/* College Terms checklist */}
                  <div className="md:col-span-2 pt-4">
                    <label className="flex items-start gap-3 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        name="agreeToTerms"
                        checked={formData.agreeToTerms}
                        onChange={handleInputChange}
                        className="mt-1 accent-brand-gold text-brand-blue"
                      />
                      <span className="text-[11px] text-gray-400 leading-normal">
                        I hereby declare that all provided high school matrices, coordinates and personal descriptors are authentic to my real records. I agree to comply with Periyar University regulations and AVS administrative guidelines.
                      </span>
                    </label>
                    {formErrors.agreeToTerms && (
                      <p className="text-red-500 text-[10px] font-semibold mt-2">{formErrors.agreeToTerms}</p>
                    )}
                  </div>

                </div>

                {/* Final Navigation Actions */}
                <div className="pt-6 border-t border-gray-100 dark:border-white/5 flex justify-between">
                  <button
                    type="button"
                    onClick={prevStep}
                    className="inline-flex items-center gap-1.5 px-5 py-3 rounded-xl border border-gray-300 dark:border-white/10 text-gray-400 hover:text-white transition-all cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    Back
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="inline-flex items-center gap-1.5 bg-emerald-500 hover:bg-emerald-600 text-white px-8 py-3.5 rounded-xl font-extrabold text-xs uppercase tracking-widest font-display shadow-lg transition-all transform hover:-translate-y-0.5 cursor-pointer disabled:opacity-50"
                  >
                    {isSubmitting ? "Locking Seat..." : "Submit Registration Check"}
                  </button>
                </div>
              </motion.div>
            )}

            {/* STEP 4: Success & Registration Receipt View */}
            {activeStep === 4 && registrationSuccess && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="space-y-8"
              >
                {/* Header Banner - Succces notification */}
                <div className="text-center space-y-3 print:hidden">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-500/25 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto shadow-inner animate-bounce text-xl">
                    <CheckCircle className="w-10 h-10" />
                  </div>
                  <h4 className="text-xl font-extrabold font-display text-emerald-500 uppercase tracking-tight">
                    Registration Submitted Successfully!
                  </h4>
                  <p className="text-xs text-gray-400 max-w-lg mx-auto">
                    Your digital registration token is verified. Please print details or keep receipt card copy handy for counselor interviews.
                  </p>
                </div>

                {/* VISUAL PRINT COMPLIANT RECEIPT CARD */}
                <div 
                  id="avs-printed-receipt" 
                  className={`p-6 sm:p-10 rounded-2xl border ${
                    isDarkMode 
                      ? 'bg-[#101c30] border-white/10 text-gray-200' 
                      : 'bg-white border-gray-300 text-gray-800'
                  } font-mono text-xs sm:text-xs relative overflow-hidden`}
                >
                  {/* Decorative background logo */}
                  <div className="absolute right-6 bottom-6 opacity-5 pointer-events-none">
                    <FileCheck className="w-64 h-64" />
                  </div>

                  {/* Campus Header row */}
                  <div className="text-center pb-6 border-b border-dashed border-gray-300 dark:border-white/15 space-y-1">
                    <h2 className="font-display font-black text-sm uppercase tracking-widest text-brand-gold">
                      {COLLEGE_INFO.name}
                    </h2>
                    <p className="text-[10px] uppercase text-gray-400">{COLLEGE_INFO.location}</p>
                    <p className="text-[9px] text-gray-500">{COLLEGE_INFO.affiliation} • {COLLEGE_INFO.accreditation}</p>
                    <h3 className="text-[10px] uppercase font-bold text-emerald-500 bg-emerald-500/10 px-4 py-1.5 rounded-full inline-block mt-3 border border-emerald-500/25">
                      ★ Admission Registration Receipt 2026 ★
                    </h3>
                  </div>

                  {/* Token Coordinates Grid */}
                  <div className="py-6 grid grid-cols-1 sm:grid-cols-2 gap-4 border-b border-dashed border-gray-300 dark:border-white/15 text-[11px] sm:text-xs text-left">
                    <div>
                      <span className="text-gray-400 block font-semibold">REGISTRATION ID</span>
                      <strong className="text-brand-gold font-display text-sm uppercase">{generatedRegId}</strong>
                    </div>
                    <div>
                      <span className="text-gray-400 block font-semibold">TOKEN GENERATION DATE</span>
                      <strong className="text-gray-400 block font-semibold">{regDate}</strong>
                    </div>
                    <div>
                      <span className="text-gray-400 block font-semibold">CHOSEN PROGRAM</span>
                      <strong className="text-brand-gold block uppercase text-[11px]">{selectedCourse?.name || 'Computer Science'}</strong>
                    </div>
                    <div>
                      <span className="text-gray-400 block font-semibold">TUITION FEE SEMESTER METER</span>
                      <strong className="text-emerald-500 block">{selectedCourse?.feePerSemester || '¥18,000'} per sem</strong>
                    </div>
                  </div>

                  {/* Student Coordinates table */}
                  <div className="py-6 border-b border-dashed border-gray-300 dark:border-white/15 space-y-3.5 text-left text-[11px]">
                    <span className="text-gray-400 font-extrabold uppercase tracking-wider block text-xxs">I. Student Coordinates</span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div><span className="text-gray-400">FullName:</span> <strong>{formData.studentName.toUpperCase()}</strong></div>
                      <div><span className="text-gray-400">Date of Birth:</span> <strong>{formData.dob}</strong></div>
                      <div><span className="text-gray-400">Gender / Blood:</span> <strong>{formData.gender} ({formData.bloodGroup || 'N/A'})</strong></div>
                      <div><span className="text-gray-400">Student Phone:</span> <strong>{formData.mobile}</strong></div>
                      <div><span className="text-gray-400">Email Address:</span> <strong className="lowercase">{formData.email || 'N/A'}</strong></div>
                    </div>
                  </div>

                  {/* Academic performance and guardian */}
                  <div className="py-6 border-b border-dashed border-gray-300 dark:border-white/15 space-y-3.5 text-left text-[11px]">
                    <span className="text-gray-400 font-extrabold uppercase tracking-wider block text-xxs">II. Academic Matrix</span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div><span className="text-gray-400">Last School:</span> <strong>{formData.lastSchool.toUpperCase()}</strong></div>
                      <div><span className="text-gray-400">Board / Aggregate:</span> <strong>{formData.boardOfStudy} ({formData.percentage}%)</strong></div>
                      <div><span className="text-gray-400">Guardian Name:</span> <strong>{formData.guardianName} ({formData.guardianRelation})</strong></div>
                      <div><span className="text-gray-400">Guardian Contact:</span> <strong>{formData.guardianContact}</strong></div>
                    </div>
                    <div>
                      <span className="text-gray-400 block pb-1">Permanent Location Details:</span>
                      <strong>
                        {formData.addressLine1}, {formData.addressLine2 ? formData.addressLine2 + ', ' : ''}{formData.city}, {formData.pincode}
                      </strong>
                    </div>
                  </div>

                  {/* Signatures placeholder */}
                  <div className="pt-8 flex justify-between items-end text-xxs text-gray-500 text-left">
                    <div>
                      <p className="pb-10 font-bold">STUDENT SIGNATURE</p>
                      <span className="border-t border-gray-300 pt-1 uppercase">VIMAL PRAKASH S</span>
                    </div>
                    <div className="text-right">
                      <p className="pb-10 font-bold">COUNSELLING DESK SEAL</p>
                      <span className="border-t border-gray-300 pt-1">AVS REGISTRAR OFFICE</span>
                    </div>
                  </div>

                  {/* Interactive advice card banner */}
                  <div className="mt-8 p-4 rounded-xl bg-orange-500/10 border border-orange-500/25 text-amber-500 text-[10px] text-center font-sans tracking-wide leading-relaxed print:hidden">
                    ⚠️ <strong>Next Step Directive:</strong> Ensure you send these token coordinates directly to the Admission Cell on WhatsApp using the green share button below; this triggers immediate priority verification!
                  </div>
                </div>

                {/* Print and share Control button bar */}
                <div className="flex flex-col sm:flex-row justify-center items-center gap-4 pt-4 print:hidden">
                  
                  {/* Share to WhatsApp */}
                  <button
                    type="button"
                    onClick={handleShareToWhatsApp}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold text-xs py-3.5 px-6 rounded-xl uppercase tracking-wider font-display shadow-md transition-all cursor-pointer"
                  >
                    <PhoneCall className="w-4 h-4" />
                    Share with Admission Desk (WhatsApp)
                  </button>

                  {/* Print Document PDF */}
                  <button
                    type="button"
                    onClick={handlePrint}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-brand-blue-accent hover:bg-brand-blue-accent/90 text-white font-semibold text-xs py-3.5 px-6 rounded-xl uppercase tracking-wider font-display border border-white/10 transition-all cursor-pointer"
                  >
                    <Printer className="w-4 h-4" />
                    Print / Save Receipt Card
                  </button>

                  {/* Back/Reset */}
                  <button
                    type="button"
                    onClick={() => {
                      setRegistrationSuccess(false);
                      setActiveStep(1);
                      setFormData({
                        studentName: '',
                        dob: '',
                        gender: '',
                        mobile: '',
                        altMobile: '',
                        email: '',
                        bloodGroup: '',
                        lastSchool: '',
                        boardOfStudy: 'State Board',
                        percentage: '',
                        selectedCourseId: '',
                        guardianName: '',
                        guardianRelation: 'Father',
                        guardianContact: '',
                        addressLine1: '',
                        addressLine2: '',
                        city: 'Salem',
                        stateId: 'Tamil Nadu',
                        pincode: '',
                        agreeToTerms: false
                      });
                    }}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl border border-gray-300 dark:border-white/10 text-gray-400 hover:text-white transition-all cursor-pointer"
                  >
                    Register Another Candidate
                  </button>

                </div>

              </motion.div>
            )}

          </form>

          {/* Verification terms footer indicator */}
          {!registrationSuccess && (
            <div className="bg-gray-50/50 dark:bg-brand-blue-light/30 border-t border-gray-150 dark:border-white/5 p-4 flex flex-col sm:flex-row justify-between items-center gap-2.5 text-xxs tracking-wider font-sans text-gray-400 print:hidden select-none">
              <span className="flex items-center gap-1.5 uppercase font-bold text-gray-400">
                <ShieldCheck className="w-4 h-4 text-emerald-500" /> End-to-End Encryption Secured
              </span>
              <span>
                🔒 Information audited via Periyar Board Admissions Rules
              </span>
            </div>
          )}

        </div>

        {/* Quick FAQ / Contacts card */}
        {!registrationSuccess && (
          <div className="mt-8 bg-brand-gold/10 border border-brand-gold/20 p-5 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-4 font-sans text-xs print:hidden">
            <div className="flex items-center gap-3 text-left">
              <div className="p-2.5 rounded-2xl bg-brand-gold/10 text-brand-gold shrink-0">
                <ClipboardList className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-brand-gold font-display uppercase tracking-wider">Need offline counseling assistance?</h4>
                <p className="text-gray-400 text-xxs leading-normal mt-0.5">Skip online registration and visit college administration directly in Salem.</p>
              </div>
            </div>
            <a 
              href={`tel:${COLLEGE_INFO.phone}`} 
              className="inline-flex items-center gap-1.5 bg-brand-gold text-black font-extrabold px-4.5 py-2.5 rounded-xl text-xxs uppercase tracking-wider font-display hover:bg-brand-gold-dark shrink-0"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              Call Hub
            </a>
          </div>
        )}

      </section>

    </div>
  );
}
