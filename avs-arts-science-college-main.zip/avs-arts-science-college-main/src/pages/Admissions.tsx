import React, { useState } from 'react';
import { 
  ClipboardCheck, 
  HelpCircle, 
  Table, 
  Coins, 
  Download, 
  ChevronDown, 
  CheckCircle2, 
  FileSpreadsheet,
  Calendar,
  PhoneCall
} from 'lucide-react';
import { COLLEGE_INFO, FAQS, COURSES } from '../data/mockData';

interface AdmissionsProps {
  isDarkMode: boolean;
}

export default function Admissions({ isDarkMode }: AdmissionsProps) {
  // Enquiry form state
  const [formData, setFormData] = useState({
    studentName: '',
    email: '',
    mobile: '',
    selectedCourse: '',
    state: '',
    message: ''
  });
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [downloadingBrochure, setDownloadingBrochure] = useState(false);
  const [faqExpandedIdx, setFaqExpandedIdx] = useState<number | null>(null);

  const admissionSteps = [
    { num: "01", title: "Enquiry or Consultation", text: "Submit your details on our digital portal or walk directly into the Salem counseling center to consult an academic advisor." },
    { num: "02", title: "Transcripts & Verification", text: "Furnish your original secondary/higher board graduation marksheets, transfer certificate, and community certificate for assessment." },
    { num: "03", title: "Merit Rank Evaluation", text: "The college admission panel compiles student merit scores to calculate eligibility and allocate tuition waivers." },
    { num: "04", title: "Fee Clearance & Seat Locking", text: "Deposit the primary semester commission fee to secure your college roll and finalize institutional alignment." }
  ];

  const scholarshipParameters = [
    { rank: "Class XII Score Board > 95%", reward: "50% Tuition Waiver", eligibility: "Applicable for all semesters with clean academic scores" },
    { rank: "Class XII Score Board 90% - 95%", reward: "25% Tuition Waiver", eligibility: "Applicable for all semesters on maintaining > 7.5 CGPA" },
    { rank: "National/State Level Sports Champion", reward: "100% Sports Waiver", eligibility: "Must represent the college athletic clubs continuously" },
    { rank: "Socio-Economic Minority Support", reward: "Special Annual Endowment", eligibility: "Assigned by trust trustees based on yearly background reviews" }
  ];

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.studentName || !formData.mobile || !formData.selectedCourse) {
      alert("Please fill in Student Name, Mobile Number, and Selected Course field.");
      return;
    }

    // Capture details and build premium WhatsApp API link
    const targetWhatsAppNum = "916384688085";
    const textMessage = 
      `*AVS ARTS & SCIENCE COLLEGE, SALEM*\n` +
      `*Admission Inquiry 2026-27*\n\n` +
      `• *Student Name:* ${formData.studentName}\n` +
      `• *Mobile Number:* ${formData.mobile}\n` +
      `• *Email Address:* ${formData.email || 'N/A'}\n` +
      `• *Selected Course:* ${formData.selectedCourse}\n` +
      `• *State/Region:* ${formData.state || 'Tamil Nadu'}\n` +
      `• *Brief Message/Query:* ${formData.message || 'N/A'}\n\n` +
      `_Enquiry submitted successfully! Ready to connect with the counseling team._`;
    
    const formattedUrl = `https://wa.me/${targetWhatsAppNum}?text=${encodeURIComponent(textMessage)}`;

    setFormSubmitted(true);

    // Open WhatsApp immediately
    window.open(formattedUrl, '_blank');

    setTimeout(() => {
      setFormSubmitted(false);
      setFormData({
        studentName: '',
        email: '',
        mobile: '',
        selectedCourse: '',
        state: '',
        message: ''
      });
    }, 4500);
  };

  const handleBrochureDownload = () => {
    setDownloadingBrochure(true);
    setTimeout(() => {
      setDownloadingBrochure(false);
      // Simulate download notification click
      const link = document.createElement('a');
      link.href = '#';
      link.setAttribute('download', 'AVS_College_Brochure_2026.pdf');
      alert("✅ AVS Arts & Science College Brochure & Prospectus 2026-27 has been compiled. Downloading will now begin in background!");
    }, 1500);
  };

  const toggleFAQ = (idx: number) => {
    setFaqExpandedIdx(faqExpandedIdx === idx ? null : idx);
  };

  return (
    <div id="admissions-view" className="animate-fade-in mt-[60px] md:mt-[76px]">
      
      {/* Mini Title Jumbotron */}
      <section className="bg-brand-blue text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-brand-blue via-brand-blue/90 to-brand-blue-accent" />
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-gold/15 rounded-full blur-3xl" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-3">
          <span className="text-xxs font-bold uppercase tracking-widest text-brand-gold px-3.5 py-1.5 rounded-full bg-white/10 border border-white/5 font-display select-none">
            Admissions Desk 2026-27
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold font-display leading-none tracking-tight">
            Shape Your Academic Destination
          </h2>
          <p className="text-xs sm:text-sm text-brand-gold-light/80 max-w-2xl mx-auto font-sans">
            Admissions officially open for all undergraduate and postgraduate scientific and commerce divisions.
          </p>
        </div>
      </section>

      {/* Guide Steps to Apply */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-2 mb-16">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display flex items-center justify-center gap-1.5">
            <ClipboardCheck className="w-4 h-4 text-brand-gold" /> Step-by-Step Procedure
          </span>
          <h3 className={`text-3xl font-extrabold tracking-tight font-display ${
            isDarkMode ? 'text-white' : 'text-brand-blue'
          }`}>
            How to Submit Enrollment Details
          </h3>
          <p className="text-xs text-gray-400 max-w-md mx-auto">
            Review our straightforward 4-step registration parameters designed to make your entry process extremely seamless.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 font-sans">
          {admissionSteps.map((step, idx) => (
            <div 
              key={idx}
              className={`p-6 rounded-3xl border relative transition-all hover:scale-101 ${
                isDarkMode 
                  ? 'bg-brand-blue-light border-white/5 text-gray-300' 
                  : 'bg-white border-gray-150 shadow-sm text-gray-650'
              }`}
            >
              <div className="absolute top-4 right-4 text-3xl font-extrabold font-display opacity-15 text-brand-gold">
                {step.num}
              </div>
              <div className="w-10 h-10 rounded-2xl bg-brand-gold/10 text-brand-gold flex items-center justify-center font-bold text-sm mb-4">
                {step.num}
              </div>
              <h4 className={`text-sm font-bold font-display uppercase tracking-tight mb-2 ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                {step.title}
              </h4>
              <p className="text-xs text-gray-500 leading-relaxed">
                {step.text}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Fee Structure Table Section */}
      <section className={`py-20 border-t border-b ${
        isDarkMode 
          ? 'bg-brand-blue-light/10 border-white/5' 
          : 'bg-slate-50 border-gray-100'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 mb-12">
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display flex items-center gap-1">
                <Table className="w-4 h-4 text-brand-gold" /> Clear cost analysis
              </span>
              <h3 className={`text-3xl font-extrabold tracking-tight font-display ${
                isDarkMode ? 'text-white' : 'text-brand-blue'
              }`}>
                Comprehensive Fee Structure
              </h3>
              <p className="text-xs text-gray-400">
                Transparent tuition fees for the {new Date().getFullYear()}-{new Date().getFullYear()+1} academic session. 
              </p>
            </div>
            
            <button
              onClick={handleBrochureDownload}
              disabled={downloadingBrochure}
              className="inline-flex items-center gap-1.5 bg-brand-gold hover:bg-brand-gold-dark text-black font-bold text-xs py-3 px-6 rounded-xl shadow-md transition-all shrink-0 cursor-pointer disabled:opacity-50"
            >
              <Download className="w-4 h-4 animate-bounce" />
              {downloadingBrochure ? "Compiling PDF..." : "Download Full Brochure PDF"}
            </button>
          </div>

          {/* Table Container */}
          <div className="bg-white dark:bg-brand-blue rounded-3xl border border-gray-200 dark:border-white/5 overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-brand-blue text-white text-xs sm:text-sm font-display font-bold uppercase tracking-wider border-b border-white/10">
                    <th className="py-4 px-6">Course Name</th>
                    <th className="py-4 px-6">Degree Level</th>
                    <th className="py-4 px-6">Normal Duration</th>
                    <th className="py-4 px-6 text-right">Tuition Fee per Semester</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-white/5 text-xs sm:text-sm">
                  {COURSES.map((course) => (
                    <tr 
                      key={course.id}
                      className="hover:bg-slate-50 dark:hover:bg-brand-blue-light/50 transition-colors font-sans text-gray-500 dark:text-gray-300"
                    >
                      <td className={`py-4 px-6 font-bold font-display ${isDarkMode ? 'text-brand-gold-light' : 'text-brand-blue'}`}>
                        {course.name}
                      </td>
                      <td className="py-4 px-6">
                        <span className="bg-brand-blue-accent/20 text-brand-gold border border-brand-gold/20 font-bold px-2 py-0.5 rounded text-[10px]">
                          {course.degree}
                        </span>
                      </td>
                      <td className="py-4 px-6">{course.duration}</td>
                      <td className="py-3 px-6 text-right font-bold text-emerald-600 dark:text-emerald-400">
                        {course.feePerSemester}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {/* Table Footer statement */}
            <div className="bg-gray-55/50 border-t border-gray-100 dark:border-white/5 p-4 text-xxs sm:text-xs text-gray-400 text-center font-sans">
              * Hostel accommodation, text materials, and special Periyar university examinations fees are collected as extra coordinates.
            </div>
          </div>
        </div>
      </section>

      {/* Scholarship Matrices Grid */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-2 mb-16">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display flex items-center justify-center gap-1.5">
            <Coins className="w-4 h-4 text-brand-gold" /> Trust support schemes
          </span>
          <h3 className={`text-3xl font-extrabold tracking-tight font-display ${
            isDarkMode ? 'text-white' : 'text-brand-blue'
          }`}>
            Merit & Sports Scholarships
          </h3>
          <p className="text-xs text-gray-400 max-w-md mx-auto">
            AVS trusts believe in empowering deserving brains. Realize up to 100% waiving parameters based on standard secondary scorecard results.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 font-sans">
          {scholarshipParameters.map((sch, idx) => (
            <div 
              key={idx}
              className={`p-6 rounded-3xl border border-dashed flex flex-col justify-between ${
                isDarkMode 
                  ? 'bg-brand-blue border-white/10 text-gray-300' 
                  : 'bg-white border-gray-200 text-gray-650'
              }`}
            >
              <div className="space-y-4">
                <span className="text-xxs font-bold text-brand-gold uppercase tracking-widest block font-display">
                  Scheme Group
                </span>
                <h4 className={`text-xs md:text-sm font-extrabold font-display leading-tight ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                  {sch.rank}
                </h4>
                <p className="text-xxs text-gray-500 leading-relaxed">
                  Criteria: {sch.eligibility}
                </p>
              </div>

              <div className="pt-6 mt-6 border-t border-gray-55 dark:border-white/5">
                <span className="text-xxs text-gray-400 block uppercase font-semibold">Award details</span>
                <span className="text-base font-extrabold text-emerald-600 dark:text-emerald-400 font-display mt-1 block">
                  {sch.reward}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Admissions Enquiry Form & Quick CTA */}
      <section className={`py-20 border-t ${
        isDarkMode 
          ? 'bg-brand-blue-light/30 border-white/5' 
          : 'bg-gray-50/50 border-gray-100'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Context parameters left */}
            <div className="lg:col-span-5 space-y-6">
              <div className="space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display">No obligations consultations</span>
                <h3 className={`text-3xl font-extrabold tracking-tight font-display ${
                  isDarkMode ? 'text-white' : 'text-brand-blue'
                }`}>
                  Submit an Admission Inquiry
                </h3>
              </div>

              <p className="text-xs sm:text-sm text-gray-500 font-sans leading-relaxed">
                Unlock direct academic support. Enter student qualifications and selected departments details here, and a trust counseling representative will call back within 12 business hours.
              </p>

              {/* Direct phone parameters */}
              <div className="p-4 rounded-2xl bg-white dark:bg-brand-blue border border-gray-150 dark:border-white/5 shadow-sm space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-brand-gold/10 text-brand-gold">
                    <PhoneCall className="w-5 h-5" />
                  </div>
                  <div className="font-sans text-xs">
                    <span className="text-gray-400 block font-semibold leading-none mb-1">Direct Call Helpdesk Office</span>
                    <strong className={`block text-sm ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>{COLLEGE_INFO.phone}</strong>
                  </div>
                </div>
              </div>
            </div>

            {/* Interactive Form UI Right */}
            <div className="lg:col-span-7">
              <div className={`p-6 sm:p-8 rounded-3xl border shadow-xl ${
                isDarkMode 
                  ? 'bg-brand-blue border-white/5 text-white' 
                  : 'bg-white border-gray-100 text-gray-800'
              }`}>
                {/* Visual Live Allocation Notice */}
                <div className="mb-6 p-4 rounded-2xl bg-brand-gold/10 border border-brand-gold/20 flex flex-col sm:flex-row justify-between items-center gap-3 font-display">
                  <div className="flex items-center gap-2.5 text-left">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                    </span>
                    <span className="text-[10px] uppercase font-bold text-brand-gold tracking-widest leading-none">Counseling Speed Metric</span>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-500 font-mono uppercase tracking-wider">
                    🔥 91% Seats Secured At Salem Division
                  </span>
                </div>

                {formSubmitted ? (
                  <div className="text-center py-12 space-y-4 animate-fade-in font-sans">
                    <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-4">
                      <CheckCircle2 className="w-10 h-10" />
                    </div>
                    <h4 className="text-lg font-bold font-display text-emerald-600">Inquiry Received Successfully!</h4>
                    <p className="text-xs text-gray-400 max-w-md mx-auto leading-relaxed">
                      Thank you for choosing AVS Arts & Science College. A designated admissions officer has been assigned to verify eligibility for the <strong>{formData.selectedCourse || "B.Sc"}</strong> seat. Look out for a callback soon.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleFormSubmit} className="space-y-4 font-sans text-xs">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Name */}
                      <div className="space-y-1">
                        <label className="font-semibold text-gray-400 uppercase tracking-wider block">Student Name *</label>
                        <input
                          type="text"
                          name="studentName"
                          placeholder="Ex: Dinesh Kumar"
                          required
                          value={formData.studentName}
                          onChange={handleFormChange}
                          className="w-full p-3 rounded-xl border border-gray-200 dark:border-white/10 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold"
                        />
                      </div>
                      
                      {/* Mobile */}
                      <div className="space-y-1">
                        <label className="font-semibold text-gray-400 uppercase tracking-wider block">Mobile Number *</label>
                        <input
                          type="tel"
                          name="mobile"
                          pattern="[0-9]{10}"
                          placeholder="10 Digit Number"
                          required
                          value={formData.mobile}
                          onChange={handleFormChange}
                          className="w-full p-3 rounded-xl border border-gray-200 dark:border-white/10 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Email */}
                      <div className="space-y-1">
                        <label className="font-semibold text-gray-400 uppercase tracking-wider block">Email Address</label>
                        <input
                          type="email"
                          name="email"
                          placeholder="student@gmail.com"
                          value={formData.email}
                          onChange={handleFormChange}
                          className="w-full p-3 rounded-xl border border-gray-200 dark:border-white/10 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold"
                        />
                      </div>

                      {/* Course Selection */}
                      <div className="space-y-1">
                        <label className="font-semibold text-gray-400 uppercase tracking-wider block">Select Course Course *</label>
                        <select
                          name="selectedCourse"
                          required
                          value={formData.selectedCourse}
                          onChange={handleFormChange}
                          className="w-full p-3 rounded-xl border border-gray-200 dark:border-white/10 bg-white dark:bg-brand-blue text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold"
                        >
                          <option value="">-- Choose Program --</option>
                          {COURSES.map((cr) => (
                            <option key={cr.id} value={cr.name}>{cr.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Message */}
                    <div className="space-y-1">
                      <label className="font-semibold text-gray-400 uppercase tracking-wider block">Brief Details or Questions</label>
                      <textarea
                        name="message"
                        rows={3}
                        placeholder="State your XII standard score ratio or any hostel/scholarship clarifications..."
                        value={formData.message}
                        onChange={handleFormChange}
                        className="w-full p-3 rounded-xl border border-gray-200 dark:border-white/10 bg-transparent text-sm focus:outline-none focus:ring-2 focus:ring-brand-gold"
                      />
                    </div>

                    <div className="pt-2">
                      <button
                        type="submit"
                        className="w-full bg-brand-gold hover:bg-brand-gold-dark text-black font-extrabold text-xs py-3.5 rounded-xl uppercase tracking-wider font-display shadow-lg transform hover:-translate-y-0.5 transition-all cursor-pointer"
                      >
                        Submit Query Form
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* FAQs Segment */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-2 mb-16">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display flex items-center justify-center gap-1.5">
            <HelpCircle className="w-4 h-4 text-brand-gold" /> Cleared Doubts
          </span>
          <h3 className={`text-3xl font-extrabold tracking-tight font-display ${
            isDarkMode ? 'text-white' : 'text-brand-blue'
          }`}>
            Admissions FAQs Central
          </h3>
          <p className="text-xs text-gray-400 max-w-md mx-auto">
            Got queries? Check standard responses related to fees, affiliations, accreditation rules or boarding options.
          </p>
        </div>

        {/* FAQs list widget */}
        <div className="max-w-3xl mx-auto space-y-3 font-sans">
          {FAQS.map((faq, idx) => {
            const isExpanded = faqExpandedIdx === idx;
            return (
              <div 
                key={idx}
                className={`rounded-2xl border ${
                  isDarkMode 
                    ? 'bg-brand-blue border-white/5' 
                    : 'bg-white border-gray-150 shadow-sm'
                } overflow-hidden`}
              >
                <button
                  onClick={() => toggleFAQ(idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 focus:outline-none cursor-pointer"
                >
                  <span className={`text-xs sm:text-sm font-bold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                    {faq.question}
                  </span>
                  <ChevronDown className={`w-4 h-4 text-brand-gold transition-transform duration-300 ${
                    isExpanded ? 'rotate-180' : ''
                  }`} />
                </button>
                
                {isExpanded && (
                  <div className="px-5 pb-5 pt-1 text-xxs sm:text-xs text-gray-500 leading-relaxed border-t border-gray-50 dark:border-white/5">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

    </div>
  );
}
