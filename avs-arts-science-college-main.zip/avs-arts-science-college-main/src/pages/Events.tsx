import React, { useState } from 'react';
import { 
  Calendar, 
  MapPin, 
  Bookmark, 
  Clock, 
  Activity, 
  Search, 
  Award, 
  AlertCircle,
  Megaphone
} from 'lucide-react';
import { EVENTS, NEWS_ANNOUNCEMENTS } from '../data/mockData';

interface EventsProps {
  isDarkMode: boolean;
}

export default function Events({ isDarkMode }: EventsProps) {
  const [selectedCategory, setSelectedCategory] = useState<'All' | 'academic' | 'admission' | 'placement'>('All');

  const filteredNews = NEWS_ANNOUNCEMENTS.filter((news) => {
    return selectedCategory === 'All' ? true : news.category === selectedCategory;
  });

  return (
    <div id="events-news-workspace" className="animate-fade-in mt-[60px] md:mt-[76px]">
      
      {/* Title Header */}
      <section className="bg-brand-blue text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-brand-blue via-brand-blue/90 to-brand-blue-accent" />
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-gold/15 rounded-full blur-3xl" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-3">
          <span className="text-xxs font-bold uppercase tracking-widest text-brand-gold px-3.5 py-1.5 rounded-full bg-white/10 border border-white/5 font-display select-none">
            Institutional Timetables
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold font-display leading-none tracking-tight">
            Events & Campus Bulletins
          </h2>
          <p className="text-xs sm:text-sm text-brand-gold-light/80 max-w-2xl mx-auto font-sans">
            Stay aligned with academic events, state symposiums, coding hackathons, and trust announcements in Salem.
          </p>
        </div>
      </section>

      {/* Main Core View Area */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start font-sans">
          
          {/* 1. Upcoming Events (Left 7-columns) */}
          <div className="lg:col-span-8 space-y-8">
            <div className="border-b border-gray-150 dark:border-white/5 pb-4">
              <span className="text-[10px] font-bold uppercase tracking-widest text-brand-gold block font-display">Seminars & Workshops</span>
              <h3 className={`text-2xl font-extrabold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                Upcoming Academic Events Grid
              </h3>
            </div>

            <div className="space-y-8">
              {EVENTS.map((item) => (
                <div
                  key={item.id}
                  className={`group rounded-3xl overflow-hidden border flex flex-col md:flex-row shadow-sm hover:shadow-md transition-all duration-300 ${
                    isDarkMode 
                      ? 'bg-brand-blue border-white/5' 
                      : 'bg-white border-gray-150'
                  }`}
                >
                  {/* Photo area */}
                  <div className="relative h-48 md:h-auto md:w-60 overflow-hidden shrink-0">
                    <img
                      src={item.image}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    
                    {/* Floating Date Badge */}
                    <div className="absolute top-4 left-4 w-14 h-14 rounded-2xl overflow-hidden shadow border border-brand-gold/25 flex flex-col text-center font-display">
                      <div className="bg-brand-blue/90 text-brand-gold font-bold text-[10px] py-0.5 truncate uppercase">
                        {item.month}
                      </div>
                      <div className="bg-brand-gold text-black font-extrabold text-base flex-1 flex items-center justify-center leading-none">
                        {item.date}
                      </div>
                    </div>
                  </div>

                  {/* Text details */}
                  <div className="p-6 flex flex-col justify-between flex-1">
                    <div className="space-y-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="bg-brand-gold/15 text-brand-gold border border-brand-gold/25 text-[10px] font-bold uppercase px-3 py-0.5 rounded-full font-display">
                          {item.type}
                        </span>
                        <span className="text-xxs text-gray-400 font-semibold uppercase font-mono">
                          By {item.organizedBy.split(' of ')[1] || item.organizedBy}
                        </span>
                      </div>

                      <h4 className={`text-sm sm:text-base font-bold font-display leading-snug tracking-tight ${
                        isDarkMode ? 'text-white' : 'text-brand-blue'
                      }`}>
                        {item.title}
                      </h4>
                      <p className="text-xxs sm:text-xs text-gray-500 leading-relaxed font-sans">
                        {item.description}
                      </p>
                    </div>

                    {/* Footer descriptors */}
                    <div className="flex flex-wrap gap-4 items-center justify-between pt-4 mt-4 border-t border-gray-100 dark:border-white/5 text-xxs sm:text-xs font-sans text-gray-500 font-semibold">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4 text-brand-gold shrink-0" />
                        {item.location}
                      </span>
                      <span className="text-brand-gold uppercase tracking-wider font-bold">
                        Enquire at Block Desk
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 2. News Announcements (Right 4-columns) */}
          <div className="lg:col-span-4 space-y-6">
            <div className="border-b border-gray-150 dark:border-white/5 pb-4">
              <span className="text-[10px] font-bold uppercase tracking-widest text-brand-gold block font-display">Campus Updates</span>
              <h3 className={`text-2xl font-extrabold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                Announcements
              </h3>
            </div>

            {/* Filter buttons for News */}
            <div className="grid grid-cols-2 gap-2 font-display">
              {(['All', 'academic', 'admission', 'placement'] as const).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`text-center py-2 px-3 rounded-xl text-xxs font-extrabold border uppercase tracking-wider transition-all cursor-pointer ${
                    selectedCategory === cat
                      ? 'bg-brand-gold border-brand-gold text-black shadow-sm'
                      : isDarkMode
                        ? 'bg-white/5 border-white/5 text-gray-300 hover:bg-white/10'
                        : 'bg-slate-50 border-gray-150 text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Announcements listings */}
            <div className="space-y-4 font-sans text-xs">
              {filteredNews.length === 0 ? (
                <div className="text-center py-10 space-y-2 text-gray-400">
                  <AlertCircle className="w-8 h-8 text-brand-gold mx-auto" />
                  <p className="font-semibold leading-none">No Updates Found!</p>
                </div>
              ) : (
                filteredNews.map((news) => (
                  <div
                    key={news.id}
                    className={`p-5 rounded-2xl border ${
                      news.isImportant
                        ? 'border-brand-gold/30 bg-brand-gold-light/5'
                        : isDarkMode
                          ? 'bg-brand-blue border-white/5 text-gray-300'
                          : 'bg-white border-gray-150 shadow-sm text-gray-650'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-2 font-display text-xxs font-bold">
                      <span className="text-gray-400 font-mono text-[10px]">
                        {news.date}
                      </span>
                      <span className={`px-2 py-0.5 rounded text-[9px] uppercase tracking-wider ${
                        news.isImportant
                          ? 'bg-red-500/10 text-red-500'
                          : 'bg-brand-blue-accent/30 text-brand-gold'
                      }`}>
                        {news.category}
                      </span>
                    </div>

                    <h4 className={`text-xs font-bold leading-tight mb-2 uppercase tracking-wide tracking-tight ${
                      isDarkMode ? 'text-white' : 'text-brand-blue'
                    }`}>
                      {news.title}
                    </h4>
                    
                    <p className="text-xxs sm:text-xs text-gray-500 leading-relaxed font-sans mt-2 border-t border-dotted border-gray-100 dark:border-white/5 pt-2">
                      {news.content}
                    </p>
                  </div>
                ))
              )}
            </div>

            {/* Newsletter Subscription Box */}
            <div className={`p-6 rounded-3xl border text-center space-y-4 ${
              isDarkMode ? 'bg-gradient-to-br from-brand-blue-light to-brand-blue border-white/5' : 'bg-gradient-to-br from-white to-gray-50 border-gray-150 shadow-md'
            }`}>
              <div className="w-10 h-10 rounded-xl bg-brand-gold/15 text-brand-gold flex items-center justify-center mx-auto shadow-inner">
                <Megaphone className="w-5 h-5 animate-pulse" />
              </div>
              <h5 className={`font-display text-xs font-extrabold uppercase tracking-wide ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                Subscribe to Bulletin Updates
              </h5>
              <p className="text-xxs text-gray-400 font-sans max-w-xs mx-auto leading-relaxed">
                Receive notices, academic calendars, admissions open updates and scholarships straight into your personal email inbox.
              </p>
              
              <div className="space-y-2 font-sans">
                <input
                  type="email"
                  placeholder="Enter email adress..."
                  className="w-full text-xxs p-2.5 rounded-xl border border-gray-200 dark:border-white/10 bg-transparent text-center focus:outline-none focus:ring-1 focus:ring-brand-gold"
                />
                <button
                  onClick={() => alert("✅ Subscribed successfully! Thank you for staying connected with AVS Arts & Science.")}
                  className="w-full bg-brand-gold hover:bg-brand-gold-dark text-black font-extrabold text-xxs py-2.5 rounded-xl cursor-pointer"
                >
                  Join Newsletter
                </button>
              </div>
            </div>

          </div>

        </div>
      </section>

    </div>
  );
}
