import React, { useState } from 'react';
import { 
  MapPin, 
  PhoneCall, 
  Mail, 
  Clock, 
  Send, 
  CheckCircle2, 
  MessageSquare,
  Facebook,
  Instagram,
  Twitter,
  Linkedin
} from 'lucide-react';
import { COLLEGE_INFO } from '../data/mockData';

interface ContactProps {
  isDarkMode: boolean;
}

export default function Contact({ isDarkMode }: ContactProps) {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    mobile: '',
    subject: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.firstName || !formData.email || !formData.message) {
      alert("Please fill in First Name, Email Address, and Message fields.");
      return;
    }

    // Build Premium WhatsApp messaging link
    const targetWhatsAppNum = "916384688085";
    const textMessage = 
      `*AVS ARTS & SCIENCE COLLEGE, SALEM*\n` +
      `*General Support / Administrative Inquiry*\n\n` +
      `• *Name:* ${formData.firstName} ${formData.lastName || ''}\n` +
      `• *Mobile:* ${formData.mobile || 'N/A'}\n` +
      `• *Email:* ${formData.email}\n` +
      `• *Subject:* ${formData.subject || 'General Info'}\n` +
      `• *Message:* ${formData.message}\n\n` +
      `_Administrative office query submitted. Ready to connect._`;

    const formattedUrl = `https://wa.me/${targetWhatsAppNum}?text=${encodeURIComponent(textMessage)}`;

    setSubmitted(true);

    // Open WhatsApp link immediately
    window.open(formattedUrl, '_blank');

    setTimeout(() => {
      setSubmitted(false);
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        mobile: '',
        subject: '',
        message: ''
      });
    }, 4500);
  };

  const socialChannels = [
    { name: 'Facebook', icon: <Facebook className="w-5 h-5 text-blue-600" />, href: 'https://facebook.com' },
    { name: 'Instagram', icon: <Instagram className="w-5 h-5 text-pink-600" />, href: 'https://instagram.com' },
    { name: 'Twitter', icon: <Twitter className="w-5 h-5 text-sky-500" />, href: 'https://twitter.com' },
    { name: 'LinkedIn', icon: <Linkedin className="w-5 h-5 text-blue-700" />, href: 'https://linkedin.com' }
  ];

  return (
    <div id="contact-page-container" className="animate-fade-in mt-[60px] md:mt-[76px]">
      
      {/* Title Jumbotron Header */}
      <section className="bg-brand-blue text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-brand-blue via-brand-blue/90 to-brand-blue-accent" />
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-gold/15 rounded-full blur-3xl" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-3">
          <span className="text-xxs font-bold uppercase tracking-widest text-brand-gold px-3.5 py-1.5 rounded-full bg-white/10 border border-white/5 font-display select-none">
            Get In Touch
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold font-display leading-none tracking-tight">
            Contact Academic Office
          </h2>
          <p className="text-xs sm:text-sm text-brand-gold-light/80 max-w-2xl mx-auto font-sans">
            Reach out for hostel, fee structures, admissions counselor lines, or general administration questions in Salem.
          </p>
        </div>
      </section>

      {/* Main Core Viewport */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start font-sans">
          
          {/* Quick Info & Timings (Left 5-columns) */}
          <div className="lg:col-span-5 space-y-8">
            <div className="border-b border-gray-155 dark:border-white/5 pb-4">
              <span className="text-[10px] font-bold uppercase tracking-widest text-brand-gold block font-display">Office Address details</span>
              <h3 className={`text-xl sm:text-2xl font-extrabold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                Our Primary Campus Coordinates
              </h3>
            </div>

            <div className="space-y-6 text-xs sm:text-sm">
              {/* Address card */}
              <div className={`p-5 rounded-2xl border flex gap-4 ${
                isDarkMode ? 'bg-brand-blue border-white/5' : 'bg-white border-gray-150 shadow-sm'
              }`}>
                <div className="p-3 bg-brand-gold/15 text-brand-gold rounded-xl shrink-0 h-max">
                  <MapPin className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] font-extrabold text-gray-400 uppercase tracking-widest block font-display">Campus Location</span>
                  <p className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
                    {COLLEGE_INFO.location}
                  </p>
                </div>
              </div>

              {/* Call card */}
              <div className={`p-5 rounded-2xl border flex gap-4 ${
                isDarkMode ? 'bg-brand-blue border-white/5' : 'bg-white border-gray-150 shadow-sm'
              }`}>
                <div className="p-3 bg-brand-gold/15 text-brand-gold rounded-xl shrink-0 h-max">
                  <PhoneCall className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] font-extrabold text-gray-400 uppercase tracking-widest block font-display">Helpdesk Hotline</span>
                  <p className={`font-bold font-display ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
                    {COLLEGE_INFO.phone}
                  </p>
                  <p className="text-xxs text-gray-400">Admissions/Counseling queries are processed directly through this number.</p>
                </div>
              </div>

              {/* Mail card */}
              <div className={`p-5 rounded-2xl border flex gap-4 ${
                isDarkMode ? 'bg-brand-blue border-white/5' : 'bg-white border-gray-150 shadow-sm'
              }`}>
                <div className="p-3 bg-brand-gold/15 text-brand-gold rounded-xl shrink-0 h-max">
                  <Mail className="w-5 h-5" />
                </div>
                <div className="space-y-1 font-sans">
                  <span className="text-[10px] font-extrabold text-gray-400 uppercase tracking-widest block font-display">Email Address</span>
                  <p className={`font-bold ${isDarkMode ? 'text-white' : 'text-gray-850'}`}>
                    {COLLEGE_INFO.email}
                  </p>
                </div>
              </div>

              {/* Timing card */}
              <div className={`p-5 rounded-2xl border flex gap-4 ${
                isDarkMode ? 'bg-brand-blue border-white/5' : 'bg-white border-gray-150 shadow-sm'
              }`}>
                <div className="p-3 bg-brand-gold/15 text-brand-gold rounded-xl shrink-0 h-max">
                  <Clock className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <span className="text-[10px] font-extrabold text-gray-400 uppercase tracking-widest block font-display">Administrative Hours</span>
                  <p className={`font-semibold ${isDarkMode ? 'text-white' : 'text-gray-800'}`}>
                    {COLLEGE_INFO.officeHours}
                  </p>
                </div>
              </div>
            </div>

            {/* Social Grid block */}
            <div className="space-y-4">
              <span className="text-[10px] font-bold uppercase tracking-widest text-brand-gold block font-display">Stay connected</span>
              <div className="flex gap-3">
                {socialChannels.map((soc) => (
                  <a
                    key={soc.name}
                    href={soc.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`w-10 h-10 rounded-xl border flex items-center justify-center transition-all ${
                      isDarkMode 
                        ? 'bg-white/5 border-white/5 hover:bg-white/10' 
                        : 'bg-white border-gray-150 hover:shadow-md'
                    }`}
                    title={soc.name}
                  >
                    {soc.icon}
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Interactive Form Board (Right 7-columns) */}
          <div className="lg:col-span-7">
            <div className={`p-6 sm:p-8 rounded-3xl border shadow-xl ${
              isDarkMode 
                ? 'bg-brand-blue border-white/5 text-white' 
                : 'bg-white border-gray-150 text-gray-850'
            }`}>
              <div className="border-b border-gray-100 dark:border-white/5 pb-4 mb-6">
                <h4 className={`text-lg font-bold font-display flex items-center gap-1.5 ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                  <MessageSquare className="w-5 h-5 text-brand-gold" /> Send Custom Query Message
                </h4>
              </div>

              {submitted ? (
                <div className="text-center py-12 space-y-4 animate-fade-in">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-4">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>
                  <h4 className="text-lg font-bold font-display text-emerald-600">Query Transmitted Successfully!</h4>
                  <p className="text-xs text-gray-400 max-w-md mx-auto leading-relaxed">
                    Thank you, <strong>{formData.firstName}</strong>. Your counseling message has been routed to the registrar's office. You will receive an official email confirmation shortly.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleFormSubmit} className="space-y-4 text-xs font-sans">
                  
                  {/* First & Last Name */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="font-bold text-gray-400 uppercase tracking-wider block">First Name *</label>
                      <input
                        type="text"
                        name="firstName"
                        required
                        placeholder="Ex: Dinesh"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        className="w-full text-xs sm:text-sm p-3 rounded-xl border border-gray-200 dark:border-white/10 bg-transparent focus:outline-none focus:ring-2 focus:ring-brand-gold text-gray-700 dark:text-white"
                      />
                    </div>
                    
                    <div className="space-y-1">
                      <label className="font-bold text-gray-400 uppercase tracking-wider block">Last Name</label>
                      <input
                        type="text"
                        name="lastName"
                        placeholder="Ex: Kumar"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        className="w-full text-xs sm:text-sm p-3 rounded-xl border border-gray-200 dark:border-white/10 bg-transparent focus:outline-none focus:ring-2 focus:ring-brand-gold text-gray-750 dark:text-white"
                      />
                    </div>
                  </div>

                  {/* Mail & Mob */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="font-bold text-gray-400 uppercase tracking-wider block">Email Address *</label>
                      <input
                        type="email"
                        name="email"
                        required
                        placeholder="yourname@gmail.com"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="w-full text-xs sm:text-sm p-3 rounded-xl border border-gray-200 dark:border-white/10 bg-transparent focus:outline-none focus:ring-2 focus:ring-brand-gold text-gray-750 dark:text-white"
                      />
                    </div>
                    
                    <div className="space-y-1">
                      <label className="font-bold text-gray-400 uppercase tracking-wider block">Mobile (10 Digits)</label>
                      <input
                        type="tel"
                        name="mobile"
                        pattern="[0-9]{10}"
                        placeholder="9876543210"
                        value={formData.mobile}
                        onChange={handleInputChange}
                        className="w-full text-xs sm:text-sm p-3 rounded-xl border border-gray-200 dark:border-white/10 bg-transparent focus:outline-none focus:ring-2 focus:ring-brand-gold text-gray-750 dark:text-white"
                      />
                    </div>
                  </div>

                  {/* Subject */}
                  <div className="space-y-1 font-sans">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Subject *</label>
                    <input
                      type="text"
                      name="subject"
                      required
                      placeholder="Admission query, hostel queries, scholarships, certificate issues..."
                      value={formData.subject}
                      onChange={handleInputChange}
                      className="w-full text-xs sm:text-sm p-3 rounded-xl border border-gray-200 dark:border-white/10 bg-transparent focus:outline-none focus:ring-2 focus:ring-brand-gold text-gray-750 dark:text-white"
                    />
                  </div>

                  {/* Message body */}
                  <div className="space-y-1 font-sans text-xs">
                    <label className="font-bold text-gray-400 uppercase tracking-wider block">Message Details *</label>
                    <textarea
                      name="message"
                      rows={4}
                      required
                      placeholder="Write your brief concern here..."
                      value={formData.message}
                      onChange={handleInputChange}
                      className="w-full text-xs sm:text-sm p-3 rounded-xl border border-gray-200 dark:border-white/10 bg-transparent focus:outline-none focus:ring-2 focus:ring-brand-gold text-gray-700 dark:text-white"
                    />
                  </div>

                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full flex items-center justify-center gap-2 bg-brand-gold hover:bg-brand-gold-dark text-black font-extrabold text-xs py-3.5 rounded-xl uppercase tracking-wider font-display shadow-lg transform hover:-translate-y-0.5 transition-all cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                      Transmit Message
                    </button>
                  </div>

                </form>
              )}
            </div>
          </div>

        </div>
      </section>

      {/* Embedded Google Map */}
      <section className="w-full px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto pb-20">
        <div className="space-y-4 text-center mb-8">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display">Interactive Navigation Map</span>
          <h3 className={`text-2xl font-extrabold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
            Locate Us easily on Google Maps
          </h3>
        </div>

        <div className="rounded-3xl overflow-hidden border border-gray-200 dark:border-white/5 shadow-lg h-96 w-full relative">
          <iframe
            src={COLLEGE_INFO.mapsEmbedUrl}
            title={`${COLLEGE_INFO.name} Location Map`}
            className="w-full h-full border-0 absolute inset-0"
            allowFullScreen={false}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </section>

    </div>
  );
}
