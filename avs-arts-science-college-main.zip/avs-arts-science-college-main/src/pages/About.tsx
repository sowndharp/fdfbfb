import React from 'react';
import { 
  History, 
  Compass, 
  Target, 
  Award, 
  ShieldCheck, 
  Zap, 
  User, 
  Briefcase, 
  LayoutGrid, 
  BookOpen, 
  Wifi, 
  Activity, 
  MapPin
} from 'lucide-react';
import { COLLEGE_INFO } from '../data/mockData';

interface AboutProps {
  isDarkMode: boolean;
}

export default function About({ isDarkMode }: AboutProps) {
  
  const accreditationList = [
    { title: "Affiliation Status", desc: "Permanent affiliation with Periyar University, Salem, legally authorized to issue global level BA, B.Sc, BCA, B.Com, MBA, M.Sc degrees.", icon: <ShieldCheck className="w-5 h-5 text-brand-gold" /> },
    { title: "NAAC Registration", desc: "Awarded continuous 'A' Grade in successive evaluation audits. Highly commended academic infrastructure, research initiatives, and corporate ratios.", icon: <Award className="w-5 h-5 text-brand-gold" /> },
    { title: "UGC Approved Model", desc: "Approved and fully validated under sections 2(f) and 12(B) of the UGC corporate regulatory standards.", icon: <Zap className="w-5 h-5 text-brand-gold" /> }
  ];

  const developmentTimeline = [
    { year: "2006", title: "Inception & Establishment", text: "Founded by general philanthropic academics with 3 flagship computer science branches, shaping educational paths in Salem." },
    { year: "2011", title: "Postgraduate Amplification", text: "Inaugurated dedicated postgraduate master cohorts including Masters of Business (MBA) and advanced sciences M.Sc." },
    { year: "2016", title: "First Cycle NAAC Merit Accreditation", text: "Achieved initial National Board certification, acknowledging prime pedagogical structures and student welfare metrics." },
    { year: "2021", title: "Mega Computing Infrastructure Build", text: "Inaugurated Turing Lab wing and automated catalog systems across library chambers, supporting more than 350 terminals." },
    { year: "2024", title: "NAAC Grade 'A' Cycle Success", text: "Accredited with premium 'A' standards highlighting institutional quality, 30+ registered patents, and near-perfect placements." }
  ];

  const facilityBlocks = [
    { title: "Srinivasa Central Library", desc: "Hosts more than 25,000 reference monographs, state board academic portfolios, international computer science journals, and quiet digital browsing spaces.", icon: <BookOpen className="w-6 h-6 text-brand-gold" />, img: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=600&q=80" },
    { title: "Hi-Tech Computer Wings", desc: "Centralized computing halls containing Core i7 workstations, cloud dev environments, digital analytics tools, and internet lines.", icon: <LayoutGrid className="w-6 h-6 text-brand-gold" />, img: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80" },
    { title: "Smart Seminar Auditoriums", desc: "Equipped with immersive widescreen projectors, dynamic Bose amplifiers, acoustic paneling, and seating capacity for 250+ scholars.", icon: <Activity className="w-6 h-6 text-brand-gold" />, img: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=600&q=80" },
    { title: "Gigabit Campus Networks", desc: "100% fiber optic cabling routing high speed 100 Mbps internet data continuously across laboratories, academic cells, and hostels.", icon: <Wifi className="w-6 h-6 text-brand-gold" />, img: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=600&q=80" }
  ];

  return (
    <div id="about-us-page" className="animate-fade-in mt-[60px] md:mt-[76px]">
      
      {/* Page Title Header */}
      <section className="bg-brand-blue text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-brand-blue via-brand-blue/90 to-brand-blue-accent" />
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-gold/15 rounded-full blur-3xl" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-3">
          <span className="text-xxs font-bold uppercase tracking-widest text-brand-gold px-3.5 py-1.5 rounded-full bg-white/10 border border-white/5 font-display select-none">
            About Our Institution
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold font-display leading-none tracking-tight">
            AVS Arts & Science College
          </h2>
          <p className="text-xs sm:text-sm text-brand-gold-light/80 max-w-2xl mx-auto font-sans">
            Affiliated to Periyar University, Salem • Accredited by NAAC with 'A' Grade
          </p>
        </div>
      </section>

      {/* Basic History block */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display flex items-center gap-1.5">
                <History className="w-4 h-4 text-brand-gold" /> Legacy of Excellence
              </span>
              <h3 className={`text-2xl sm:text-3.5xl font-extrabold tracking-tight font-display ${
                isDarkMode ? 'text-white' : 'text-brand-blue'
              }`}>
                Established with a vision to empower Salem's youth
              </h3>
            </div>
            
            <p className="text-xs sm:text-sm text-gray-500 font-sans leading-relaxed">
              AVS Arts & Science College, Salem, was established in the year {COLLEGE_INFO.established} under the flagship of experienced academics. Over the years, the institution has emerged as Salem's premier portal of higher learning, sculpting thousands of undergraduate and postgraduate scholars.
            </p>

            <p className="text-xs sm:text-sm text-gray-500 font-sans leading-relaxed">
              We stand as a top benchmark organization by consistently offering stellar computer programming workshops, comprehensive accounting paradigms, and highly effective placement training strategies. Our degrees are recognized globally, unlocking prospective career futures.
            </p>
          </div>

          <div className="relative rounded-3xl overflow-hidden shadow-xl max-h-80 border-4 border-white dark:border-brand-blue-accent shrink-0">
            <img
              src="https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=800&q=80"
              alt="Students in college campus grounds"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </section>

      {/* Vision & Mission Core Cards */}
      <section className={`py-20 border-t border-b ${
        isDarkMode 
          ? 'bg-transparent border-white/5' 
          : 'bg-slate-50 border-gray-100'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            
            {/* Vision card */}
            <div className={`p-8 rounded-3xl border ${
              isDarkMode 
                ? 'bg-brand-blue-light border-white/5' 
                : 'bg-white border-gray-100 shadow-md'
            } space-y-4`}>
              <div className="w-12 h-12 rounded-2xl bg-brand-gold/10 flex items-center justify-center text-brand-gold">
                <Compass className="w-6 h-6" />
              </div>
              <h4 className={`text-xl font-bold font-display tracking-tight ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                Our Vision
              </h4>
              <p className="text-xs sm:text-sm text-gray-500 font-sans leading-relaxed">
                To build an internationally recognized center of academic excellence that nurtures innovative technological insights, standard commerce capabilities, and ethical governance standards among diverse students to build strong national communities.
              </p>
            </div>

            {/* Mission card */}
            <div className={`p-8 rounded-3xl border ${
              isDarkMode 
                ? 'bg-brand-blue-light border-white/5' 
                : 'bg-white border-gray-100 shadow-md'
            } space-y-4`}>
              <div className="w-12 h-12 rounded-2xl bg-brand-gold/10 flex items-center justify-center text-brand-gold">
                <Target className="w-6 h-6" />
              </div>
              <h4 className={`text-xl font-bold font-display tracking-tight ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                Our Mission
              </h4>
              <ul className="text-xs sm:text-sm text-gray-500 font-sans space-y-2 leading-relaxed">
                <li className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 bg-brand-gold rounded-full shrink-0 mt-2" />
                  To impart peerless technological literacy and vocational capability through robust, responsive state-of-the-art computational facilities.
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 bg-brand-gold rounded-full shrink-0 mt-2" />
                  To design and maintain continuous interface with corporate industry ecosystems to facilitate internships, mentorships, and direct placements.
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 bg-brand-gold rounded-full shrink-0 mt-2" />
                  To prioritize human values and professional ethic traits through dedicated community outreach projects.
                </li>
              </ul>
            </div>

          </div>
        </div>
      </section>

      {/* Leadership Messages: Chairman & Principal */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* Chairman block */}
        <div className={`p-8 sm:p-12 rounded-3xl border relative ${
          isDarkMode ? 'bg-brand-blue-light border-white/5' : 'bg-white border-gray-100 shadow-lg'
        }`}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-8 space-y-4">
              <span className="text-xxs font-bold text-brand-gold uppercase tracking-widest block font-display">
                Founder Chairman Address
              </span>
              <h3 className={`text-2xl font-extrabold font-display leading-tight ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                "We provide the wings of capability and the grounding of absolute values."
              </h3>
              <div className="text-xs sm:text-sm text-gray-500 font-sans space-y-3 leading-relaxed">
                <p>
                  Education remains the single most powerful catalytic force to uplift societal sectors. When we laid the cornerstone of AVS Arts & Science College, Salem, our single focus was delivering uncompromised tier-1 educational inputs comparable to metropolitan portals.
                </p>
                <p>
                  Today, I feel content witnessing the state-of-the-art computational workshops, placement success logs, and standard ethical discipline rooted in our alumni. We continuously expand facilities to welcome the future.
                </p>
              </div>
              <div className="border-t border-gray-100 dark:border-white/5 pt-4">
                <span className="font-serif italic text-sm text-brand-gold block">Thiru. K. Kailasam</span>
                <span className="text-xxs text-gray-400 font-mono">Chairman, AVS Educational Trust</span>
              </div>
            </div>

            <div className="lg:col-span-4 shrink-0 text-center">
              <div className="w-48 h-48 sm:w-56 sm:h-56 rounded-2xl overflow-hidden border-4 border-brand-gold/30 mx-auto shadow">
                <img
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80"
                  alt="Chairman Thiru. K. Kailasam"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Principal Message Duplicate for detail alignment */}
        <div className={`p-8 sm:p-12 rounded-3xl border relative ${
          isDarkMode ? 'bg-brand-blue-light border-white/5' : 'bg-white border-gray-100 shadow-lg'
        }`}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-4 shrink-0 text-center order-last lg:order-first">
              <div className="w-48 h-48 sm:w-56 sm:h-56 rounded-2xl overflow-hidden border-4 border-brand-gold/30 mx-auto shadow">
                <img
                  src="https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=400&q=80"
                  alt="Principal Dr. S. K. Venugopal"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>

            <div className="lg:col-span-8 space-y-4">
              <span className="text-xxs font-bold text-brand-gold uppercase tracking-widest block font-display">
                Principal Academic Desk Message
              </span>
              <h3 className={`text-2xl font-extrabold font-display leading-tight ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                "Unlocking vocational potential with precision scientific and commercial training."
              </h3>
              <div className="text-xs sm:text-sm text-gray-500 font-sans space-y-3 leading-relaxed">
                <p>
                  In this dynamic computational age, students must navigate beyond textbook definitions. Our specialized semesters focus enormously on practical laboratory development, logical systems operations, commercial trade audits, and communicative interactions.
                </p>
                <p>
                  We coordinate with regional industrial chambers of Salem and state software guilds to map student capabilities to active company vacancies. Let us shape a remarkable professional future together.
                </p>
              </div>
              <div className="border-t border-gray-100 dark:border-white/5 pt-4">
                <span className="font-serif italic text-sm text-brand-gold block">Dr. S. K. Venugopal, M.Sc., Ph.D.</span>
                <span className="text-xxs text-gray-400 font-mono">Principal & Secretary</span>
              </div>
            </div>

          </div>
        </div>

      </section>

      {/* Accreditations Details Box */}
      <section className={`py-20 border-t border-b ${
        isDarkMode 
          ? 'bg-brand-blue-light/20 border-white/5' 
          : 'bg-gray-50 border-gray-100'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-2 mb-16">
            <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display">Official Accreditations</span>
            <h3 className={`text-3xl font-extrabold tracking-tight font-display ${
              isDarkMode ? 'text-white' : 'text-brand-blue'
            }`}>
              Affiliated & Fully Certified Institution
            </h3>
            <p className="text-xs text-gray-400 max-w-lg mx-auto">
              Our institutional frameworks comply with peak national standard matrices to assure your degrees hold global compliance values.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {accreditationList.map((ac, idx) => (
              <div 
                key={idx}
                className={`p-6 rounded-2xl border text-center space-y-4 ${
                  isDarkMode 
                    ? 'bg-brand-blue border-white/5' 
                    : 'bg-white border-gray-100 shadow-sm'
                }`}
              >
                <div className="w-10 h-10 rounded-full bg-brand-gold/10 text-brand-gold flex items-center justify-center mx-auto shadow-inner">
                  {ac.icon}
                </div>
                <h4 className={`text-base font-bold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                  {ac.title}
                </h4>
                <p className="text-xs text-gray-500 leading-relaxed font-sans">
                  {ac.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements Timeline */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-2 mb-16">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display">Timeline Journey</span>
          <h3 className={`text-3xl font-extrabold tracking-tight font-display ${
            isDarkMode ? 'text-white' : 'text-brand-blue'
          }`}>
            Chronology of Major Achievements
          </h3>
          <p className="text-xs text-gray-400 max-w-md mx-auto">
            A testament to our incremental milestones and continuing educational success records since inception.
          </p>
        </div>

        {/* Vertical Timeline Tree */}
        <div className="relative max-w-4xl mx-auto">
          {/* Main line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-brand-gold via-brand-gold-dark to-brand-blue-accent" />

          <div className="space-y-12">
            {developmentTimeline.map((item, idx) => {
              const isEven = idx % 2 === 0;
              return (
                <div key={idx} className="relative flex flex-col md:flex-row items-start font-sans">
                  {/* Left Side */}
                  <div className={`w-full md:w-1/2 flex md:justify-end pr-0 md:pr-12 pl-10 md:pl-0 ${
                    isEven ? 'md:order-first' : 'md:order-last md:text-left text-left pl-10 md:pl-12'
                  }`}>
                    <div className={`p-6 rounded-2xl border ${
                      isDarkMode ? 'bg-brand-blue-light border-white/5' : 'bg-white border-gray-100 shadow'
                    } max-w-md space-y-2`}>
                      <span className="inline-block bg-brand-gold text-black rounded px-2.5 py-0.5 font-bold font-display text-xs">
                        {item.year}
                      </span>
                      <h4 className={`text-sm font-bold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                        {item.title}
                      </h4>
                      <p className="text-xs text-gray-500 leading-relaxed">
                        {item.text}
                      </p>
                    </div>
                  </div>

                  {/* Bullet Marker (Middle) */}
                  <div className="absolute left-2.5 md:left-1/2 -translate-x-1.5 md:-translate-x-1/2 top-6 w-3 h-3 rounded-full bg-brand-gold border-2 border-white dark:border-brand-blue shadow shrink-0 z-10" />
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Infrastructures & Facilities */}
      <section className={`py-20 border-t ${
        isDarkMode 
          ? 'bg-brand-blue-light/30 border-white/5' 
          : 'bg-gray-50/50 border-gray-100'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-2 mb-16">
            <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display">Campus Infrastructure</span>
            <h3 className={`text-3xl font-extrabold tracking-tight font-display ${
              isDarkMode ? 'text-white' : 'text-brand-blue'
            }`}>
              Stellar Campus Facilities
            </h3>
            <p className="text-xs text-gray-400 max-w-lg mx-auto">
              Our campus encompasses world-class laboratories and academic domains meticulously laid out for modern students.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {facilityBlocks.map((fac, idx) => (
              <div 
                key={idx}
                className={`group rounded-2xl overflow-hidden border ${
                  isDarkMode 
                    ? 'bg-brand-blue border-white/5' 
                    : 'bg-white border-gray-100 shadow-sm hover:shadow-md'
                } transition-all duration-300`}
              >
                <div className="h-44 overflow-hidden relative">
                  <img
                    src={fac.img}
                    alt={fac.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                </div>

                <div className="p-5 space-y-2">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-brand-gold/15 text-brand-gold shrink-0">
                      {fac.icon}
                    </div>
                    <h4 className={`font-display text-xs font-bold leading-tight ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                      {fac.title}
                    </h4>
                  </div>
                  <p className="text-xxs sm:text-xs text-gray-500 font-sans leading-relaxed">
                    {fac.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

    </div>
  );
}
