import React, { useState, useEffect } from 'react';
import { 
  ArrowRight, 
  BookOpen, 
  Award, 
  Users, 
  Building, 
  TrendingUp, 
  Bookmark, 
  Calendar, 
  ChevronLeft, 
  ChevronRight,
  Video,
  MapPin,
  Star
} from 'lucide-react';
import { 
  COLLEGE_INFO, 
  COURSES, 
  TESTIMONIALS, 
  RECRUITERS, 
  EVENTS, 
  NEWS_ANNOUNCEMENTS 
} from '../data/mockData';

interface HomeProps {
  onPageChange: (page: string) => void;
  isDarkMode: boolean;
}

export default function Home({ onPageChange, isDarkMode }: HomeProps) {
  const [currentSlide, setCurrentSlide] = useState(0);

  const slides = [
    {
      title: "AVS Arts & Science College",
      subtitle: "Where Knowledge Meets Character",
      badge: "NAAC 'A' Grade Accredited • Admissions 2026-27",
      desc: "Empowering state-of-the-art technological literacy, corporate commerce competency, and scientific innovation in Salem.",
      image: "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=1920&q=80",
      cta: "Explore Programs"
    },
    {
      title: "Pathway to Premier Placements",
      subtitle: "Highest Package Up To ₹12.0 LPA",
      badge: "93.4% Consistent Placement Rate",
      desc: "Rigorous quantitative app training, tech camps, coding workshops, and mock interview setups with Fortune 500 corporate recruiters.",
      image: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=1920&q=80",
      cta: "View Placement Records"
    },
    {
      title: "State-Of-The-Art Tech Infrastructure",
      subtitle: "Modern Computational & Analytical Labs",
      badge: "Spacious Student Campus & Research Environment",
      desc: "Over 350 modern computing nodes, high-performance MATLAB facilities, full-stack workshops, and robust fiber internet networks.",
      image: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=1920&q=80",
      cta: "Tour Our Facilities"
    }
  ];

  // Auto transition hero banner
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [slides.length]);

  const handleNextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const handlePrevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const stats = [
    { icon: <Award className="w-6 h-6 text-brand-gold" />, value: "Grade 'A'", label: "NAAC Accredited" },
    { icon: <Building className="w-6 h-6 text-brand-gold" />, value: "20+", label: "Academic Labs" },
    { icon: <Users className="w-6 h-6 text-brand-gold" />, value: "3,500+", label: "Enrollments" },
    { icon: <TrendingUp className="w-6 h-6 text-brand-gold" />, value: "93.4%", label: "Placement Ratio" }
  ];

  const campusHighlights = [
    { title: "Centralized Library Domain", desc: "A colossal library catalog containing over 25,000 corporate science logs, literature journals and virtual books.", image: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=600&q=80" },
    { title: "Sports Complex", desc: "Multiple standard courts, indoor table hubs, dynamic physical training camps and periodic tournament setups.", image: "https://images.unsplash.com/photo-1513568690616-ad9748272fbd?auto=format&fit=crop&w=600&q=80" },
    { title: "Residential Safe Hostels", desc: "Distinct boys and girls residential blocks, clean dining halls, purified hot water grids, and high-speed campus Wi-Fi.", image: "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&w=600&q=80" }
  ];

  return (
    <div id="home-page-container" className="animate-fade-in">
      
      {/* 1. Hero Dynamic Image Slider Section */}
      <section id="hero-slider" className="relative h-[80vh] md:h-[90vh] bg-slate-950 overflow-hidden mt-[60px] md:mt-[76px]">
        {/* Carousel Tracks */}
        {slides.map((slide, index) => {
          const isActive = index === currentSlide;
          return (
            <div
              key={index}
              className={`absolute inset-0 transition-all duration-1000 ease-in-out transform ${
                isActive ? 'opacity-100 scale-100' : 'opacity-0 scale-105 pointer-events-none'
              }`}
            >
              {/* Cover Image */}
              <img
                src={slide.image}
                alt={slide.title}
                className="w-full h-full object-cover opacity-35"
                referrerPolicy="no-referrer"
              />
              {/* Gradient Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-brand-blue via-brand-blue/50 to-transparent" />
              
              {/* Content overlay */}
              <div className="absolute inset-0 flex items-center">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full text-white">
                  <div className="max-w-3xl space-y-4 sm:space-y-6">
                    {/* Badge */}
                    <span className="inline-flex items-center gap-1.5 bg-brand-gold/25 border border-brand-gold/30 text-brand-gold px-3.5 py-1.5 rounded-full text-xxs sm:text-xs font-semibold tracking-wider uppercase font-display select-none animate-pulse">
                      <Award className="w-3.5 h-3.5" />
                      {slide.badge}
                    </span>
                    
                    {/* Heading */}
                    <div className="space-y-2">
                      <h2 className="text-3xl sm:text-5xl md:text-6xl font-extrabold tracking-tight font-display text-white leading-tight">
                        {slide.title}
                      </h2>
                      <p className="text-lg sm:text-2xl md:text-3xl font-light text-brand-gold font-serif italic">
                        {slide.subtitle}
                      </p>
                    </div>

                    {/* Desc */}
                    <p className="text-xs sm:text-base text-gray-300 leading-relaxed font-sans max-w-2xl">
                      {slide.desc}
                    </p>

                    {/* Action Buttons */}
                    <div className="flex flex-wrap gap-3 pt-2">
                      <button
                        onClick={() => {
                          if (index === 0) onPageChange('courses');
                          else if (index === 1) onPageChange('placements');
                          else onPageChange('about');
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className="bg-brand-gold hover:bg-brand-gold-dark text-black px-6 py-3 rounded-full text-xs font-bold font-display shadow-lg transform hover:-translate-y-0.5 transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        {slide.cta}
                        <ArrowRight className="w-4 h-4" />
                      </button>
                      
                      <button
                        onClick={() => {
                          onPageChange('admissions');
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className="bg-white/10 border border-white/20 hover:bg-white/20 text-white px-6 py-3 rounded-full text-xs font-bold font-display transition-all cursor-pointer"
                      >
                        Apply Online 2026-27
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {/* Carousel Arrow Controls */}
        <button
          onClick={handlePrevSlide}
          className="absolute left-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/40 hover:bg-black/60 text-white backdrop-blur-sm z-10 transition-colors focus:outline-none cursor-pointer"
          aria-label="Previous main slide"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <button
          onClick={handleNextSlide}
          className="absolute right-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/40 hover:bg-black/60 text-white backdrop-blur-sm z-10 transition-colors focus:outline-none cursor-pointer"
          aria-label="Next main slide"
        >
          <ChevronRight className="w-5 h-5" />
        </button>

        {/* Indicator dots */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center space-x-2.5 z-10">
          {slides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentSlide(idx)}
              className={`h-2.5 rounded-full transition-all duration-300 ${
                idx === currentSlide ? 'w-8 bg-brand-gold' : 'w-2.5 bg-white/40'
              }`}
              aria-label={`Go to slide ${idx + 1}`}
            />
          ))}
        </div>
      </section>

      {/* 2. Key Stats Animated Blocks */}
      <section id="stats-banner" className="relative z-10 -mt-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`grid grid-cols-2 lg:grid-cols-4 gap-4 p-6 sm:p-8 rounded-3xl shadow-xl border ${
          isDarkMode 
            ? 'bg-brand-blue-light border-white/5' 
            : 'bg-white border-gray-100'
        }`}>
          {stats.map((stat, idx) => (
            <div 
              key={idx} 
              className="flex items-center gap-3.5 sm:gap-4 border-r last:border-r-0 border-gray-200/50 dark:border-white/10 pr-2 last:pr-0"
            >
              <div className="p-3 rounded-2xl bg-brand-gold/10 text-brand-gold shrink-0">
                {stat.icon}
              </div>
              <div>
                <dt className={`font-display text-2xl sm:text-3xl font-extrabold tracking-tight ${
                  isDarkMode ? 'text-white' : 'text-brand-blue'
                }`}>
                  {stat.value}
                </dt>
                <dd className="text-xxs sm:text-xs font-semibold text-gray-400 uppercase tracking-widest leading-none mt-1">
                  {stat.label}
                </dd>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. About Briefing Section */}
      <section id="about-intro" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Photos grid left */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white dark:border-brand-blue-accent">
              <img
                src="https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=800&q=80"
                alt="AVS Campus Building"
                className="w-full h-80 object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-brand-blue/60 to-transparent" />
              <div className="absolute bottom-4 left-4 text-white">
                <span className="text-xxs font-bold uppercase tracking-widest text-brand-gold font-display">Est. {COLLEGE_INFO.established}</span>
                <p className="text-sm font-semibold font-sans">Main Campus Domain, Salem</p>
              </div>
            </div>
            {/* Dec decorative card */}
            <div className="absolute -bottom-6 -right-6 hidden sm:block p-4 rounded-2xl shadow-lg border bg-brand-gold text-brand-blue font-display max-w-[200px] border-brand-gold-dark">
              <span className="block text-2xl font-extrabold leading-none">NAAC 'A'</span>
              <p className="text-xxs font-semibold uppercase tracking-wider mt-1 opacity-90">Outstanding Quality Accreditation</p>
            </div>
          </div>

          {/* Texts right */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display">Welcome to AVS Arts & Science</span>
              <h3 className={`text-3xl sm:text-4xl font-extrabold tracking-tight font-display ${
                isDarkMode ? 'text-white' : 'text-brand-blue'
              }`}>
                Inspiring Academic Innovation and Character Excellence
              </h3>
            </div>
            
            <p className="text-xs sm:text-sm text-gray-500 leading-relaxed font-sans">
              AVS Arts & Science College, Salem, stands tall as an exceptional temple of higher learning affiliated with Periyar University. We ensure state-of-the-art technological support, deep research exposure, and market-ready commerce programs to sculpt standard academic leaders.
            </p>

            <p className="text-xs sm:text-sm text-gray-500 leading-relaxed font-sans">
              Under our intensive mentorship paradigm, students cultivate core computing techniques, advanced economic analytical models, and communicative rhetoric required to conquer modern corporate careers successfully.
            </p>

            {/* Micro checks row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="flex items-center gap-2.5 text-xs font-semibold">
                <div className="w-2.5 h-2.5 rounded-full bg-brand-gold shrink-0" />
                <span className={isDarkMode ? 'text-gray-300' : 'text-gray-700'}>State-of-the-Art Core Labs</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs font-semibold">
                <div className="w-2.5 h-2.5 rounded-full bg-brand-gold shrink-0" />
                <span className={isDarkMode ? 'text-gray-300' : 'text-gray-700'}>100% Comprehensive Placement Drills</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs font-semibold">
                <div className="w-2.5 h-2.5 rounded-full bg-brand-gold shrink-0" />
                <span className={isDarkMode ? 'text-gray-300' : 'text-gray-700'}>Merit Tuition Scholarships</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs font-semibold">
                <div className="w-2.5 h-2.5 rounded-full bg-brand-gold shrink-0" />
                <span className={isDarkMode ? 'text-gray-300' : 'text-gray-700'}>Highly Accomplished Faculty Base</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => {
                  onPageChange('about');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="inline-flex items-center gap-2 bg-brand-blue-accent/10 border border-brand-blue-accent/20 hover:bg-brand-blue-accent/20 text-brand-gold hover:text-brand-gold-dark font-display font-bold text-xs px-6 py-3 rounded-full transition-all cursor-pointer"
              >
                Learn More About Us
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Popular Courses Spots */}
      <section className={`py-20 border-t border-b ${
        isDarkMode 
          ? 'bg-brand-blue-light/30 border-white/5' 
          : 'bg-gray-50/50 border-gray-100'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 mb-12">
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display">Aspirant Pathways</span>
              <h3 className={`text-3xl font-extrabold tracking-tight font-display ${
                isDarkMode ? 'text-white' : 'text-brand-blue'
              }`}>
                Popular Professional Courses
              </h3>
            </div>
            <button
              onClick={() => {
                onPageChange('courses');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="text-xs font-extrabold font-display text-brand-gold hover:text-brand-gold-dark inline-flex items-center gap-1 cursor-pointer"
            >
              Explore All Courses
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {COURSES.slice(0, 3).map((course) => (
              <div
                key={course.id}
                className={`group rounded-2xl overflow-hidden shadow-md border hover:shadow-xl transition-all duration-300 flex flex-col h-full ${
                  isDarkMode 
                    ? 'bg-brand-blue border-white/5' 
                    : 'bg-white border-gray-100'
                }`}
              >
                {/* Course Img */}
                <div className="relative h-48 overflow-hidden shrink-0">
                  <img
                    src={course.image}
                    alt={course.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-4 left-4 bg-brand-blue/80 backdrop-blur-md px-3 py-1 rounded-full text-[10px] text-brand-gold font-bold uppercase font-display border border-brand-gold/20">
                    {course.degree} • {course.duration}
                  </div>
                </div>

                {/* Course Desc */}
                <div className="p-6 flex flex-col flex-1">
                  <span className="text-[10px] font-mono font-bold text-gray-400 block mb-1">{course.code}</span>
                  <h4 className={`text-base font-bold font-display tracking-tight mb-2 group-hover:text-brand-gold transition-colors duration-200 ${
                    isDarkMode ? 'text-white' : 'text-brand-blue'
                  }`}>
                    {course.name}
                  </h4>
                  <p className="text-xs text-gray-500 leading-relaxed font-sans mb-4 flex-1 line-clamp-3">
                    {course.description}
                  </p>
                  
                  {/* Footer card metrics */}
                  <div className="flex items-center justify-between pt-4 border-t border-gray-100 dark:border-white/5 text-xxs font-sans font-semibold">
                    <span className="text-gray-400">Semester Fee: <strong className={isDarkMode ? 'text-white' : 'text-brand-blue'}>{course.feePerSemester}</strong></span>
                    <button
                      onClick={() => {
                        onPageChange('courses');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="text-brand-gold group-hover:translate-x-1 transition-transform inline-flex items-center gap-1 cursor-pointer font-bold"
                    >
                      Syllabus Details <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. Principal Message Domain */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`rounded-3xl p-8 sm:p-12 border ${
          isDarkMode 
            ? 'bg-gradient-to-br from-brand-blue-light to-brand-blue border-white/5' 
            : 'bg-gradient-to-br from-white to-gray-50/50 border-gray-100 shadow-lg'
        }`}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Img of Principal */}
            <div className="lg:col-span-4 text-center">
              <div className="relative inline-block w-48 h-48 sm:w-56 sm:h-56 rounded-2xl overflow-hidden shadow-lg border-4 border-brand-gold/30 mx-auto">
                <img
                  src="https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=400&q=80"
                  alt="College Principal Dr. S. K. Venugopal"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <h4 className={`text-base font-bold font-display mt-4 ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                Dr. S. K. Venugopal, M.Sc., Ph.D.
              </h4>
              <p className="text-xxs font-bold text-brand-gold uppercase tracking-widest mt-1">
                Principal & Academic Council Head
              </p>
            </div>

            {/* Speech bubble */}
            <div className="lg:col-span-8 space-y-6">
              <span className="inline-flex items-center gap-1 text-xs text-brand-gold font-bold uppercase tracking-wider font-display">
                <Bookmark className="w-3.5 h-3.5" /> Traditional Welcome Address
              </span>
              <h3 className={`text-xl sm:text-2xl font-serif italic ${isDarkMode ? 'text-gray-100' : 'text-gray-800'}`}>
                "Our single absolute target consists of cultivating student competencies with strict character values in Salem."
              </h3>
              
              <div className="text-xs sm:text-sm text-gray-500 space-y-3 font-sans leading-relaxed">
                <p>
                  As the head of this esteemed institution, I feel immensely proud to present the incredible academic horizons open at AVS Arts & Science College. Over the past decades, AVS has established itself as an epicenter of vocational excellence, housing stellar modern computing laboratories, extensive research setups, and highly effective corporate training channels.
                </p>
                <p>
                  We aim beyond standard grades. Our target centers on raising highly ethical citizens equipped with full logical analytical maturity, technological leadership qualifications, and communicative prowess needed to lead global software, commerce and science industries. Look forward to seeing you at our Salem campus.
                </p>
              </div>

              {/* Principal sign */}
              <div className="border-t border-gray-100 dark:border-white/5 pt-4">
                <span className="text-xxs text-gray-400 block uppercase font-mono font-bold">Official Seal Authorized</span>
                <span className="font-serif italic text-sm text-brand-gold mt-1 block">Dr. S. K. Venugopal</span>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 6. Recruiter Logos Domain */}
      <section className={`py-16 border-t border-b ${
        isDarkMode 
          ? 'bg-brand-blue border-white/5' 
          : 'bg-white border-gray-100'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-xxs font-extrabold uppercase tracking-widest text-gray-450 text-brand-gold mb-8">
            Empanelled Corporate Placement Recruiters
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-6 justify-center items-center opacity-85 hover:opacity-100 transition-opacity">
            {RECRUITERS.map((rec, idx) => (
              <div 
                key={idx} 
                className={`p-4 rounded-xl border flex items-center justify-center h-16 ${
                  isDarkMode 
                    ? 'bg-white/5 border-white/5 hover:border-brand-gold/30 hover:bg-white/10' 
                    : 'bg-slate-50 border-gray-100 hover:border-brand-gold/30 hover:bg-white shadow-sm'
                } transition-all duration-300`}
                title={rec.name}
              >
                <span className={`text-[10px] font-bold font-display text-center leading-tight ${isDarkMode ? 'text-white' : 'text-gray-600'}`}>
                  {rec.name.split(' (')[0]}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. Student Testimonial Carousels */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-2 mb-16">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display">Student Success Stories</span>
          <h3 className={`text-3xl font-extrabold tracking-tight font-display ${
            isDarkMode ? 'text-white' : 'text-brand-blue'
          }`}>
            What Our Academic Alumni Say
          </h3>
          <p className="text-xs text-gray-400 max-w-xl mx-auto">
            Discover real career journey stories of students placed straight into global tier-1 MNC development circles from our Salem institution.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((test) => (
            <div
              key={test.id}
              className={`rounded-2xl p-6 border relative flex flex-col justify-between h-full ${
                isDarkMode 
                  ? 'bg-brand-blue-light border-white/5 text-gray-300' 
                  : 'bg-white border-gray-100 shadow-md text-gray-600'
              }`}
            >
              <div className="space-y-4">
                {/* Rating */}
                <div className="flex items-center gap-1 text-brand-gold">
                  {[...Array(test.rating)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-current" />
                  ))}
                </div>

                {/* Quote */}
                <p className="text-xs sm:text-sm font-sans italic leading-relaxed text-gray-450 dark:text-gray-305">
                  "{test.quote}"
                </p>
              </div>

              {/* Profile Card Bottom */}
              <div className="flex items-center gap-3.5 pt-6 mt-6 border-t border-gray-100 dark:border-white/5">
                <img
                  src={test.image}
                  alt={test.name}
                  className="w-11 h-11 rounded-full object-cover border-2 border-brand-gold"
                  referrerPolicy="no-referrer"
                />
                <div className="leading-tight font-sans">
                  <span className={`block font-bold text-xs ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>{test.name}</span>
                  <span className="text-[10px] text-gray-400 font-semibold">{test.course} • Batch {test.batch}</span>
                  {test.company && (
                    <span className="block text-[9px] text-brand-gold font-bold mt-0.5 uppercase tracking-wider">{test.company}</span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 8. Campus Life Spotlight */}
      <section className={`py-20 border-t ${
        isDarkMode 
          ? 'bg-brand-blue-light/20 border-white/5' 
          : 'bg-gray-50/40 border-gray-100'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-2 mb-16">
            <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display">Campus Life Domain</span>
            <h3 className={`text-3xl font-extrabold tracking-tight font-display ${
              isDarkMode ? 'text-white' : 'text-brand-blue'
            }`}>
              Holistic College Living Environment
            </h3>
            <p className="text-xs text-gray-400 max-w-xl mx-auto">
              Our campus space is meticulously planned to offer excellent support for academic analysis, physical fitness, creative cultural exploration, and safe community housing.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {campusHighlights.map((hl, idx) => (
              <div 
                key={idx}
                className={`group rounded-2xl overflow-hidden border shadow-sm hover:shadow-md transition-all ${
                  isDarkMode 
                    ? 'bg-brand-blue border-white/5' 
                    : 'bg-white border-gray-100'
                }`}
              >
                <div className="h-44 overflow-hidden relative">
                  <img
                    src={hl.image}
                    alt={hl.title}
                    className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                </div>
                <div className="p-5 font-sans">
                  <h4 className={`font-display text-sm font-bold tracking-tight mb-2 ${
                    isDarkMode ? 'text-white' : 'text-brand-blue'
                  }`}>
                    {hl.title}
                  </h4>
                  <p className="text-xs text-gray-500 leading-relaxed">
                    {hl.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 9. News & Upcoming Events Sneak */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Latest Announcements Left */}
          <div className="lg:col-span-7 space-y-6">
            <div className="border-b border-gray-100 dark:border-white/5 pb-4">
              <h3 className={`text-2xl font-extrabold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                Latest Campus Announcements
              </h3>
            </div>

            <div className="space-y-4">
              {NEWS_ANNOUNCEMENTS.map((news) => (
                <div
                  key={news.id}
                  className={`p-4 rounded-xl border flex gap-4 ${
                    news.isImportant
                      ? 'border-brand-gold/30 bg-brand-gold/5'
                      : isDarkMode
                        ? 'border-white/5 bg-white/5'
                        : 'border-gray-100 bg-white shadow-sm'
                  }`}
                >
                  <div className="flex flex-col items-center shrink-0">
                    <span className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">{news.date.split(',')[0]}</span>
                    {news.isImportant && (
                      <span className="bg-brand-gold text-black rounded text-[9px] px-1.5 py-0.5 font-bold uppercase tracking-wider font-display mt-2 animate-pulse">
                        HOT
                      </span>
                    )}
                  </div>
                  <div className="space-y-2 font-sans">
                    <h4 className={`text-xs sm:text-sm font-bold tracking-tight ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                      {news.title}
                    </h4>
                    <p className="text-xxs sm:text-xs text-gray-500 leading-relaxed">
                      {news.content}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Upcoming Academic events calendar Right */}
          <div className="lg:col-span-5 space-y-6">
            <div className="flex justify-between items-end border-b border-gray-100 dark:border-white/5 pb-4">
              <h3 className={`text-2xl font-extrabold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                Upcoming Events
              </h3>
              <button
                onClick={() => {
                  onPageChange('events');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="text-xxs font-bold text-brand-gold hover:text-brand-gold-dark cursor-pointer flex items-center gap-0.5"
              >
                Calendar <ChevronRight className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-4">
              {EVENTS.slice(0, 2).map((item) => (
                <div
                  key={item.id}
                  className={`p-4 rounded-xl border flex items-center gap-4 ${
                    isDarkMode ? 'bg-brand-blue border-white/5' : 'bg-white border-gray-100 shadow-sm'
                  }`}
                >
                  {/* Calendar Widget */}
                  <div className="w-16 h-16 rounded-xl overflow-hidden shadow border border-brand-gold/20 flex flex-col shrink-0 text-center font-display">
                    <div className="bg-brand-blue-accent/80 text-white font-bold text-[10px] py-0.5 truncate uppercase">
                      {item.month}
                    </div>
                    <div className="bg-brand-gold text-black font-extrabold text-lg flex-1 flex items-center justify-center leading-none">
                      {item.date}
                    </div>
                  </div>

                  {/* Text Details */}
                  <div className="space-y-1 font-sans">
                    <span className="text-[10px] font-bold text-brand-gold uppercase tracking-wider block font-display">
                      {item.type}
                    </span>
                    <h4 className={`text-xs font-bold leading-tight ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                      {item.title}
                    </h4>
                    <span className="text-[10px] text-gray-400 block flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-brand-gold" /> {item.location}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </section>

    </div>
  );
}
