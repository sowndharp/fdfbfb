import React from 'react';
import { 
  Building2, 
  TrendingUp, 
  GraduationCap, 
  Lightbulb, 
  Award, 
  CheckCircle2, 
  Users, 
  Trophy, 
  ArrowRight
} from 'lucide-react';
import { PLACEMENT_STATS, RECRUITERS, TESTIMONIALS } from '../data/mockData';

interface PlacementsProps {
  isDarkMode: boolean;
}

export default function Placements({ isDarkMode }: PlacementsProps) {
  
  const packageMetrics = [
    { title: "Highest Package", val: PLACEMENT_STATS.highestPackage, label: "Offered by Zoho Corporation 2025" },
    { title: "Average Package", val: PLACEMENT_STATS.averagePackage, label: "L1 Software/Finance entries" },
    { title: "Placement Ratio", val: PLACEMENT_STATS.placementRate, label: "Consistent Year-over-Year" },
    { title: "Rigorous Training", val: PLACEMENT_STATS.trainingHours, label: "Covers Aptitude & Coding" }
  ];

  // Mock historic data for charts
  const historyRecords = [
    { year: "2021", pct: "86.5%", height: "h-[86%]", count: 280 },
    { year: "2022", pct: "89.0%", height: "h-[89%]", count: 310 },
    { year: "2023", pct: "91.4%", height: "h-[91%]", count: 325 },
    { year: "2024", pct: "92.8%", height: "h-[92%]", count: 340 },
    { year: "2025", pct: "93.4%", height: "h-[93%]", count: 355 }
  ];

  return (
    <div id="placements-workspace" className="animate-fade-in mt-[60px] md:mt-[76px]">
      
      {/* Title Jumbotron */}
      <section className="bg-brand-blue text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-brand-blue via-brand-blue/90 to-brand-blue-accent" />
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-gold/15 rounded-full blur-3xl" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center space-y-3">
          <span className="text-xxs font-bold uppercase tracking-widest text-brand-gold px-3.5 py-1.5 rounded-full bg-white/10 border border-white/5 font-display select-none">
            Corporate Alliances
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold font-display leading-none tracking-tight">
            Placements & Training Workdesk
          </h2>
          <p className="text-xs sm:text-sm text-brand-gold-light/80 max-w-2xl mx-auto font-sans">
            Bridging academic talents to world-beating corporate platforms with stellar industrial alliances.
          </p>
        </div>
      </section>

      {/* Main Stats Block Cards */}
      <section className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 font-display">
          {packageMetrics.map((met, idx) => (
            <div 
              key={idx}
              className={`p-6 rounded-3xl border flex flex-col justify-between h-36 relative overflow-hidden ${
                isDarkMode 
                  ? 'bg-brand-blue-light border-white/5 text-white' 
                  : 'bg-white border-gray-150 shadow'
              }`}
            >
              <div className="space-y-1 relative z-10">
                <span className="text-xxs font-bold uppercase tracking-widest text-gray-400 block mb-1">
                  {met.title}
                </span>
                <span className="text-2xl sm:text-3xl font-extrabold text-brand-gold block">
                  {met.val}
                </span>
              </div>
              <p className="text-xxs text-gray-400 relative z-10 font-sans leading-none mt-4 font-semibold">
                {met.label}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Interactive Charts Dashboard & Training Modules Grid */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start font-sans">
          
          {/* Chart dashboard left */}
          <div className="lg:col-span-5 space-y-6">
            <div className="border-b border-gray-150 dark:border-white/5 pb-4">
              <span className="text-[10px] font-bold uppercase tracking-widest text-brand-gold block font-display">Historical Track Records</span>
              <h3 className={`text-xl sm:text-2xl font-extrabold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                Placement Success Chart
              </h3>
            </div>

            {/* Simulated Chart Board */}
            <div className={`p-6 rounded-3xl border ${
              isDarkMode ? 'bg-brand-blue border-white/5' : 'bg-white border-gray-150 shadow-md'
            } space-y-6`}>
              <div className="h-48 flex items-end justify-between px-2 pt-4 relative">
                {/* Grid guidelines background */}
                <div className="absolute inset-0 flex flex-col justify-between pointer-events-none opacity-5 px-1 py-4">
                  <div className="h-px bg-gray-500 w-full" />
                  <div className="h-px bg-gray-500 w-full" />
                  <div className="h-px bg-gray-500 w-full" />
                </div>

                {historyRecords.map((item, idx) => (
                  <div key={idx} className="flex flex-col items-center flex-1 space-y-3 group cursor-pointer relative z-10">
                    <span className="text-[10px] font-bold text-emerald-500 opacity-0 group-hover:opacity-100 transition-opacity">
                      {item.pct}
                    </span>
                    <div className="w-8 sm:w-10 rounded-t-lg bg-gradient-to-t from-brand-blue-accent to-brand-gold flex items-end justify-center transition-all duration-500 group-hover:from-brand-gold group-hover:to-brand-gold-dark h-36">
                      <div className={`w-full ${item.height} bg-brand-gold group-hover:bg-brand-gold-dark rounded-t-lg transition-all`} />
                    </div>
                    <span className={`text-[10px] uppercase font-bold tracking-wider ${isDarkMode ? 'text-white' : 'text-gray-500'}`}>
                      {item.year}
                    </span>
                  </div>
                ))}
              </div>

              <p className="text-xxs sm:text-xs text-gray-500 leading-relaxed font-sans text-center">
                Histological progress mapping from {historyRecords[0].year} representing the continuous increase of successfully empanelled students (above 350+ annually).
              </p>
            </div>
          </div>

          {/* Training Modules right */}
          <div className="lg:col-span-7 space-y-6">
            <div className="border-b border-gray-150 dark:border-white/5 pb-4">
              <span className="text-[10px] font-bold uppercase tracking-widest text-brand-gold block font-display">Specialized Preparation</span>
              <h3 className={`text-xl sm:text-2xl font-extrabold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                Comprehensive Training Curriculum
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {PLACEMENT_STATS.programDetails.map((prog, idx) => (
                <div
                  key={idx}
                  className={`p-5 rounded-2xl border flex flex-col justify-between ${
                    isDarkMode 
                      ? 'bg-brand-blue border-white/5 text-gray-300' 
                      : 'bg-white border-gray-150 shadow-sm text-gray-600'
                  }`}
                >
                  <div className="space-y-2">
                    <div className="w-8 h-8 rounded-xl bg-brand-gold/10 text-brand-gold flex items-center justify-center font-bold text-xs">
                      0{idx+1}
                    </div>
                    <h4 className={`text-xs sm:text-sm font-bold font-display ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>
                      {prog.title}
                    </h4>
                    <p className="text-xxs sm:text-xs text-gray-500 leading-relaxed font-sans">
                      {prog.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </section>

      {/* Recruiter Showcase Grid */}
      <section className={`py-16 border-t border-b ${
        isDarkMode 
          ? 'bg-brand-blue-light/10 border-white/5' 
          : 'bg-slate-50 border-gray-100'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-4">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display">Empanelled Partners</span>
          <h3 className={`text-2xl sm:text-3.5xl font-extrabold tracking-tight font-display ${
            isDarkMode ? 'text-white' : 'text-brand-blue'
          }`}>
            Our Core Placement Recruiters
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-4 justify-center items-center pt-8">
            {RECRUITERS.map((rec, idx) => (
              <div 
                key={idx} 
                className={`p-4 rounded-xl border flex items-center justify-center h-16 ${
                  isDarkMode 
                    ? 'bg-brand-blue border-white/5 hover:border-brand-gold/20' 
                    : 'bg-white border-gray-150 hover:border-brand-gold/20 shadow-sm'
                } transition-all duration-300`}
                title={rec.name}
              >
                <span className={`text-[10px] font-bold font-display text-center leading-tight ${isDarkMode ? 'text-white' : 'text-gray-600'}`}>
                  {rec.name.split(' (')[0]}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Internship Opportunities Column */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-2 max-w-xl mx-auto">
          <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display">Vocational Internships</span>
          <h3 className={`text-2xl sm:text-3.5xl font-extrabold tracking-tight font-display ${
            isDarkMode ? 'text-white' : 'text-brand-blue'
          }`}>
            Active Student Internship Opportunities
          </h3>
          <p className="text-xs text-gray-400">
            Gain invaluable core software engineering and enterprise governance experience prior to graduating from our Salem classrooms.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 font-sans">
          {PLACEMENT_STATS.internships.map((intern, idx) => (
            <div 
              key={idx}
              className={`p-6 rounded-3xl border flex flex-col justify-between ${
                isDarkMode 
                  ? 'bg-brand-blue border-white/5 text-white' 
                  : 'bg-white border-gray-150 shadow-sm'
              }`}
            >
              <div className="space-y-4">
                <span className="text-[10px] font-semibold text-brand-gold uppercase tracking-wider block font-display">
                  Corporate Vacancy
                </span>
                <div className="space-y-1">
                  <h4 className={`text-xs sm:text-sm font-extrabold font-display leading-tight ${isDarkMode ? 'text-blue-200' : 'text-brand-blue'}`}>
                    {intern.position}
                  </h4>
                  <p className="text-xxs sm:text-xs font-bold text-gray-500 font-sans">
                    at {intern.company}
                  </p>
                </div>
              </div>

              <div className="pt-6 mt-6 border-t border-gray-100 dark:border-white/5 flex items-center justify-between text-xxs font-sans font-semibold">
                <span className="text-gray-400">Selected: <strong className={isDarkMode ? 'text-white' : 'text-brand-blue'}>{intern.count} Candidates</strong></span>
                <span className="text-emerald-650 bg-emerald-100 dark:bg-emerald-500/10 dark:text-emerald-400 px-2.5 py-1 rounded-full font-bold">
                  {intern.stipend}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Alumni placement stories */}
      <section className={`py-20 border-t ${
        isDarkMode 
          ? 'bg-brand-blue-light/10 border-white/5' 
          : 'bg-gray-50/50 border-gray-150'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-2 mb-16">
            <span className="text-xs font-bold uppercase tracking-wider text-brand-gold font-display">Alumni Success Spotlight</span>
            <h3 className={`text-3xl font-extrabold tracking-tight font-display ${
              isDarkMode ? 'text-white' : 'text-brand-blue'
            }`}>
              Placed Student Success Stories
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {TESTIMONIALS.map((test) => (
              <div
                key={test.id}
                className={`p-6 rounded-2xl border relative flex flex-col justify-between h-full ${
                  isDarkMode 
                    ? 'bg-brand-blue border-white/5 text-gray-300' 
                    : 'bg-white border-gray-150 shadow-sm text-gray-600'
                }`}
              >
                <p className="text-xs sm:text-sm font-sans italic leading-relaxed text-gray-500">
                  "{test.quote}"
                </p>

                <div className="flex items-center gap-3 pt-6 mt-6 border-t border-gray-100 dark:border-white/5">
                  <img
                    src={test.image}
                    alt={test.name}
                    className="w-10 h-10 rounded-full object-cover border-2 border-brand-gold"
                    referrerPolicy="no-referrer"
                  />
                  <div className="leading-tight font-sans text-xs">
                    <span className={`block font-bold ${isDarkMode ? 'text-white' : 'text-brand-blue'}`}>{test.name}</span>
                    <span className="text-[10px] text-gray-400">{test.course} • {test.batch}</span>
                    <span className="block text-[9px] text-brand-gold font-extrabold uppercase mt-1 tracking-wider">{test.company}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

    </div>
  );
}
