import React from 'react';
import { COLLEGE_INFO } from '../data/mockData';
import { 
  GraduationCap, 
  MapPin, 
  PhoneCall, 
  Mail, 
  Clock, 
  ChevronRight, 
  Facebook, 
  Instagram, 
  Twitter, 
  Linkedin
} from 'lucide-react';

interface FooterProps {
  onPageChange: (page: string) => void;
  isDarkMode: boolean;
}

export default function Footer({ onPageChange, isDarkMode }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const handleLinkClick = (pageId: string) => {
    onPageChange(pageId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const collegeLinks = [
    { page: 'about', label: 'History & Accredits' },
    { page: 'about', label: 'Principal & Chairman Message' },
    { page: 'departments', label: 'Academic Departments' },
    { page: 'courses', label: 'Search College Courses' },
    { page: 'about', label: 'Campus Facilities' }
  ];

  const studentLinks = [
    { page: 'admissions', label: 'Admission Procedure' },
    { page: 'admissions', label: 'Eligibility & Fees' },
    { page: 'placements', label: 'Placement Records' },
    { page: 'placements', label: 'Training & Internships' },
    { page: 'gallery', label: 'Campus Gallery' }
  ];

  const socialChannels = [
    { name: 'Facebook', icon: <Facebook className="w-4 h-4" />, href: 'https://facebook.com' },
    { name: 'Instagram', icon: <Instagram className="w-4 h-4" />, href: 'https://instagram.com' },
    { name: 'Twitter', icon: <Twitter className="w-4 h-4" />, href: 'https://twitter.com' },
    { name: 'LinkedIn', icon: <Linkedin className="w-4 h-4" />, href: 'https://linkedin.com' }
  ];

  return (
    <footer 
      id="main-footer"
      className={`relative pt-16 pb-8 font-display border-t ${
        isDarkMode 
          ? 'bg-brand-blue border-white/5 text-gray-300' 
          : 'bg-brand-blue border-brand-blue-accent text-gray-300'
      }`}
    >
      {/* Decorative Gold Border */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-gold via-brand-gold-light to-brand-gold-dark" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Logo & Statement */}
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-brand-gold flex items-center justify-center shadow-md">
                <GraduationCap className="w-6 h-6 text-brand-blue" />
              </div>
              <div>
                <h3 className="text-white text-base font-bold tracking-tight leading-none">
                  AVS <span className="text-brand-gold">ARTS & SCIENCE</span>
                </h3>
                <p className="text-xxs uppercase tracking-wider font-semibold text-brand-gold-light/75">
                  Salem • Tamil Nadu
                </p>
              </div>
            </div>
            
            <p className="text-xs text-gray-400 leading-relaxed font-sans">
              Founded on principles of educational brilliance and holistic integrity, AVS Arts & Science College empowers students with industrial competence and strong characters.
            </p>

            {/* Social Grid */}
            <div className="flex items-center space-x-3.5">
              {socialChannels.map((chan) => (
                <a
                  key={chan.name}
                  href={chan.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-gray-400 hover:text-brand-gold hover:bg-brand-gold/10 hover:border-brand-gold/30 transition-all duration-300"
                  aria-label={chan.name}
                >
                  {chan.icon}
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links Group A */}
          <div>
            <h4 className="text-white text-sm font-bold tracking-wider uppercase mb-6 flex items-center gap-2">
              <span className="w-1.5 h-3 bg-brand-gold rounded-full" />
              Academics
            </h4>
            <ul className="space-y-3">
              {collegeLinks.map((item, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => handleLinkClick(item.page)}
                    className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-brand-gold transition-colors duration-200 group text-left w-full cursor-pointer"
                  >
                    <ChevronRight className="w-3.5 h-3.5 text-brand-gold/50 group-hover:translate-x-1 transition-transform" />
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links Group B */}
          <div>
            <h4 className="text-white text-sm font-bold tracking-wider uppercase mb-6 flex items-center gap-2">
              <span className="w-1.5 h-3 bg-brand-gold rounded-full" />
              Admissions & Life
            </h4>
            <ul className="space-y-3">
              {studentLinks.map((item, idx) => (
                <li key={idx}>
                  <button
                    onClick={() => handleLinkClick(item.page)}
                    className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-brand-gold transition-colors duration-200 group text-left w-full cursor-pointer"
                  >
                    <ChevronRight className="w-3.5 h-3.5 text-brand-gold/50 group-hover:translate-x-1 transition-transform" />
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Coordinates */}
          <div className="space-y-5">
            <h4 className="text-white text-sm font-bold tracking-wider uppercase flex items-center gap-2">
              <span className="w-1.5 h-3 bg-brand-gold rounded-full" />
              Contact Office
            </h4>
            
            <div className="space-y-3.5 text-xs text-gray-400 font-sans">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-brand-gold shrink-0 mt-0.5" />
                <span>{COLLEGE_INFO.location}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <PhoneCall className="w-4 h-4 text-brand-gold shrink-0" />
                <span>{COLLEGE_INFO.phone}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-brand-gold shrink-0" />
                <span>{COLLEGE_INFO.email}</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Clock className="w-4 h-4 text-brand-gold shrink-0" />
                <span>{COLLEGE_INFO.officeHours}</span>
              </div>
            </div>
          </div>

        </div>

        {/* Divider */}
        <div className="h-px bg-white/5 mb-8" />

        {/* Copyright Panel */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-xxs font-sans text-gray-400">
          <div className="text-center md:text-left">
            <p>© {currentYear} {COLLEGE_INFO.name}. All Rights Reserved.</p>
            <p className="mt-1 text-gray-500 text-[10px]">
              Approved by Govt. of Tamil Nadu • Affiliated to Periyar University, Salem • Accredited by NAAC with 'A' Grade
            </p>
          </div>
          <div className="flex items-center gap-1.5 bg-brand-blue-accent/20 border border-white/5 rounded-full px-3.5 py-1.5 shrink-0 text-brand-gold-light/80">
            <GraduationCap className="w-3.5 h-3.5 text-brand-gold" />
            <span>Interactive Student Desk & Prospectus Portal 2026</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
