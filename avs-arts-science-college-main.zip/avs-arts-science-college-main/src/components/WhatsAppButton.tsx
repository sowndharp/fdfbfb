import React, { useState, useEffect } from 'react';
import { MessageCircle, X, Check, HeartHandshake } from 'lucide-react';
import { COLLEGE_INFO } from '../data/mockData';

export default function WhatsAppButton() {
  const [isOpen, setIsOpen] = useState(false);
  const [hasPrompted, setHasPrompted] = useState(false);

  useEffect(() => {
    // Show a small helpful overlay bubble after 8 seconds of first visit
    const timer = setTimeout(() => {
      setHasPrompted(true);
    }, 8000);
    return () => clearTimeout(timer);
  }, []);

  const handleWhatsAppRedirect = () => {
    const formattedPhone = COLLEGE_INFO.whatsapp.replace(/\+/g, '').replace(/\s/g, '');
    const textMsg = encodeURIComponent("Hello AVS Admissions Helpdesk! I would like to enquire about Admissions requirements for the 2026-27 academic year.");
    window.open(`https://wa.me/${formattedPhone}?text=${textMsg}`, '_blank');
  };

  return (
    <div id="whatsapp-floating" className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      
      {/* Mini Counseling Popup Dialog */}
      {(hasPrompted && !isOpen) && (
        <div className="bg-white text-gray-800 text-xs px-4 py-2.5 rounded-xl shadow-xl border border-gray-100 max-w-xs mb-3 font-sans animate-bounce relative flex items-center gap-2">
          <HeartHandshake className="w-4 h-4 text-emerald-500 shrink-0" />
          <span>Need help with admissions? Chat live with us!</span>
          <button 
            onClick={() => setHasPrompted(false)}
            className="p-0.5 text-gray-400 hover:text-gray-700 ml-1 rounded-full hover:bg-gray-100"
          >
            <X className="w-3.5 h-3.5" />
          </button>
          <div className="absolute bottom-[-6px] right-5 w-3 h-3 bg-white border-r border-b border-gray-100 rotate-45" />
        </div>
      )}

      {/* Main Panel */}
      {isOpen && (
        <div id="whatsapp-info-panel" className="bg-white rounded-2xl shadow-2xl border border-gray-100 w-80 mb-4 overflow-hidden font-sans transition-all duration-300">
          {/* Header */}
          <div className="bg-emerald-600 p-4 text-white flex justify-between items-center">
            <div className="flex items-center gap-2.5">
              <div className="relative">
                <MessageCircle className="w-10 h-10 text-emerald-100" />
                <span className="absolute bottom-0.5 right-0.5 w-3 h-3 bg-green-400 border-2 border-white rounded-full" />
              </div>
              <div>
                <h4 className="font-semibold text-sm leading-tight">AVS Office Helpdesk</h4>
                <p className="text-xxs text-emerald-100 flex items-center gap-1">
                  <Check className="w-3 h-3 text-emerald-200" /> Typically replies within 5 minutes
                </p>
              </div>
            </div>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-white/80 hover:text-white p-1 hover:bg-emerald-700 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Chat Body */}
          <div className="p-4 bg-gray-50 max-h-60 overflow-y-auto space-y-3.5">
            <div className="bg-white rounded-xl p-3 border border-gray-100 shadow-sm text-xs text-gray-700">
              <span className="font-medium text-emerald-600 block mb-1 font-display">Admissions Counselor Priya</span>
              <p className="leading-relaxed">
                Welcome to AVS Arts & Science College, Salem!
              </p>
              <p className="mt-1">
                How can we support you today? Feel free to ask about our undergraduate programs, fee waivers, or hostel seats!
              </p>
            </div>
          </div>

          {/* Action Box */}
          <div className="p-3 bg-white border-t border-gray-100">
            <button
              onClick={handleWhatsAppRedirect}
              className="w-full flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs py-2.5 rounded-xl shadow transition-all transform hover:-translate-y-0.5 cursor-pointer"
            >
              <MessageCircle className="w-4 h-4" />
              Start Counseling Chat
            </button>
          </div>
        </div>
      )}

      {/* Floating Toggle Button */}
      <button
        onClick={() => {
          setIsOpen(!isOpen);
          setHasPrompted(false);
        }}
        className="w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white flex items-center justify-center shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 select-none relative focus:outline-none cursor-pointer"
        aria-label="Contact Admissions Helpdesk on WhatsApp"
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageCircle className="w-7 h-7" />}
        {!isOpen && (
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-amber-500 border-2 border-white rounded-full animate-ping" />
        )}
      </button>

    </div>
  );
}
