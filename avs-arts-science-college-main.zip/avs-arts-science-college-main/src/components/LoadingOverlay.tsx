import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { GraduationCap } from 'lucide-react';

interface LoadingOverlayProps {
  isDarkMode: boolean;
}

export default function LoadingOverlay({ isDarkMode }: LoadingOverlayProps) {
  const loadingTexts = [
    "Initializing Campus Portal...",
    "Securing Academic Connection...",
    "Synchronizing Course Catalogs...",
    "Loading Digital Student Desk..."
  ];

  const [currentTextIndex, setCurrentTextIndex] = useState(0);

  useEffect(() => {
    const textInterval = setInterval(() => {
      setCurrentTextIndex((prev) => (prev + 1) % loadingTexts.length);
    }, 1500);

    return () => clearInterval(textInterval);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3, ease: "easeInOut" }}
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center ${
        isDarkMode 
          ? 'bg-brand-blue/98 text-white' 
          : 'bg-white/98 text-brand-blue'
      } backdrop-blur-md`}
    >
      <div className="relative flex flex-col items-center">
        {/* Spinner Rings Container */}
        <div className="relative w-24 h-24 flex items-center justify-center">
          
          {/* Outer Ring - Gold (Clockwise) */}
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
            className={`absolute w-20 h-20 rounded-full border-4 border-t-brand-gold border-r-transparent border-b-brand-gold/10 border-l-transparent`}
          />

          {/* Inner Ring - Blue/Light Gold (Counter Clockwise) */}
          <motion.div 
            animate={{ rotate: -360 }}
            transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
            className={`absolute w-14 h-14 rounded-full border-4 ${
              isDarkMode 
                ? 'border-t-brand-gold-light border-r-transparent border-b-white/5 border-l-transparent' 
                : 'border-t-brand-blue-accent border-r-transparent border-b-brand-blue/5 border-l-transparent'
            }`}
          />

          {/* Core Symbol - Graduation Cap Pulsing */}
          <motion.div
            animate={{ scale: [0.92, 1.08, 0.92] }}
            transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
            className="z-10 flex items-center justify-center bg-brand-gold/15 p-2.5 rounded-full border border-brand-gold/30"
          >
            <GraduationCap className="w-6 h-6 text-brand-gold" />
          </motion.div>
        </div>

        {/* Brand Text Header */}
        <h3 className="mt-8 font-display font-bold text-lg tracking-wider uppercase">
          AVS <span className="text-brand-gold">Arts & Science</span>
        </h3>

        {/* Dynamic Loading Messages */}
        <div className="mt-2 h-6 flex items-center justify-center overflow-hidden">
          <motion.p
            key={currentTextIndex}
            initial={{ y: 15, opacity: 0 }}
            animate={{ y: 0, opacity: 0.75 }}
            exit={{ y: -15, opacity: 0 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="text-xs font-mono font-medium tracking-wide"
          >
            {loadingTexts[currentTextIndex]}
          </motion.p>
        </div>

        {/* Accidental micro-loading bar */}
        <div className="w-32 h-1 bg-gray-200 dark:bg-white/10 rounded-full mt-4 overflow-hidden relative">
          <motion.div 
            initial={{ left: "-100%" }}
            animate={{ left: "100%" }}
            transition={{ repeat: Infinity, duration: 1.25, ease: "easeInOut" }}
            className="absolute top-0 bottom-0 w-1/2 bg-brand-gold rounded-full"
          />
        </div>
      </div>
    </motion.div>
  );
}
