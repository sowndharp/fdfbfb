import React, { useState, useEffect } from 'react';
import { ArrowRight, X, Award, Flame } from 'lucide-react';

interface StickyConversionBarProps {
  onApplyClick: () => void;
  isDarkMode: boolean;
}

export default function StickyConversionBar({ onApplyClick, isDarkMode }: StickyConversionBarProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  useEffect(() => {
    // Show sticky bottom bar after scrolling down 300px
    const handleScroll = () => {
      if (window.scrollY > 300 && !isDismissed) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isDismissed]);

  if (!isVisible) return null;

  return (
    <div 
      id="sticky-conversion-ribbon"
      className="fixed bottom-0 left-0 right-0 z-40 p-4 transition-all duration-550 transform translate-y-0 animate-fade-in"
    >
      <div className={`max-w-6xl mx-auto rounded-2xl md:rounded-full border shadow-2xl relative overflow-hidden p-4 md:py-3.5 md:px-8 flex flex-col md:flex-row justify-between items-center gap-4 ${
        isDarkMode
          ? 'bg-gradient-to-r from-brand-blue via-brand-blue-accent to-brand-blue border-brand-gold/30 text-white'
          : 'bg-gradient-to-r from-brand-blue via-brand-blue/95 to-brand-blue-accent border-brand-gold/40 text-white shadow-brand-gold/10'
      }`}>
        {/* Visual Gold Ambient Light inside the pill */}
        <div className="absolute top-0 right-0 w-44 h-44 bg-brand-gold/10 rounded-full blur-2xl pointer-events-none" />
        
        {/* Dismiss trigger */}
        <button
          onClick={() => {
            setIsVisible(false);
            setIsDismissed(true);
          }}
          className="absolute top-2.5 right-4 md:static md:order-last p-1 text-white/60 hover:text-white hover:bg-white/10 rounded-full transition-all cursor-pointer"
          aria-label="Close bottom announcement"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Content Info Frame */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="w-9 h-9 rounded-xl bg-brand-gold/20 border border-brand-gold/35 flex items-center justify-center text-brand-gold shrink-0 animate-bounce">
            <Award className="w-4.5 h-4.5" />
          </div>
          <div className="leading-tight font-display text-xs">
            <div className="flex items-center gap-2">
              <span className="text-[10px] uppercase font-bold text-brand-gold tracking-widest flex items-center gap-1">
                <Award className="w-3.5 h-3.5" /> Admissions 2026-27 Open!
              </span>
              <span className="bg-red-500/85 text-white text-[8px] font-extrabold uppercase px-1.5 py-0.5 rounded tracking-wide animate-pulse inline-flex items-center gap-0.5">
                <Flame className="w-2.5 h-2.5" /> Fast Filling
              </span>
            </div>
            <p className="text-[11px] sm:text-xs text-gray-200 mt-1 font-sans">
              Avail Up To <strong className="text-brand-gold">50% Merit Waiver Scholarships</strong> on standard Class XII rankings.
            </p>
          </div>
        </div>

        {/* CTA Buttons Layout */}
        <div className="flex items-center gap-3 w-full md:w-auto shrink-0 justify-end">
          <button
            onClick={onApplyClick}
            className="flex-1 md:flex-initial text-center bg-brand-gold hover:bg-brand-gold-dark hover:scale-103 text-black text-xs font-extrabold px-6 py-2.5 rounded-full md:rounded-full shadow-lg font-display flex items-center justify-center gap-1.5 transition-all transform duration-150 cursor-pointer cursor-pointer relative overflow-hidden group"
          >
            {/* Elegant shine animation inside target button */}
            <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-white/0 via-white/20 to-white/0 -translate-x-full group-hover:animate-shine" />
            Apply Online Desk
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
}
