import React, { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Menu, X, Sun, Moon, PhoneCall, GraduationCap, ArrowRight } from 'lucide-react';
import { COLLEGE_INFO } from '../data/mockData';

interface HeaderProps {
  currentPage: string;
  onPageChange: (page: string) => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

export default function Header({ currentPage, onPageChange, isDarkMode, onToggleDarkMode }: HeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Us' },
    { id: 'admissions', label: 'Admissions' },
    { id: 'register', label: 'Register Online' },
    { id: 'courses', label: 'Courses' },
    { id: 'departments', label: 'Departments' },
    { id: 'placements', label: 'Placements' },
    { id: 'events', label: 'Events & News' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'contact', label: 'Contact Us' }
  ];

  const handleNavClick = (pageId: string) => {
    onPageChange(pageId);
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header 
      id="main-header"
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled 
          ? isDarkMode 
            ? 'bg-brand-blue/95 border-b border-white/10 shadow-lg' 
            : 'bg-white/95 border-b border-gray-100 shadow-md backdrop-blur-md'
          : isDarkMode
            ? 'bg-transparent border-b border-white/5'
            : 'bg-brand-blue border-b border-brand-blue-accent'
      }`}
    >
      {/* Top Bar for contact, visible on scroll-up or top banner */}
      <div className={`hidden md:block py-1.5 px-6 font-display text-xs border-b transition-colors duration-300 ${
        isScrolled 
          ? isDarkMode 
            ? 'border-white/5 text-gray-400 bg-brand-blue-light/50' 
            : 'border-gray-100 text-gray-500 bg-gray-50'
          : 'border-white/10 text-brand-gold-light/90 bg-brand-blue-light/60'
      }`}>
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-6">
            <span className="flex items-center gap-1.5">
              <PhoneCall className="w-3.5 h-3.5 text-brand-gold" /> {COLLEGE_INFO.phone}
            </span>
            <span>{COLLEGE_INFO.affiliation}</span>
          </div>
          <div className="flex items-center space-x-6">
            <span className="bg-brand-gold/15 text-brand-gold font-semibold px-2 py-0.5 rounded border border-brand-gold/20">
              {COLLEGE_INFO.accreditation}
            </span>
            <span>Estd. {COLLEGE_INFO.established}</span>
          </div>
        </div>
      </div>

      {/* Main Header Row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex justify-between items-center">
        {/* College Brand Logo Area */}
        <div 
          id="header-brand-logo"
          className="flex items-center gap-3 cursor-pointer shrink-0"
          onClick={() => handleNavClick('home')}
        >
          <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-brand-gold flex items-center justify-center shadow-inner transform hover:rotate-12 transition-transform duration-300">
            <GraduationCap className="w-6 h-6 md:w-7 md:h-7 text-brand-blue" />
          </div>
          <div className="flex flex-col">
            <h1 className={`font-display text-sm md:text-lg font-bold leading-none tracking-tight transition-colors duration-300 ${
              isScrolled && !isDarkMode ? 'text-brand-blue' : 'text-white'
            }`}>
              AVS <span className="text-brand-gold">ARTS & SCIENCE</span>
            </h1>
            <p className={`font-display text-[9px] md:text-xxs uppercase tracking-wider font-semibold opacity-85 transition-colors duration-300 ${
              isScrolled && !isDarkMode ? 'text-gray-500' : 'text-brand-gold-light/80'
            }`}>
              College • Salem • NAAC 'A' Grade
            </p>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav id="desktop-nav" className="hidden lg:flex items-center space-x-1">
          {navItems.map((item) => {
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`px-3 py-2 rounded-lg text-xs font-semibold ring-offset-zinc-900 focus:outline-none transition-all duration-200 relative ${
                  isActive
                    ? 'text-brand-gold bg-brand-gold/10'
                    : isScrolled && !isDarkMode
                      ? 'text-gray-600 hover:text-brand-blue hover:bg-gray-100'
                      : 'text-white/80 hover:text-white hover:bg-white/5'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-1/4 right-1/4 h-0.5 bg-brand-gold rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Utility Actions (Theme Toggler & Apply Button) */}
        <div id="header-utilities" className="flex items-center gap-2 sm:gap-3">
          {/* Theme Toggler */}
          <button
            onClick={onToggleDarkMode}
            className={`p-2 rounded-lg transition-colors. duration-200 ${
              isScrolled && !isDarkMode
                ? 'text-gray-500 hover:bg-gray-100 hover:text-brand-blue'
                : 'text-white/80 hover:bg-white/5 hover:text-white'
            }`}
            aria-label="Toggle theme color"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-brand-gold" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Apply CTA Button */}
          <button
            onClick={() => handleNavClick('register')}
            className="hidden sm:flex items-center gap-1.5 bg-brand-gold hover:bg-brand-gold-dark text-black px-4.5 py-2.5 rounded-full text-xs font-extrabold shadow-md hover:shadow-lg transition-all transform hover:-translate-y-0.5 cursor-pointer animate-pulse-glow relative overflow-hidden group"
          >
            <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-white/0 via-white/25 to-white/0 -translate-x-full group-hover:animate-shine" />
            Apply Now 2026
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          {/* Mobile hamburger trigger */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`lg:hidden p-2 rounded-lg ${
              isScrolled && !isDarkMode
                ? 'text-brand-blue hover:bg-gray-100'
                : 'text-white hover:bg-white/5'
            }`}
            aria-label="Toggle mobile menu"
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Mobile menu slide-in drawer */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            {/* Backdrop Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="fixed inset-0 z-55 bg-black/60 backdrop-blur-sm lg:hidden"
              onClick={() => setIsMobileMenuOpen(false)}
              aria-hidden="true"
            />

            {/* Slider Drawer Container */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 220 }}
              className={`fixed top-0 right-0 h-full w-[320px] max-w-[85vw] shadow-2xl z-60 lg:hidden flex flex-col justify-between ${
                isDarkMode 
                  ? 'bg-brand-blue border-l border-white/10 text-white' 
                  : 'bg-white border-l border-gray-100 text-gray-800'
              }`}
            >
              {/* Drawer Top Header Row */}
              <div className="p-4 flex justify-between items-center border-b border-gray-200/40 dark:border-white/10 shrink-0">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-brand-gold flex items-center justify-center">
                    <GraduationCap className="w-5 h-5 text-brand-blue" />
                  </div>
                  <div>
                    <h2 className="font-display font-bold text-sm tracking-wide uppercase">
                      AVS <span className="text-brand-gold">CAMPUS</span>
                    </h2>
                    <p className="font-display text-[9px] uppercase tracking-wider text-gray-400">
                      Menu Navigation
                    </p>
                  </div>
                </div>
                
                {/* Close Trigger Button */}
                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={`p-1.5 rounded-lg border transition-colors ${
                    isDarkMode 
                      ? 'border-white/15 text-white/80 hover:bg-white/10 hover:text-white' 
                      : 'border-gray-200 text-gray-500 hover:bg-gray-100 hover:text-brand-blue'
                  }`}
                  aria-label="Close menu drawer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Navigation and Actions */}
              <div className="flex-1 overflow-y-auto px-4 py-6 space-y-1">
                {navItems.map((item) => {
                  const isActive = currentPage === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleNavClick(item.id)}
                      className={`block w-full text-left px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                        isActive
                          ? 'text-brand-gold bg-brand-gold/15 border-l-4 border-brand-gold pl-5'
                          : isDarkMode
                            ? 'text-gray-300 hover:text-white hover:bg-white/10 pl-4'
                            : 'text-gray-700 hover:text-brand-blue hover:bg-gray-100 pl-4'
                      }`}
                    >
                      {item.label}
                    </button>
                  );
                })}
              </div>

              {/* Drawer Footer Panel */}
              <div className="p-4 border-t border-gray-200/40 dark:border-white/10 space-y-4 shrink-0 bg-gray-50/50 dark:bg-brand-blue-light/30">
                <button
                  onClick={() => handleNavClick('register')}
                  className="w-full text-center flex items-center justify-center gap-2 bg-brand-gold hover:bg-brand-gold-dark text-black py-3.5 rounded-xl font-extrabold text-sm shadow-md transition-all relative overflow-hidden group"
                >
                  Apply Now 2026-27
                  <ArrowRight className="w-4 h-4" />
                </button>
                <div className="text-center font-display text-[10px] text-gray-500 dark:text-gray-400">
                  <p className="font-semibold">{COLLEGE_INFO.name}</p>
                  <p className="opacity-80 mt-0.5">Salem, Tamil Nadu, India</p>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  );
}
