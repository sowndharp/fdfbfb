import React, { useState, useEffect } from 'react';
import { X, Award, Trophy, ArrowRight, BookOpen } from 'lucide-react';

interface AdmissionPopupProps {
  onApplyClick: () => void;
}

export default function AdmissionPopup({ onApplyClick }: AdmissionPopupProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Show popup 3.5 seconds after landing
    const isDismissed = sessionStorage.getItem('avs_admission_dismissed');
    if (!isDismissed) {
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleDismiss = () => {
    setIsVisible(false);
    sessionStorage.setItem('avs_admission_dismissed', 'true');
  };

  const handleAction = () => {
    onApplyClick();
    handleDismiss();
  };

  if (!isVisible) return null;

  return (
    <div id="admission-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div 
        id="admission-popup-box"
        className="relative w-full max-w-lg bg-gradient-to-b from-brand-blue-light to-brand-blue rounded-3xl border border-brand-gold/30 shadow-2xl p-6 sm:p-8 overflow-hidden text-white font-sans max-h-[90vh] overflow-y-auto"
      >
        {/* Subtle Decorative Gold Lights */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-brand-gold/10 rounded-full blur-2xl" />
        <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-brand-gold/5 rounded-full blur-2xl" />

        {/* Close Button */}
        <button
          onClick={handleDismiss}
          className="absolute top-4 right-4 p-1.5 rounded-full bg-white/10 text-white/75 hover:text-white hover:bg-white/20 transition-all cursor-pointer"
          aria-label="Dismiss admissions modal"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Badge header */}
        <div className="flex items-center gap-2 bg-brand-gold/15 text-brand-gold px-3.5 py-1.5 rounded-full text-[10px] uppercase font-bold tracking-wider w-max mb-5 border border-brand-gold/30 font-display">
          <Award className="w-3.5 h-3.5 animate-pulse" />
          <span>UG & PG Admissions Open 2026-27</span>
        </div>

        {/* Content Heading */}
        <div className="space-y-1.5 mb-6">
          <span className="text-xxs uppercase tracking-widest text-brand-gold-light/75 font-mono block">AVS Arts & Science College, Salem</span>
          <h3 className="font-display text-2xl sm:text-3xl font-black text-white tracking-tight leading-none">
            Secure Your Professional Future Today
          </h3>
          <p className="text-xs text-gray-300 leading-relaxed font-sans">
            Affiliated to Periyar University • NAAC 'A' Accredited Institution • Leading the state in technological & commerce literacy.
          </p>
        </div>

        {/* Body content info with custom Bento layout */}
        <div className="space-y-3 mb-8 font-sans text-xs">
          <div className="p-4 bg-white/5 border border-white/5 rounded-2xl flex items-start gap-3.5 hover:border-brand-gold/20 transition-all duration-300">
            <div className="w-8 h-8 rounded-lg bg-brand-gold/10 text-brand-gold flex items-center justify-center shrink-0 border border-brand-gold/20">
              <Trophy className="w-4.5 h-4.5" />
            </div>
            <div>
              <span className="font-bold text-white block mb-0.5 font-display text-[11px] uppercase tracking-wide">1. Merit Scholarship Reward Structure</span>
              <p className="text-gray-400 text-xxs sm:text-xs leading-relaxed">
                Unlock **25% to 50% tuition waiver grants** automatically determined based on your Class XII board score records. No hidden criteria.
              </p>
            </div>
          </div>

          <div className="p-4 bg-white/5 border border-white/5 rounded-2xl flex items-start gap-3.5 hover:border-brand-gold/20 transition-all duration-300">
            <div className="w-8 h-8 rounded-lg bg-brand-gold/10 text-brand-gold flex items-center justify-center shrink-0 border border-brand-gold/20">
              <BookOpen className="w-4.5 h-4.5" />
            </div>
            <div>
              <span className="font-bold text-white block mb-0.5 font-display text-[11px] uppercase tracking-wide">2. Elite Corporate Placement Ready</span>
              <p className="text-gray-400 text-xxs sm:text-xs leading-relaxed">
                Intensive **Aptitude & Coding Bootcamp training** provided for streamlined recruitments into TCS, Zoho, Infosys, and Cognizant.
              </p>
            </div>
          </div>

          <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-center">
            <p className="text-xxs sm:text-xs font-bold text-red-250 italic">
              ⚡ Notice: Final round merit enrollment lists close soon for B.Sc CS, BCA & Commerce streams.
            </p>
          </div>
        </div>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={handleAction}
            className="flex-1 text-center justify-center flex items-center gap-2 bg-brand-gold hover:bg-brand-gold-dark text-black leading-none font-bold text-xs py-4 px-6 rounded-xl shadow-lg transition-all transform hover:-translate-y-0.5 cursor-pointer relative overflow-hidden group font-display uppercase tracking-wider"
          >
            <span className="absolute inset-0 w-full h-full bg-gradient-to-r from-white/0 via-white/20 to-white/0 -translate-x-full group-hover:animate-shine" />
            Apply Online Desk
            <ArrowRight className="w-4 h-4" />
          </button>
          
          <a
            href="tel:04272112233"
            className="flex-1 text-center justify-center flex items-center bg-white/10 border border-white/10 hover:bg-white/20 text-white font-bold text-xs py-4 px-6 rounded-xl transition-all cursor-pointer font-display uppercase tracking-wider"
          >
            Call counselor
          </a>
        </div>

        <p className="text-center text-xxs text-gray-500 mt-5 leading-none">
          Approved by Govt. of Tamil Nadu • Affiliated to Periyar University
        </p>

      </div>
    </div>
  );
}
