import {
  Course,
  Department,
  PlacementRecord,
  Recruiter,
  Testimonial,
  GalleryItem,
  CollegeEvent,
  NewsAnnouncement,
  FAQItem
} from '../types';

export const COLLEGE_INFO = {
  name: "AVS Arts & Science College",
  motto: "Knowledge is Power • Character is Destiny",
  established: "2006",
  affiliation: "Affiliated to Periyar University, Salem",
  accreditation: "Accredited by NAAC with 'A' Grade (3rd Cycle)",
  location: "Attur Main Road, Ramalingapuram, Salem - 636106, Tamil Nadu, India",
  email: "admissions@avscollege.ac.in",
  phone: "+91 63846 88085",
  whatsapp: "+91 63846 88085",
  officeHours: "Monday - Saturday: 9:00 AM - 5:00 PM",
  mapsEmbedUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3908.431248060824!2d78.232371!3d11.6025178!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bab912a76fc3d7b%3A0xe54e60fc31d904b7!2sAVS%20College%20of%20Arts%20%26%20Science!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
};

export const COURSES: Course[] = [
  // UG COURSES
  {
    id: "bsc-cs",
    code: "AVS-UG-101",
    name: "B.Sc Computer Science",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 with Mathematics or Computer Science as a core subject.",
    description: "Build a strong foundation in modern computing architecture, software development methodologies, database engineering, and cybersecurity protocols. The course includes hands-on training in contemporary program design.",
    opportunities: [
      "Software Engineer / Developer",
      "Database Administrator",
      "System Representative",
      "Web Applications Consultant",
      "Network Administrator",
      "IT Project Associate"
    ],
    image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹18,500"
  },
  {
    id: "bsc-it",
    code: "AVS-UG-102",
    name: "B.Sc Information Technology",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 with Mathematics, Computer Science, or equivalent technical/commerce stream.",
    description: "Master computational systems administration, network architectures, data communication systems, cloud infrastructure operations, and corporate software solutions.",
    opportunities: [
      "IT Systems Consultant",
      "Network Support Specialist",
      "Cloud Operations Analyst",
      "Technical Support Executive",
      "Web Infrastructure Manager"
    ],
    image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹18,000"
  },
  {
    id: "bsc-aids",
    code: "AVS-UG-103",
    name: "B.Sc AI & Data Science",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 with Mathematics/Computer Science as mandatory core subjects.",
    description: "An advanced specialized program in predictive analytics, large language frameworks, mathematical modeling, and enterprise data visualization techniques.",
    opportunities: [
      "Junior Data Analyst",
      "AI Pipeline Architect",
      "Data Visualization Expert",
      "Predictive Modeler",
      "Business Intelligence Analyst"
    ],
    image: "https://images.unsplash.com/photo-1527474305487-b87b222841cc?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹22,000"
  },
  {
    id: "bsc-aiml",
    code: "AVS-UG-104",
    name: "B.Sc AI & ML",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 with Mathematics or Computer Science.",
    description: "Focuses on deep learning systems, neural networks, machine learning algorithms, robotics, and pattern recognition technologies.",
    opportunities: [
      "Machine Learning Operator",
      "Neural Network Analyst",
      "Data Science Specialist",
      "AI Development Engineer",
      "Cognitive Systems Integrator"
    ],
    image: "https://images.unsplash.com/photo-1507146426996-ef05306b995a?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹22,500"
  },
  {
    id: "bsc-cyber",
    code: "AVS-UG-105",
    name: "B.Sc Cyber Security",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 with Computer Science, Mathematics, or equivalent science group.",
    description: "Specialized defense stream centering ethical hacking, network defense protocols, cyber laws, threat mitigation, and forensic diagnostics.",
    opportunities: [
      "Ethical Hacker / PenTester",
      "Information Security Analyst",
      "Cyber Incident Responder",
      "Security Operations Engineer",
      "Risk & Compliance Associate"
    ],
    image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹21,500"
  },
  {
    id: "bsc-biotech",
    code: "AVS-UG-106",
    name: "B.Sc Biotechnology",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 with Biology, Botany, Zoology, or Biotechnology as core subjects.",
    description: "Explore molecular biology, industrial immunology, genetic engineering models, tissue cultures, and bio-process technologies in state-of-the-art laboratory environments.",
    opportunities: [
      "Research Lab Technician",
      "Bioprocess Coordinator",
      "Quality Control Executive",
      "Pharmaceutical Analyst",
      "Environmental Biosafety Auditor"
    ],
    image: "https://images.unsplash.com/photo-1532187863486-abf9d39d66e8?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹17,500"
  },
  {
    id: "bsc-forensic",
    code: "AVS-UG-107",
    name: "B.Sc Forensic Science",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 with Physics, Chemistry, Biology, or Mathematics.",
    description: "Delve into criminology, fingerprint analysis, chemical forensics, ballot/document analysis, crime scene investigation tools, and analytical toxicology.",
    opportunities: [
      "Forensic Lab Assistant",
      "Document Analyst",
      "Crime Scene Consultant",
      "Toxicology Lab Executive",
      "Private Security Profiler"
    ],
    image: "https://images.unsplash.com/photo-1582719471384-894fbb16e074?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹19,500"
  },
  {
    id: "bsc-viscom",
    code: "AVS-UG-108",
    name: "B.Sc Visual Communication",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 from a recognized board in any stream.",
    description: "Master digital filmmaking, photography, graphic branding design, advertising principles, television production graphics, and cultural media research.",
    opportunities: [
      "Graphic Designer / Brand Specialist",
      "Director of Photography",
      "Video Post-Production Editor",
      "Ad Agency Visual Coordinator",
      "UI/UX Visualizer"
    ],
    image: "https://images.unsplash.com/photo-1551269901-5c5e14c25df7?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹18,500"
  },
  {
    id: "bsc-tfd",
    code: "AVS-UG-109",
    name: "B.Sc Textile & Fashion Designing",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 in any stream from a recognized board.",
    description: "Develop competencies in pattern creation, high-fashion styling, garment fabrication procedures, textile chemical analysis, and computer-aided fashion design tools.",
    opportunities: [
      "Fashion Designer / Stylist",
      "Garment Production Merchandiser",
      "Textile Pattern Visualizer",
      "Boutique Brand Executive",
      "Quality Assurance Controller"
    ],
    image: "https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹16,500"
  },
  {
    id: "bcom",
    code: "AVS-UG-201",
    name: "B.Com",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 with Commerce, Accountancy, or business placement vocational streams.",
    description: "Provides comprehensive corporate commerce literacy, strategic marketing, advanced corporate accounting, tax administration, and financial law insights.",
    opportunities: [
      "Financial Analyst",
      "Accounts Manager",
      "Auditing Assistant",
      "Banking Officer",
      "Taxation Advisory Associate"
    ],
    image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹15,000"
  },
  {
    id: "bcom-ca",
    code: "AVS-UG-202",
    name: "B.Com CA",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 with Commerce/Accountancy/Computer Applications.",
    description: "Blends professional ledger accounting systems with computerized database solutions, spreadsheet modeling, and digital commerce applications.",
    opportunities: [
      "Computerized Accountant",
      "Database Accounts Executive",
      "E-Commerce Business Analyst",
      "Tax Solutions Developer",
      "ERP Administrator"
    ],
    image: "https://images.unsplash.com/photo-1508385082352-7d0e30617b5a?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹16,000"
  },
  {
    id: "bcom-pa",
    code: "AVS-UG-203",
    name: "B.Com Professional Accounting",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 with excellent scores in Accountancy, Commerce, and business maths.",
    description: "An intensive curriculum specifically aligned with CA, ACS, and CMA certification tracks, with heavy training on auditing and advanced accounting standards.",
    opportunities: [
      "CA Associate / Audit Assistant",
      "Corporate Auditor",
      "Management Accountant",
      "Corporate Secretary Clerk",
      "Investment Risk Analyst"
    ],
    image: "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹17,000"
  },
  {
    id: "bba",
    code: "AVS-UG-204",
    name: "BBA",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 in any stream (Commerce or Science).",
    description: "Develop executive administration insights, organizational leadership principles, global marketing tactics, resource allocation skills, and entrepreneurial competencies.",
    opportunities: [
      "Operations Executive",
      "Business Development Officer",
      "Human Resources Coordinator",
      "Corporate Sales Consultant",
      "Assistant Management Associate"
    ],
    image: "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹15,500"
  },
  {
    id: "bba-ca",
    code: "AVS-UG-205",
    name: "BBA (Computer Application)",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 with Commerce, Science, or computer streams.",
    description: "Integrates modern business management theories with practical enterprise cloud computing systems, database administrations, and analytics tools.",
    opportunities: [
      "Business Intelligence Associate",
      "Management Services Analyst",
      "Systems Administrator Assistant",
      "Digital Product Executive",
      "Operation Database Controller"
    ],
    image: "https://images.unsplash.com/photo-1460925895914-a22741746412?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹16,500"
  },
  {
    id: "bca",
    code: "AVS-UG-110",
    name: "BCA",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 with Mathematics, Computer Science, or equivalent commercial computing stream.",
    description: "Focuses on applied corporate technologies, cloud integration, mobile development, and full-stack software implementation inside advanced logic labs.",
    opportunities: [
      "Full Stack Web Developer",
      "Mobile Applications Developer",
      "UI/UX Implementation Specialist",
      "Systems Administrator",
      "Cloud Operations Engineer"
    ],
    image: "https://images.unsplash.com/photo-1547082299-de196ea013d6?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹19,000"
  },
  {
    id: "ba-english",
    code: "AVS-UG-301",
    name: "BA English",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 with English as a primary component subject.",
    description: "Explore canonical global literature, professional written communication paradigms, comparative rhetoric, cultural journalism, and creative publication methods.",
    opportunities: [
      "Editorial Associate",
      "Public Relations Officer",
      "Technical Content Writer",
      "Media Communications Coordinator",
      "Language Trainer / Educator"
    ],
    image: "https://images.unsplash.com/photo-1506880018603-83d5b814b5a6?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹12,000"
  },
  {
    id: "ba-tamil",
    code: "AVS-UG-302",
    name: "BA Tamil",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 with Tamil as a primary subject element.",
    description: "Deep dive into ancient Sangam literature, modern grammar standards, epigraphy, journalistic Tamil writing, and Tamil literary history.",
    opportunities: [
      "Tamil Language Translator",
      "Journalist / Scriptwriter",
      "Public Relations Clerk",
      "Academic Educator",
      "Archeology field clerk"
    ],
    image: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹11,500"
  },
  {
    id: "ba-history",
    code: "AVS-UG-303",
    name: "BA History",
    degree: "UG",
    duration: "3 Years (6 Semesters)",
    eligibility: "Passed 10+2 in any stream from a recognized board.",
    description: "Examine comparative global civilizations, ancient Indian archaeology, public policy histories, administrative evolutions, and global war policies.",
    opportunities: [
      "Archaeological Assistant",
      "History Research Associate",
      "Archivist / Records Manager",
      "Civil Services Aspirant",
      "Tour and Travel Consultant"
    ],
    image: "https://images.unsplash.com/photo-1461360370896-922624d12aa1?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹12,000"
  },

  // PG COURSES
  {
    id: "msc-cs",
    code: "AVS-PG-101",
    name: "M.Sc Computer Science",
    degree: "PG",
    duration: "2 Years (4 Semesters)",
    eligibility: "Graduation in B.Sc CS / BCA / B.Sc IT with minimum 55% aggregate marks.",
    description: "In-depth specialization exploring modern Artificial Intelligence models, deep learning pipelines, serverless deployment architectures, and automated system optimizations.",
    opportunities: [
      "AI & Machine Learning Engineer",
      "Senior Software Architect",
      "Data Scientist",
      "Cloud Solutions Developer",
      "Research Scientist"
    ],
    image: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹24,000"
  },
  {
    id: "mcom",
    code: "AVS-PG-201",
    name: "M.Com",
    degree: "PG",
    duration: "2 Years (4 Semesters)",
    eligibility: "Graduation in B.Com / BBA with a minimum 50% aggregate score.",
    description: "Master modern economic analytics, advanced auditing practices, international finance structures, corporate taxation paradigms, and computer-supported enterprise auditing solutions.",
    opportunities: [
      "Taxation Specialist",
      "Senior Financial Auditor",
      "Management Accountant",
      "Treasury Risk Analyst",
      "Research Fellow"
    ],
    image: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹20,000"
  },
  {
    id: "mcom-ca",
    code: "AVS-PG-202",
    name: "M.Com CA",
    degree: "PG",
    duration: "2 Years (4 Semesters)",
    eligibility: "Graduation in B.Com CA / B.Com / BCA with 50% minimum marks.",
    description: "High-level integration of corporate accounting architectures with advanced database query systems, customized financial ERPs, and cloud accounting applications.",
    opportunities: [
      "Accounting Database Lead",
      "ERP Solutions Manager",
      "Financial Analyst",
      "Digital Auditing Coordinator",
      "Business Intelligence Systems Architect"
    ],
    image: "https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹21,000"
  },
  {
    id: "mba",
    code: "AVS-PG-203",
    name: "MBA",
    degree: "PG",
    duration: "2 Years (4 Semesters)",
    eligibility: "Any undergraduate degree with aggregate 50% marks + Periyar University/TANCET score.",
    description: "Our premier master-level program focusing on corporate enterprise governance, international business strategy, portfolio management, analytics, and agile organizational setups.",
    opportunities: [
      "Corporate Manager",
      "Investment Banking Associate",
      "Brand Director",
      "Business Transformation Consultant",
      "Operational Lead Coordinator"
    ],
    image: "https://images.unsplash.com/photo-1542744173-8e7e53415bb0?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹35,500"
  },
  {
    id: "mca",
    code: "AVS-PG-102",
    name: "MCA",
    degree: "PG",
    duration: "2 Years (4 Semesters)",
    eligibility: "Graduation in Computer Science, BCA, or equivalent degree with mathematics at 10+2 or degree level.",
    description: "Master modern software engineering, advanced data structures, microservices architectures, cloud platforms, Android/iOS design, and continuous integration systems.",
    opportunities: [
      "Senior Full-Stack Developer",
      "Cloud Architect",
      "Mobile Engineering Lead",
      "DevOps Deployment Engineer",
      "Database Systems Developer"
    ],
    image: "https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹25,000"
  },
  {
    id: "ma-english",
    code: "AVS-PG-301",
    name: "MA English",
    degree: "PG",
    duration: "2 Years (4 Semesters)",
    eligibility: "Graduation in BA English Literature with minimum 50% marks.",
    description: "Analyze post-colonial comparative texts, Shakespearean canons, critique methods, structural linguistics, and technical digital content strategies.",
    opportunities: [
      "Lead Communications Specialist",
      "Creative Content Editor",
      "Corporate Training Manager",
      "Senior Publisher",
      "Research Assistant / Academic"
    ],
    image: "https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=800&q=80",
    feePerSemester: "₹15,000"
  }
];

export const DEPARTMENTS: Department[] = [
  {
    id: "cs-dept",
    name: "Department of Computer Science & Intelligent Systems",
    description: "Nurturing computational innovation, cloud architectures, artificial intelligence deployments, and advanced industrial programming competence. Led by seasoned technicians with sophisticated laboratories.",
    hod: {
      name: "Dr. K. Srinivasan, Ph.D.",
      designation: "Professor & Head of Department",
      qualification: "M.C.A., M.Phil., Ph.D. in Mobile Computing & AI",
      experience: "18+ Years in Teaching & Applied Cloud Research",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=400&q=80",
      message: "The computer science ecosystem is evolving rapidly. We emphasize strong software fundamentals so our candidates adapt seamlessly to AI/ML, Cyber Security, cloud frameworks, and DevOps cycles."
    },
    faculty: [
      { name: "Dr. L. Mary Stella", designation: "Associate Professor", qualification: "M.Sc., M.Phil, Ph.D.", image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80" },
      { name: "Mrs. P. Radhika", designation: "Assistant Professor", qualification: "M.C.A., M.Phil.", image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80" },
      { name: "Mr. M. Anand Kumar", designation: "Assistant Professor", qualification: "M.E.(CSE)", image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80" }
    ],
    laboratories: [
      { name: "Turing AI & Advanced Systems Lab", description: "Equipped with 90 high-performance computer nodes, server staging arrays, and full-gigabit networks.", image: "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=600&q=80" },
      { name: "Ada Lovelace Cloud & Security Studio", description: "Focused on database servers, virtual security deployments, IoT automation, and software prototyping platforms.", image: "https://images.unsplash.com/photo-1527689368864-3a821dbccc34?auto=format&fit=crop&w=600&q=80" }
    ],
    achievements: [
      "Received ₹8.5 Lakhs State Board Grant for localized AI IoT Agricultural Research",
      "97% placement record in tier-1 corporate systems internships",
      "12 proprietary software design patents registered under Salem IP council"
    ],
    activities: [
      "Annual National Hackcon Meet: 'TECHFEST 2026'",
      "Weekly algorithmic logical puzzle challenges and coding sprints",
      "Special Industry Seminars featuring developers from Zoho, Wipro and Infosys"
    ]
  },
  {
    id: "comm-mgmt-dept",
    name: "Department of Commerce & Management Studies",
    description: "Preparing future corporate accountants, digital business executives, asset portfolio managers, and global executives through commercial simulations, financial risk analyses, and enterprise planning camps.",
    hod: {
      name: "Dr. S. Mohan Raj, Ph.D.",
      designation: "Professor & Head of Department",
      qualification: "M.Com., M.B.A., Ph.D. in Strategic Finance",
      experience: "21+ Years of Academic Commerce Leadership",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=400&q=80",
      message: "We mold our commerce, BBA, and MBA graduates into leaders capable of navigating financial trends, deploying enterprise solutions, and driving corporate strategies intelligently."
    },
    faculty: [
      { name: "Mr. R. Karthikeyan", designation: "Assistant Professor", qualification: "M.Com., M.Phil., NET Qualified", image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=300&q=80" },
      { name: "Dr. J. Preethi", designation: "Associate Professor", qualification: "M.B.A., Ph.D.", image: "https://images.unsplash.com/photo-1534751516642-a131fed10495?auto=format&fit=crop&w=300&q=80" }
    ],
    laboratories: [
      { name: "Kotler Business ERP & Finance Chamber", description: "Configured with modern corporate spreadsheet software, financial analysis systems, and ERP accounting suites.", image: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=600&q=80" }
    ],
    achievements: [
      "Accredited as a regional Corporate Incubation Center by startup agencies",
      "Won 1st Place in the South-Zone Corporate Financial Planning Hackathon",
      "Completed 14 financial audit strategies for Salem SMEs"
    ],
    activities: [
      "Annual Retail & Business Conclave: 'BIZ-WORLD 2026'",
      "Trading simulations, portfolio evaluations, and digital tax camps",
      "GST compliance seminars led by senior auditing officers"
    ]
  },
  {
    id: "applied-sciences",
    name: "Department of Life & Applied Sciences",
    description: "Fostering research curiosity, analytical laboratory prowess, molecular technologies, and visual art creation. The department coordinates cutting-edge bio and design studies.",
    hod: {
      name: "Dr. P. Dhanasekar, M.Sc., Ph.D.",
      designation: "Head of Applied Sciences",
      qualification: "M.Sc., Ph.D. in Industrial Biotechnology",
      experience: "15+ Years in Applied Sciences & Forensic Research",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80",
      message: "Applied sciences represent the future of human safety and commercial design. From molecular gene mapping to video communication grids, we cultivate pure experiential learning."
    },
    faculty: [
      { name: "Mrs. S. Vijayalakshmi", designation: "Assistant Professor", qualification: "M.Sc., M.Phil. in Biochemistry", image: "https://images.unsplash.com/photo-1548142813-c348350dfdf2?auto=format&fit=crop&w=300&q=80" }
    ],
    laboratories: [
      { name: "Bose Biomolecular Culture Chamber", description: "Houses advanced sterile incubators, microscopes, biological risk cabinets, and genetics instrumentation.", image: "https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=600&q=80" },
      { name: "VisCom Digital Production Desk", description: "Equipped with professional sound engineering panels, cinema-grade cameras, and digital coloring suites.", image: "https://images.unsplash.com/photo-1551269901-5c5e14c25df7?auto=format&fit=crop&w=600&q=80" }
    ],
    achievements: [
      "Biotechnology students published 4 papers in recognized Scopus research journals",
      "Visual Communication students won 'Best Non-Fiction Story' at Salem Short-Film Arena",
      "Fabric works curated in national designer expo in Mumbai"
    ],
    activities: [
      "National Bio-Research Seminar: 'BioFuture 2026'",
      "Indie short-film screens, camera operation bootcamps, and garment design shows",
      "Hands-on forensic diagnostics testing workshops"
    ]
  },
  {
    id: "humanities-dept",
    name: "Department of Languages & Humanities",
    description: "Cultivating comparative language mastery, cultural awareness, historical administrative philosophies, and high-level communications expertise necessary for modern media and government administration.",
    hod: {
      name: "Dr. V. Anuradha, Ph.D.",
      designation: "Professor & Head of Languages",
      qualification: "M.A., M.Phil., Ph.D. in Literature",
      experience: "16+ Years in Linguistics, Rhetorical Writing",
      image: "https://images.unsplash.com/photo-1534751516642-a131fed10495?auto=format&fit=crop&w=400&q=80",
      message: "Humanities and language mastery provide the critical soft-skills, analytical writing capability, and social administrative logic valued across global modern organizations."
    },
    faculty: [
      { name: "Mrs. M. Banumathi", designation: "Assistant Professor", qualification: "M.A., M.Phil (Tamil)", image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80" }
    ],
    laboratories: [
      { name: "Digital Phonetics & Linguistics Study Lab", description: "Interactive language suites featuring sound booths, speech playback models, and content drafting systems.", image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=600&q=80" }
    ],
    achievements: [
      "Awarded Outstanding Linguistic Presentation trophy by Periyar University",
      "4 candidates cleared State and Civil Service level-1 preliminary tests",
      "Hosted Salem regional historical epigraphy search camp"
    ],
    activities: [
      "Annual Intercollegiate Literary Gala: 'WORDSMITH 2026'",
      "Tamil grammar debates, poetry reading clubs, and historical preservation seminars",
      "Technical writing camps for corporate documentation"
    ]
  }
];

export const PLACEMENT_STATS = {
  highestPackage: "₹12.0 LPA",
  averagePackage: "₹4.2 LPA",
  placementRate: "93.4%",
  recruitersCount: 45,
  registeredStudents: 380,
  placedStudents: 355,
  trainingHours: "120+ Hours / Year",
  programDetails: [
    { title: "Quantitative Aptitude", desc: "Rigorous analytical problem-solving modules, logical reasoning drills, and speed mathematics formulations." },
    { title: "Full-Stack Tech Camps", desc: "Intensive training in Java, Python, React, Database engineering and cloud deployments." },
    { title: "Soft Skills & Language", desc: "Group discussions, mock corporate presentations, leadership speaking, and corporate behavioral etiquettes." },
    { title: "One-on-One Mock Audits", desc: "Strict mock interviews with real software architects and business consultants with personalized reviews." }
  ],
  internships: [
    { company: "Wipro Software Services", position: "Software Engineering Intern", count: 18, stipend: "₹15,000/mo" },
    { company: "Tata Consultancy Services", position: "Associate Systems Intern", count: 22, stipend: "₹18,000/mo" },
    { company: "Zoho Corporation", position: "Product Development Intern", count: 8, stipend: "₹20,000/mo" },
    { company: "Cognizant Solutions", position: "Business Operations Intern", count: 12, stipend: "₹12,000/mo" }
  ]
};

export const RECRUITERS: Recruiter[] = [
  { name: "Tata Consultancy Services (TCS)", logo: "https://images.unsplash.com/photo-1628157582853-a796fa650a6a?auto=format&fit=crop&w=150&h=80&q=80" },
  { name: "Wipro Technologies", logo: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=150&h=80&q=80" },
  { name: "Cognizant Technology Solutions", logo: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=150&h=80&q=80" },
  { name: "Infosys", logo: "https://images.unsplash.com/photo-1614064641938-3bbee52942c7?auto=format&fit=crop&w=150&h=80&q=80" },
  { name: "Zoho Corporation", logo: "https://images.unsplash.com/photo-1620121692029-d088224ddc74?auto=format&fit=crop&w=150&h=80&q=80" },
  { name: "Accenture India", logo: "https://images.unsplash.com/photo-1606857521015-7f9fcf423740?auto=format&fit=crop&w=150&h=80&q=80" },
  { name: "Capgemini Solutions", logo: "https://images.unsplash.com/photo-1542744094-2ab25be78b90?auto=format&fit=crop&w=150&h=80&q=80" },
  { name: "HCL Technologies", logo: "https://images.unsplash.com/photo-1551434678-e076c223a692?auto=format&fit=crop&w=150&h=80&q=80" }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: "t1",
    name: "Arun Kumar S",
    batch: "2023 - 2026",
    course: "B.Sc Computer Science",
    company: "Wipro Technologies (Power Programmer)",
    quote: "The academic rigor and constant laboratory drills in the Department of Computer Science sharpened my diagnostic coding abilities. The placement training team made sure I aced my technical interviews easily.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=150&h=150&q=80"
  },
  {
    id: "t2",
    name: "Priyanka Balakrishnan",
    batch: "2023 - 2026",
    course: "BCA",
    company: "Zoho Corporation (Technical Lead Associate)",
    quote: "My 3 years at AVS College changed my career trajectory. Working on real-world projects in the Ada Lovelace software workshop boosted my engineering confidence enormously.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=150&h=150&q=80"
  },
  {
    id: "t3",
    name: "Naveen Prasad R",
    batch: "2024 - 2026",
    course: "MBA",
    company: "Tata Consultancy Services (HR Lead)",
    quote: "Highly structured curriculums coupled with intensive case studies and industrial exposures primed me for leadership roles. AVS Arts & Science stands tall in academic distinction.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&h=150&q=80"
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  { id: "g1", title: "Majestic Main Campus Entrance", category: "campus", image: "https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=800&q=80" },
  { id: "g2", title: "Modern Web Systems Lab", category: "labs", image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80" },
  { id: "g3", title: "Central Library Reading Domain", category: "library", image: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=800&q=80" },
  { id: "g4", title: "State-level Volley Championship Tournament", category: "sports", image: "https://images.unsplash.com/photo-1513568690616-ad9748272fbd?auto=format&fit=crop&w=800&q=80" },
  { id: "g5", title: "Spandana Cultural Festival Performance", category: "cultural", image: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80" },
  { id: "g6", title: "15th Graduation Day Ceremony", category: "graduation", image: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&w=800&q=80" },
  { id: "g7", title: "Lush Green Perimeter & Walkways", category: "campus", image: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=800&q=80" },
  { id: "g8", title: "Chemistry and Applied Sciences Lab", category: "labs", image: "https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=800&q=80" },
  { id: "g9", title: "Multi-seat Tech Seminar Room", category: "campus", image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80" }
];

export const EVENTS: CollegeEvent[] = [
  {
    id: "e1",
    title: "TECHFEST 2026: National Coding Symposium",
    type: "symposium",
    date: "18",
    month: "AUG",
    location: "Main Auditorium, Block C",
    description: "Annual national level paper presentations, algorithmic design challenges, speed debugging battles, and web engineering displays.",
    organizedBy: "Department of Computer Science & Intelligent Systems",
    image: "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "e2",
    title: "AI and Cloud Server Prototyping Workshop",
    type: "workshop",
    date: "04",
    month: "SEP",
    location: "Ada Lovelace Computing Wing",
    description: "Intensive 3-day practical session on cloud servers deployments, model fine-tuning with TensorFlow, and micro-service integrations.",
    organizedBy: "Institution Innovation Cell (IIC)",
    image: "https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "e3",
    title: "Strategic Fiscal Auditing & GST Reforms Seminar",
    type: "seminar",
    date: "25",
    month: "OCT",
    location: "Srinivasa Ramanujan Conclave Room",
    description: "Examines comparative tax governance structure, modern enterprise digital bookkeeping guidelines, and corporate auditing ethics.",
    organizedBy: "Department of Commerce",
    image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80"
  }
];

export const NEWS_ANNOUNCEMENTS: NewsAnnouncement[] = [
  {
    id: "n1",
    title: "Admissions Open for Undergraduate (UG) and Postgraduate (PG) Programs for the Academic Year 2026 - 2027",
    date: "June 01, 2026",
    category: "admission",
    isImportant: true,
    content: "The online portal and physical enrollment registration desks are live for students seeking seats in Computer Science, BCA, BBA, B.Com, MBA, M.Sc, etc. Inherent scholarships are accessible."
  },
  {
    id: "n2",
    title: "AVS Arts & Science College achieves Outstanding NAAC Accreditation Grade of 'A' in Third Continuous Cycle",
    date: "May 20, 2026",
    category: "academic",
    isImportant: true,
    content: "National Assessment and Accreditation Council inspection parameters rated the institutional curriculum structure, advanced labs, placement numbers, and college campus environment as excellent."
  },
  {
    id: "n3",
    title: "Mega Campus Placement Drive with Top MNC Recruiters scheduled for final year candidates on August 22nd",
    date: "May 15, 2026",
    category: "placement",
    isImportant: false,
    content: "Wipro, Zoho, TCS, and Accenture recruitment drives are locking dates for virtual and written aptitude evaluation. Verify parameters in the Placement Block."
  }
];

export const FAQS: FAQItem[] = [
  {
    question: "What is the procedure to apply for Admission at AVS?",
    answer: "You can apply online via the Admissions webpage or download the Application PDF. Alternatively, visit our Admissions Office at Salem Campus with original credentials (10th, 12th cards, Transfer Certificate) for direct counselling advice.",
    category: "admissions"
  },
  {
    question: "Are distance learners eligible, or does the college have scholarships?",
    answer: "Yes, we award scholarships for academic excellence (above 90% in 12th gets up to 50% tuition waiving), government minority quotas, sports champions representing national states, and female student advancement incentives.",
    category: "admissions"
  },
  {
    question: "Is AVS Arts & Science College affiliated and accredited?",
    answer: "AVS Arts & Science is fully affiliated with Periyar University, Salem, approved by the UGC, and accredited with 'A' Grade by NAAC. This ensures all degrees are globally valid for higher education and government exams.",
    category: "academics"
  },
  {
    question: "How is the laboratory infrastructure for research and core computer projects?",
    answer: "We have designated central computing structures with more than 350 nodes, separate logic and analytical chambers, professional MATLAB and SPSS systems, chemistry chambers, and high speed 100 Mbps fiber networks.",
    category: "academics"
  },
  {
    question: "What are the hostel and lodging parameters for outstation pupils?",
    answer: "We offer highly secure, separate boys and girls hostels on campus, equipped with filtered water, round-the-clock power back up, high-speed Wi-Fi, modern study halls, gym access, and nutritious vegetarian/non-vegetarian cuisine options.",
    category: "hostel"
  }
];
