import React, { useState, useEffect, useRef } from 'react';
import { AnimatePresence } from 'motion/react';
import Header from './components/Header';
import LoadingOverlay from './components/LoadingOverlay';
import Footer from './components/Footer';
import WhatsAppButton from './components/WhatsAppButton';
import AdmissionPopup from './components/AdmissionPopup';
import StickyConversionBar from './components/StickyConversionBar';

// Page Views
import Home from './pages/Home';
import About from './pages/About';
import Admissions from './pages/Admissions';
import Courses from './pages/Courses';
import Departments from './pages/Departments';
import Placements from './pages/Placements';
import Events from './pages/Events';
import Gallery from './pages/Gallery';
import Contact from './pages/Contact';
import Register from './pages/Register';

import { ArrowUp } from 'lucide-react';

export default function App() {
  // Sync page state with window hash for realistic URL-style navigation
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [renderedPage, setRenderedPage] = useState<string>('home');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);
  const [isBackToTopVisible, setIsBackToTopVisible] = useState<boolean>(false);

  const isFirstMount = useRef(true);

  // Hash parser
  useEffect(() => {
    const parseHash = () => {
      const hash = window.location.hash.replace('#', '');
      const validPages = [
        'home', 
        'about', 
        'admissions', 
        'courses', 
        'departments', 
        'placements', 
        'events', 
        'gallery', 
        'contact',
        'register'
      ];
      const targetPage = validPages.includes(hash) ? hash : 'home';
      
      setCurrentPage(targetPage);
      
      if (isFirstMount.current) {
        setRenderedPage(targetPage);
        isFirstMount.current = false;
      }
    };

    // On Mount
    parseHash();

    // On hash change
    window.addEventListener('hashchange', parseHash);
    return () => window.removeEventListener('hashchange', parseHash);
  }, []);

  // Listen to page changes and trigger transitions
  useEffect(() => {
    // Avoid running transition on first load since parseHash already handles that
    if (currentPage === renderedPage) return;

    setIsLoading(true);

    const changeTimer = setTimeout(() => {
      setRenderedPage(currentPage);
      window.scrollTo({ top: 0 });
    }, 300);

    const hideTimer = setTimeout(() => {
      setIsLoading(false);
    }, 800);

    return () => {
      clearTimeout(changeTimer);
      clearTimeout(hideTimer);
    };
  }, [currentPage, renderedPage]);

  const handlePageChange = (pageId: string) => {
    if (currentPage === pageId) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    window.location.hash = `#${pageId}`;
  };

  // Back to top scroll visibility
  useEffect(() => {
    const handleScrollVisibility = () => {
      if (window.scrollY > 400) {
        setIsBackToTopVisible(true);
      } else {
        setIsBackToTopVisible(false);
      }
    };
    window.addEventListener('scroll', handleScrollVisibility);
    return () => window.removeEventListener('scroll', handleScrollVisibility);
  }, []);

  // Sync dark class on raw document body/html for Tailwind dark utilities
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  // Render correct page
  const renderPage = () => {
    switch (renderedPage) {
      case 'home':
        return <Home onPageChange={handlePageChange} isDarkMode={isDarkMode} />;
      case 'about':
        return <About isDarkMode={isDarkMode} />;
      case 'admissions':
        return <Admissions isDarkMode={isDarkMode} />;
      case 'courses':
        return <Courses isDarkMode={isDarkMode} onPageChange={handlePageChange} />;
      case 'departments':
        return <Departments isDarkMode={isDarkMode} />;
      case 'placements':
        return <Placements isDarkMode={isDarkMode} />;
      case 'events':
        return <Events isDarkMode={isDarkMode} />;
      case 'gallery':
        return <Gallery isDarkMode={isDarkMode} />;
      case 'contact':
        return <Contact isDarkMode={isDarkMode} />;
      case 'register':
        return <Register isDarkMode={isDarkMode} />;
      default:
        return <Home onPageChange={handlePageChange} isDarkMode={isDarkMode} />;
    }
  };

  return (
    <div className={`min-h-screen flex flex-col justify-between ${
      isDarkMode ? 'bg-brand-blue text-white' : 'bg-[#f8fafc] text-slate-800'
    } transition-colors duration-300`}>
      
      {/* Global Loading Overlay */}
      <AnimatePresence>
        {isLoading && <LoadingOverlay isDarkMode={isDarkMode} />}
      </AnimatePresence>

      {/* 1. Header Navigation */}
      <Header 
        currentPage={currentPage}
        onPageChange={handlePageChange}
        isDarkMode={isDarkMode}
        onToggleDarkMode={toggleDarkMode}
      />

      {/* 2. Main Page View Surface */}
      <main className="flex-1 pb-16">
        {renderPage()}
      </main>

      {/* 3. Footer */}
      <Footer onPageChange={handlePageChange} isDarkMode={isDarkMode} />

      {/* 4. Support Widgets */}
      <WhatsAppButton />
      <AdmissionPopup onApplyClick={() => handlePageChange('register')} />
      <StickyConversionBar onApplyClick={() => handlePageChange('register')} isDarkMode={isDarkMode} />

      {/* 5. Back to Top tool arrow */}
      {isBackToTopVisible && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-6 left-6 z-40 p-3 rounded-xl bg-brand-gold hover:bg-brand-gold-dark text-black shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer"
          aria-label="Back to Top coordinates"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      )}

    </div>
  );
}
