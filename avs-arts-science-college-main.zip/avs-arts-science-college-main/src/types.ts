export interface Course {
  id: string;
  code: string;
  name: string;
  degree: 'UG' | 'PG';
  duration: string;
  eligibility: string;
  description: string;
  opportunities: string[];
  image: string;
  feePerSemester: string;
}

export interface Department {
  id: string;
  name: string;
  description: string;
  hod: {
    name: string;
    designation: string;
    qualification: string;
    experience: string;
    image: string;
    message: string;
  };
  faculty: {
    name: string;
    designation: string;
    qualification: string;
    image: string;
  }[];
  laboratories: {
    name: string;
    description: string;
    image: string;
  }[];
  achievements: string[];
  activities: string[];
}

export interface Faculty {
  name: string;
  designation: string;
  department: string;
  qualification: string;
  experience: string;
  image: string;
}

export interface PlacementRecord {
  year: string;
  placementPercentage: number;
  highestPackage: string;
  averagePackage: string;
  recruitedStudentsCount: number;
  companiesVisited: number;
}

export interface Recruiter {
  name: string;
  logo: string;
}

export interface Testimonial {
  id: string;
  name: string;
  batch: string;
  course: string;
  company?: string;
  quote: string;
  rating: number;
  image: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'campus' | 'labs' | 'library' | 'sports' | 'cultural' | 'graduation';
  image: string;
}

export interface CollegeEvent {
  id: string;
  title: string;
  type: 'seminar' | 'workshop' | 'symposium' | 'cultural' | 'sports';
  date: string;
  month: string;
  location: string;
  description: string;
  organizedBy: string;
  image: string;
}

export interface NewsAnnouncement {
  id: string;
  title: string;
  date: string;
  category: 'academic' | 'admission' | 'placement' | 'event';
  isImportant: boolean;
  content: string;
}

export interface FAQItem {
  question: string;
  answer: string;
  category: 'general' | 'admissions' | 'academics' | 'hostel';
}
